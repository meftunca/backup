<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\article;

class FrontendController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        //table list
        $tableList = DB::select('SHOW TABLES');
        $posts = DB::table("article")->orderBy('id', 'desc')->limit(6)->get();
        $pop = DB::table("article")->select('kind','title','picture','author','author_picture','seo_url')->orderBy('id', 'desc')->limit(5)->get();
        $contact = DB::table("contact")->orderBy('id', 'desc')->limit(1)->get();
        $category = DB::table("category")->get();
        $paginate = DB::table("article")->paginate(6);
        $comment = DB::table("comment")->orderBy("id","desc")->get();
        return view('frontend.homePage', ["tableList" => $tableList,'posts'=>$posts,'pop'=>$pop,'contact'=>$contact,'category'=>$category,"paginate"=>$paginate,"comment"=>$comment]);
    }
    public function blog($name=null){
        $tableList = DB::select('SHOW TABLES');
        if(!is_null ($name)){
            $posts = DB::table("article")->where("kind","=",$name)->orderBy('id', 'desc')->limit(6)->get();
        }else{
            $posts = DB::table("article")->orderBy('id', 'desc')->limit(6)->get();
        }
        $pop = DB::table("article")->select('kind','title','picture','author','author_picture','seo_url')->orderBy('id', 'desc')->limit(5)->get();
        $contact = DB::table("contact")->orderBy('id', 'desc')->limit(1)->get();
        $category = DB::table("category")->get();
        $paginate = DB::table("article")->paginate(6);
        $comment = DB::table("comment")->orderBy("id","desc")->get();
        return view('frontend.blog', ["tableList" => $tableList,'posts'=>$posts,'pop'=>$pop,'contact'=>$contact,'category'=>$category,"paginate"=>$paginate,"comment"=>$comment]);
    }

    public function article($name){
        $tableList = DB::select('SHOW TABLES');
        $posts = DB::table("article")->where('seo_url','=',str_slug($name,"-"))->limit(1)->get();
        $pop = DB::table("article")->select('kind','title','picture','author','author_picture','seo_url')->orderBy('id', 'desc')->limit(5)->get();
        $contact = DB::table("contact")->orderBy('id', 'desc')->limit(1)->get();
        $category = DB::table("category")->get();
        $paginate = DB::table("article")->paginate(6);
        $comment = DB::table("comment")->orderBy("id","desc")->get();
        return view('frontend.article', ["tableList" => $tableList,'posts'=>$posts,'pop'=>$pop,'contact'=>$contact,'category'=>$category,"paginate"=>$paginate,"comment"=>$comment]);
    }
    public function promotion(){
        return view("frontend.promotion");
    }

}
