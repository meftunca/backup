<?php

namespace App\Http\Controllers\Admin;

use function PHPSTORM_META\type;
use Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\article;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Carbon\Carbon;

class PostController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function addTable(Request $request){
     $tableName = $request->input("tableName");
        if (Schema::hasTable($tableName)) {
            return redirect()->back()->withErrors("Maalesef tabloyu daha önceden oluşturmuşsunuz...")->withInput();
        }else{
         $addQuery = Schema::create($tableName, function (Blueprint $table) {
             $table->collation = 'utf8_turkish_ci';
             $table->increments('id');
                $table->timestamps();
            });
         if($addQuery){
             return redirect()->back();
         }else{
             return redirect()->back()->withErrors("Maalesef tablo oluşturulamadı...")->withInput();
         }
        }
    }
    public function addColumn(Request $request){
        Schema::table('users', function($table) {
            $table->string("title");
            $table->text("description");
            $table->timestamps();
        });
        $tableName = $request->input("tableName");
        $colName = $request->input("colName");
        $type = $request->input("type");
        $colLimit = $request->input("colLimit");
        dd($request->all());
        if (Schema::hasTable($tableName)) {
            if (Schema::hasColumn($tableName, $colName)) {
               redirect()->back()->withErrors("Maalesef tablonuzda bu colon daha önceden oluşturmuşsunuz...")->withInput();
            }else{
                Schema::table($tableName, function (Blueprint $table) {
                    return ($type=="text") ? $table->text($colName) : ($type=="string") ? $table->string($colName) : ($type=="date") ? $table->date($colName) :($type=="timestamps") ? $table->timestamp($colName):$table->string($colName);
                });
            }
        }

    }
    public function rowEdit($name,$id,Request $request){
        $columns = DB::getSchemaBuilder()->getColumnListing($name);
        $count = count($columns)-3;
        $updateData = [];
        for($i = 1;$i<=$count;$i++){
            $updateData[$columns[$i]] = $request->input($columns[$i]);
        }
        $insertData["updated_at"]= Carbon::now('Europe/Istanbul');

        $updateQuery = DB::table($name)->where("id","=",$id)->update($updateData);
        if($updateQuery){
            return redirect()->back();
        }
        else{
            return redirect()->back()->withErrors($updateQuery)->withInput();
        }
    }
    public function rowAdd($name,Request $request){
        $columns = DB::getSchemaBuilder()->getColumnListing($name);
        $count = count($columns)-3;
        $insertData = [];
        for($i = 1;$i<=$count;$i++){
            $insertData[$columns[$i]] = $request->input($columns[$i]);
         }
         $insertData["created_at"]= Carbon::now('Europe/Istanbul');
         $insertData["updated_at"]= Carbon::now('Europe/Istanbul');
        if (Schema::hasColumn($name, "seo_url")) {
            //
            if($request->input("title") ){
                $insertData["seo_url"]= str_slug($request->input("title"),"-");
            }elseif($request->input("name") ){
                $insertData["seo_url"]= str_slug($request->input("name"),"-");
            }
        }


        if ($request->has("kind"))
        {
            $kind = $request->input("kind");
            $cat_query = DB::table("article")->where("kind","=",$kind);
            if($cat_query){
                $count = article::where(['kind' => $kind])->get()->count();
                $is_cat = DB::table("category")->where("category_name","=",$kind)->get();
                if($is_cat){
                    $len=0;
                    foreach ($is_cat as $is){
                        $len = $is->category_len;
                    }
                  $addQuery = DB::table("category")->update(["category_len"=>$len+1]);
                    if($addQuery==0){
                        DB::table("category")->insert(["category_name"=>$kind,"category_len"=>1]);
                    }
                }else{
                    DB::table("category")->insert(["category_name"=>$kind,"category_len"=>$count+1]);
                }
            }else{
                DB::table("category")->insert(["category_name"=>$kind,"category_len"=>1]);
            }
        }

        $insertQuery = DB::table($name)->insert($insertData);
        if($insertQuery){
            return redirect()->back();
        }
        else{
            return redirect()->back()->withErrors($insertQuery)->withInput();
        }
    }

}
