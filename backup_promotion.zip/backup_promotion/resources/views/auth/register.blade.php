@extends('layouts.app')

@section('content')
<div class="container">

            <div class="panel panel-default">
                <div class="head">Register</div>
                <div class="body">
                    <form class="mt-0 container p-0" method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}

                        <div class="field line {{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="w-full">
                                <input id="name" type="text"  name="name" value="{{ old('name') }}" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="field line {{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="w-full">
                                <input id="email" type="email"  name="email" value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="field line {{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="w-full">
                                <input id="password" type="password"  name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="field line ">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="w-full">
                                <input id="password-confirm" type="password"  name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="field line ">
                            <div class="w-full col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>

        </div>
    </div>
</div>
@endsection
