@extends('layouts.app')
@section("up")
    <script src="{{asset('ckeditor/ckeditor.js')}}"></script>
@endsection
@section('content')
    <div class="container">

        <form action="{{url($editUrl)}}" method="post" class="d-flex flex-column">
            {{csrf_field()}}
            @php
                $count = count($columns) -2; $a = 1;
            @endphp
            @for($i=1;$i<$count;$i++)
                @foreach($tables as $k)
                    @foreach($k as $d=>$v)
                        @php
                            if($d == $columns[$i])
                            $value = $v;
                        @endphp
                    @endforeach

                @endforeach
                <div class="field line">
                    @if($columns[$i] == "image")
                        <div class="wrap xl-2 md-1 xl-gutter-40">
                            <div class="col">
                                <div class="fileput">
                                    <aside class="fileput-text">
                                        Lütfen dosya seçmek için tıklayın
                                        <button type="button" class="btn btn-sm btn-info fileput-btn">Dosya seç</button>
                                    </aside>
                                    <input type="file" name="image" value="{{$value}}">
                                    <div class="fileput-list">
                                        <ul class="list line"></ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <img src="{{$value}}" alt="" class="img-embed">
                            </div>
                        </div>

                    @elseif($columns[$i]=="post" || $columns[$i]=="text")
                        <textarea name="{{$columns[$i]}}" id="{{$columns[$i]}}" class="w-full" rows="10">{{$value}}</textarea>
                        <script>
                            CKEDITOR.replace({{$columns[$i]}});
                        </script>
                    @else
                        <input type="text" name="{{$columns[$i]}}" value="{{$value}}" placeholder="{{$columns[$i]}} Alanını doldurun...">
                    @endif
                </div>
            @endfor
            <input type="submit" class="btn btn-md btn-primary" value="Güncelle">
        </form>

    </div>
@endsection
