@extends('layouts.app')
@section("up")
    <style>
        td > * {
            font-size: 13px !important;
        }

        td {
            max-width: 150px;
            word-wrap: break-word;
        }
    </style>
@endsection
@section('content')
    <div class="btn-group">
        <a href="#devre-disi" class="disabled btn btn-md btn-rose tooltip">Yeni colon ekle <i class="icon-plus text lg ml-10"></i>
                <span class="content top" style="width: 300px; word-wrap: normal; z-index: 99999 !important">Maalesef Bakım sebebiyle çalışmıyor...</span>
        </a>
        <a href="{{url("/admin/table/$tableName/add")}}" class="btn btn-md btn-sublime">Yeni veri ekle <i class="icon-plus text lg ml-10"></i></a>
    </div>
    <table class="table underline rad-5 shadow-1 text center-all">
        <thead>
            <tr class="bg-black">
                <th>#</th>
                @php
                    $count = count($columns);$a=0;
                @endphp
                @for($i=1;$i<$count;$i++)
                    @if($columns[$i] == "password" or $columns[$i] == "remember_token")
                    @else
                        <th>{{$columns[$i]}}</th>
                    @endif
                @endfor
                <th>işlem</th>
            </tr>
        </thead>
        <tbody>
        @php
            $a = 1
        @endphp
        @foreach($tables as $cols=>$val)
            <tr>
                @foreach($val as $k=> $v)
                    @if($k != "id")
                        @if($k == "created_at" or $k == "updated_at")
                            <td>{!! \Carbon\Carbon::createFromTimeStamp(strtotime($v))->diffForHumans() !!}</td>
                        @elseif($k == "password" or $k == "remember_token")
                        @else
                            <td>{!! str_limit($v,100) !!}</td>
                        @endif
                    @else
                        @php
                            $rowId = $v;
                        @endphp
                        <th scope="row">{{$a++}}</th>

                    @endif
                @endforeach
                <td class="btn-group">
                    <a href="{{url("/admin/table/$tableName/edit/$rowId")}}" class="btn btn-md btn-primary"><i
                                class="icon-edit-3 mr-10"></i> düzenle</a>
                    <a href="{{url("/admin/table/$tableName/delete/$rowId")}}" class="btn btn-md btn-rose"><i
                                class="icon-trash mr-10"></i> sil</a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
@endsection
