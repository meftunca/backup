@extends('layouts.app')
@section("up")
    <script src="{{asset('ckeditor/ckeditor.js')}}"></script>
@endsection
@section('content')
    <div class="container">
        <form action="{{url($addUrl)}}" method="post" class="d-flex flex-column">
            {{csrf_field()}}
            @php
                $count = count($columns) -2; $a = 1;
            @endphp
            @for($i=1;$i<$count;$i++)
                <div class="field line">
                    @if(str_contains($columns[$i],"seo") || str_contains($columns[$i],"url"))
                    @elseif($columns[$i] == "image")
                                <div class="fileput">
                                    <aside class="fileput-text">
                                        Lütfen dosya seçmek için tıklayın
                                        <button type="button" class="btn btn-sm btn-info fileput-btn">Dosya seç</button>
                                    </aside>
                                    <input type="file" name="image" >
                                    <div class="fileput-list">
                                        <ul class="list line"></ul>
                                    </div>
                                </div>
                    @elseif( $columns[$i]=="examples")
                        <textarea name="{{$columns[$i]}}"class="w-full" rows="10" placeholder="{{$columns[$i]}} Alanını doldurun"></textarea>
                    @elseif($columns[$i]=="post" || $columns[$i]=="text"|| $columns[$i]=="explanation")
                        <h4 class="w-full" style="position: absolute;margin-top: -30px;">{{$columns[$i]}} Alanını doldurun</h4>
                        <textarea name="{{$columns[$i]}}" id="{{$columns[$i]}}" class="w-full" rows="10" placeholder=""></textarea>
                        <script>
                            CKEDITOR.replace('{{$columns[$i]}}',{
                                customConfig: '{{asset("ckeditor/adminConfig.js")}}',width :'100%'
                            });
                        </script>
                    @else
                        <input type="text" name="{{$columns[$i]}}"  placeholder="{{$columns[$i]}} Alanını doldurun...">
                    @endif
                </div>
            @endfor
            <input type="submit" class="btn btn-md btn-primary" value="Yeni satır ekle">
        </form>

    </div>
@endsection
