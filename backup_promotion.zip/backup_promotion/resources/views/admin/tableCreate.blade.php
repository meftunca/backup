@extends('layouts.app')

@section('content')
<div class="container">
    <div class="panel">
        <div class="head">Uyarılar</div>
        <div class="body flex-column align-items-start">
            <p class="text-rose m-10 ">Tabloyu oluşturduktan sonra otomatik olarak id değeri increments(artan) olarak eklenecektir...</p>
            <p class="text-rose m-10">Tabloyu oluşturduktan sonra otomatik olarak created_at değeri eklenecektir...</p>
            <p class="text-rose m-10">Tabloyu oluşturduktan sonra otomatik olarak updated_at değeri eklenecektir...</p>
        </div>
    </div>
    <form action="{{route("postCreateTable")}}" method="POST" class="w-full">
        {{csrf_field()}}
        <div class="field line"><input type="text" name="tableName" placeholder="Tablo adı"></div>
        <input type="submit" class="btn btn-md btn-primary" value="Satır oluştur">
    </form>
</div>
@endsection
