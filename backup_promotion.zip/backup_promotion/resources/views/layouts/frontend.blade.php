<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    <link href="{{ asset('css/comeback.css') }}" rel="stylesheet">
    @yield("up")
    <style>
        .mr--10 {
            margin-right: -10px;
        }

        .ml--10 {
            margin-left: -10px;
        }
    </style>

</head>
<body style="background: #f9f9f9;">
<div id="app">
     <nav class="navbar dark no-shadow">
        <div class="navbar-panel justify-content-xl-center justify-content-md-between">
            <h5 class="text bold">ZERONE
                <span class="text-blue">
                    <i class="icon-chevron-left text-info text md mr--10"></i>
                    <i class="icon-minus text-blue text md"></i>
                    <i class="icon-chevron-right text-info text md ml--10"></i>
                </span> DESING</h5>
            <a href="#!" class="collapse-toggle" data-collapse="navbar" data-href="navbar-dark">
                <i class="fa fa-bars"></i></a>
        </div>
        <div class="navbar-collapse " data-id="navbar-dark">
            <ul class="nav-item right collapse">
                <li class="item"><a href="{{route("home")}}">Anasayfa</a></li>
                <li class="item"><a href="{{route("blog")}}">blog</a></li>
                <li class="item"><a href="{{route("promotion")}}">tanıtım</a></li>
                @guest
                    <li class="item"><a href="{{ route('login') }}">Giriş Yap</a></li>
                    @else

                        <li class="item dropdown">
                            <a href="#" class="dropdown-toggle">
                                {{ str_limit(Auth::user()->name ,8)}} <span class="icon-chevron-down"></span>
                            </a>

                            <ul class="dropdown-menu">
                                <li class="item"><a href="{{route("adminHome")}}">Panel'e git</a></li>
                                <li class="item">
                                    <a href="{{ route('logout') }}"
                                       onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                          style="display: none;">
                                        {{ csrf_field() }}
                                    </form>
                                </li>
                            </ul>
                        </li>
                        @endguest

            </ul>
        </div>
    </nav>
     <div class="wrap h-50"></div>
            <div class="container">
                <div class="wrap xl-top xl-flexbox xl-around xl-gutter-24 md-gutter-0">
                    <div class="col xl-5-7 md-1-1">
                        @yield('content')

                    </div>
                    <div class="col xl-2-7 md-1-1">
                        <section class="field search w-full mt-10 mb-0">
                            <label for="searchpur"></label><input class="input-search rad-3 w-full br-0" type="text" id="searchput" data-search="true" placeholder="Ara...">
                        </section>
                        <div class="scrollspy search_content mb-10 bg-white p-10 " style="overflow-y: hidden;max-height: 300px;">
                            <ul class="list search_list w-full  rad-0"></ul>
                        </div>
                        <div class="mb-10"></div>

                        <section class="wrap xl-flexbox xl-top xl-1 ">
                            <div class="col p-10 bg-white">
                                <h3>Son yazılar
                                    <div class="bg-success" style=" width: 80px;height: 3px;"></div>
                                </h3>
                                <div class="mt-20"></div>
                                @foreach($pop as $populars)
                                    <aside class="wrap xl-flexbox xl-gutter-16 mt-10">
                                        <div class="col xl-1-4 md-1-8">
                                            <img src="{{$populars->picture}}" alt="" width="60" height="60">
                                        </div>
                                        <div class="col xl-3-4  md-7-8">
                                            <a href="{{url("/blog/".str_replace(" ","-",$populars->title))}}" class="text md">{{$populars->title}}</a><br>
                                            <div class="wrap xl-middle xl-gutter-8">
                                                <img src="{{$populars->author_picture}}" class="circle" width="25" alt="">
                                                <span>{{$populars->author}} </span><span>/</span><span>{{$populars->kind}} </span></div>
                                            <a href="{{url("/blog/article/".$populars->seo_url)}}" class="text xs">Daha fazla oku...</a>
                                        </div>
                                    </aside>
                                @endforeach
                            </div>
                            <div class="mt-20"></div>
                            <div class="col bg-white p-10">
                                <h3>sosyal medya
                                    <div class="bg-purple" style=" width: 80px;height: 3px;"></div>
                                </h3>
                                <div class="d-flex justify-content-around mt-20">
                                    @foreach($contact as $cont)
                                        <a href="{{$cont->facebook}}" class="btn btn-circle btn-primary hover-line"><i class="icon-facebook text lg"></i></a>
                                        <a href="{{$cont->twitter}}" class="btn btn-circle btn-info hover-line"><i class="icon-twitter text lg"></i></a>
                                        <a href="{{$cont->instagram}}" class="btn btn-circle btn-purple hover-line"><i class="icon-instagram text lg"></i></a>
                                        <a href="{{$cont->github}}" class="btn btn-circle btn-dark hover-line"><i class="icon-github text lg"></i></a>
                                        <a href="{{$cont->codepen}}" class="btn btn-circle btn-sublime hover-line"><i class="icon-codepen text lg"></i></a>
                                    @endforeach

                                </div>
                            </div>
                            <div class="col mt-20"></div>
                            <div class="col bg-white p-20">
                                <h3>Kategori
                                    <div class="bg-rose" style=" width: 80px;height: 3px;"></div>
                                </h3>
                                <div class="wrap mt-20 xl-flexbox xl-1">
                                    @foreach($category as $cat)
                                        <a href="{{url("/blog/category/$cat->category_name")}}">{{$cat->category_name}} ({{$cat->category_len}})</a>
                                    @endforeach
                                </div>
                            </div>
                        </section>
                    </div>
                </div>

            </div>
</div>

<!-- Scripts -->
<script src="{{ asset('js/comeback.js') }}"></script>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"
        integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
        crossorigin="anonymous"></script>
@yield("down")
<script>

   $(document).ready(function () {
        $("ul.pagination li").addClass("item");
        var search = $("#searchput"),list = $(".search_list"),content = $(".search_content");
       content.hide();

       search.keyup(function () {
            var str = $(this).val();
            if (str ==="") {
                $(".search_list li").remove();
                content.slideUp(300);
            } else {
                $.ajax({
                    url: '{{route("search")}}',
                    data: {search: str},
                    method: "POST",
                    cache: false,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success:function(val){
                        $(".search_list").html(val);
                    }
                }).done(function () {
                    content.slideDown(300);
                });
            }
        });
       search.change(function () {
           var str = $(this).val();
           if (str ==="") {
               $(".search_list li").remove();
               content.slideUp(300);
           }
       });

    });
</script>
</body>
</html>
