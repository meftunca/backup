<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    <link href="{{ asset('css/comeback.css') }}" rel="stylesheet">
    @yield("up")
</head>
<body>
<div id="app">
    <nav class="navbar dark">
        <div class="navbar-panel justify-content-center">
            <h4>Logo</h4>
            <a href="#!" class="collapse-toggle" data-collapse="navbar" data-href="navbar-dark"><i
                        class="fa fa-bars"></i></a>
        </div>
        <div class="navbar-collapse " data-id="navbar-dark">
            <ul class="nav-item right collapse">
                <li class="item"><a href="{{route("home")}}">anasayfa</a></li>
                @guest
                    <li class="item"><a href="{{ route('login') }}">Giriş Yap</a></li>
                    <li class="item"><a href="{{ route('register') }}">Kayıt ol</a></li>
                @else
                    <li class="item"><a href="{{route("adminHome")}}">Admin anasayfa</a></li>
                    <li class="item">
                        <a class="sidebar-toggle text-blue" data-toggle="sidebar"
                                data-href="sidebar">
                            Dashboard
                        </a>
                    </li>
                    <li class="item dropdown">
                        <a href="#" class="dropdown-toggle">
                            {{ Auth::user()->name }} <span class="icon-chevron-down"></span>
                        </a>

                        <ul class="dropdown-menu">
                            <li class="item">
                                <a href="{{ route('logout') }}"
                                   onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                      style="display: none;">
                                    {{ csrf_field() }}
                                </form>
                            </li>
                        </ul>
                    </li>
                @endguest

            </ul>
        </div>
    </nav>
    <div class="wrap h-50"></div>
    @guest

    @else
        <header class="sidebar" data-type="sidebar" data-id="sidebar">
            <div class="sidebar-head">
                <img src="https://secure.meetupstatic.com/photos/event/5/7/d/3/global_436702483.jpeg" alt=""
                     class="img-embed">
            </div>
            <div class="sidebar-body" style="width: 300px;">
                <ul class="sidebar-content list-accordion">
                    <li class="item"><a href="{{route("tableCreate")}}" class="text md">Yeni tablo oluştur <i class="icon-sidebar text md ml-10"></i></a></li>
                     <li class="item">
                        <a href="#!"
                           class="collapse-toggle text md w-full d-flex justify-content-between align-items-center"
                           data-collapse="default" data-href="1">
                            Tablolar <i class="icon-chevron-down text lg"></i></a>
                        <div class="collapse" data-id="1">
                            <ul class="list box link ">
                                @foreach($tableList as $v)
                                    @foreach($v as $k=>$i)
                                        @if($i=="password_resets" or $i=="migrations")
                                        @else
                                            @if(str_contains ($i,"project"))
                                            @else
                                                <li><a href="{{url("/admin/table/$i")}}">{{$i}} tablosu</a></li>
                                            @endif
                                        @endif
                                    @endforeach
                                @endforeach
                            </ul>
                        </div>
                    </li>
                   <li class="item">
                        <a href="#!"
                           class="collapse-toggle text md w-full d-flex justify-content-between align-items-center"
                           data-collapse="default" data-href="2">
                            Projeleri yönet <i class="icon-chevron-down text lg"></i></a>
                        <div class="collapse" data-id="2">
                            <ul class="list box link ">
                                @foreach($tableList as $v)
                                    @foreach($v as $k=>$i)
                                        @if($i=="password_resets" or $i=="migrations")
                                        @else
                                            @if(str_contains ($i,"project"))
                                                @if($i == "project")
                                                    <li><a href="{{url("/admin/table/$i")}}">Proje oluştur</a></li>
                                                @else
                                                    <li><a href="{{url("/admin/table/$i")}}">{{str_replace("_"," ",str_replace("project","",$i))}} tablosu</a></li>
                                                @endif
                                            @else
                                            @endif
                                        @endif
                                    @endforeach
                                @endforeach
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="sidebar-footer"></div>
        </header>

    @endguest
    <div class="container">
    @yield('content')
    </div>
</div>

<!-- Scripts -->
<script src="{{ asset('js/comeback.js') }}"></script>
@yield("down")
</body>
</html>
