<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/home', function () {
    return view('welcome');
});
Auth::routes();
Route::namespace("Frontend")->group(function(){
    Route::get('/', 'FrontendController@index')->name('home');
    Route::get('/blog', 'FrontendController@blog')->name('blog');
    Route::get('/blog/article/{name}', 'FrontendController@article');
    Route::get('/blog/category/{name}', 'FrontendController@blog');
    Route::post("blog/comment","PostController@addComment")->name("commentPost");
    Route::get('/promotion', 'FrontendController@promotion')->name('promotion');
    Route::any("/search","PostController@search")->name("search");

});
/**
 * Admin panel
 */
Route::namespace('Admin')->prefix("admin")->group(function () {
    Route::get('/', 'AdminController@index')->name('adminHome');
    Route::get('/home', 'AdminController@index')->name('adminHome');

    Route::get("/tableCreate", 'AdminController@tableCreate')->name("tableCreate");
    Route::get("/postCreate", 'AdminController@postCreate')->name("postCreate");
    Route::post("/postArticle",'PostController@postArticle')->name("postArticle");
    Route::post("/postable",'PostController@addTable')->name("postCreateTable");
    Route::post("/addcolumn",'PostController@addTable')->name("postAddColumn");

    Route::prefix('table')->group(function () {
        Route::get('/{name}', 'AdminController@table');
        Route::get('/{name}/addcolumn','AdminController@tableColCreate');
        Route::get('/{name}/delete/{id}','AdminController@rowDelete');
        Route::get('/{name}/edit/{id}','AdminController@rowEdit');
        Route::get('/{name}/add','AdminController@rowInsert');
        Route::post('/{name}/add','PostController@rowAdd');
        Route::post('/{name}/update/{id}','PostController@rowEdit');
    });

 });