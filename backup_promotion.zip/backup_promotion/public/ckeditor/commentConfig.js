CKEDITOR.editorConfig = function( config ) {
    config.toolbar = [
        { name: 'insert', items: [ 'Image', 'CodeSnippet','Smiley', 'Iframe' ] },
        { name: 'colors', items: [ 'TextColor', 'BGColor' ] },
    ];
};