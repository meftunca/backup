CKEDITOR.editorConfig = function( config ) {

};