<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProjectCategoryLibaryNotesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('project_category_libary_notes', function (Blueprint $table) {
            $table->increments('id');
            $table->string ("heading");
            $table->string ("notes");
            $table->string ("libary_name");
            $table->string ("category_name");
            $table->string ("framework_name");
            $table->string ("seo_url");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('project_category_libary_notes');
    }
}
