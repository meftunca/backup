<?php
   
   
   Route::get('/', "HomeController@index")->name("home");
   
   
   //Route::namespace("Frontend")->group(function () {
   //    Route::get('/', 'FrontendController@index')->name('home');
   //    Route::get('/blog', 'FrontendController@blog')->name('blog');
   //    Route::get('/blog/article/{name}', 'FrontendController@article');
   //    Route::get('/blog/category/{name}', 'FrontendController@blog');
   //    Route::post("blog/comment", "PostController@addComment")->name("commentPost");
   //    Route::get('/promotion', 'FrontendController@promotion')->name('promotion');
   //    Route::any("/search", "PostController@search")->name("search");
   //
   //});
   //Auth::routes();
   
   /**
    * Admin panel
    */
   //Route::namespace("Projects")->prefix("projects")->group(function () {
   //    Route::get("/", "ProjectsController@index")->name("projectsHome");
   //    Route::prefix("docs")->group(function () {
   //        Route::get("/{project_name}", "ProjectsController@project_view");
   //        Route::get("/{project_name}/{name}", "ProjectsController@docs");
   //        Route::get("/{project_name}/{name}/{libary}", "ProjectsController@libary");
   //    });
   //    Route::prefix("create")->group(function () {
   //        //view create form
   //        Route::get("/project", "ProjectsController@project")->name("create_project");
   //        Route::get("/category", "ProjectsController@category")->name("create_category");
   //        Route::get("/libary", "ProjectsController@libaries")->name("create_libary");
   //        Route::get("/libary_content", "ProjectsController@libary_content")->name("create_libary_content");
   //        Route::get("/libary_notes", "ProjectsController@libary_notes")->name("create_libary_notes");
   //        //create post form
   //        Route::post("/new/project", "PostController@project")->name("create_post_project");
   //        Route::post("/new/category", "PostController@category")->name("create_post_category");
   //        Route::post("/new/libary", "PostController@libaries")->name("create_post_libary");
   //        Route::post("/new/libary_content", "PostController@libary_content")->name("create_post_libary_content");
   //        Route::post("/new/libary_notes", "PostController@libary_notes")->name("create_post_libary_notes");
   //    });
   //    Route::prefix("search")->group(function () {
   //        Route::get("/project", "PostController@project_search")->name("search_project");
   //        Route::get("/category", "PostController@project_category_search")->name("search_project_category");
   //        Route::get("/libary", "PostController@project_libary_search")->name("search_project_lib");
   //        Route::get("/content", "PostController@project_libary_content_search")->name("search_project_lib_content");
   //    });
   //
   //    Route::prefix("edit")->group(function () {
   //        //edit view form
   //        Route::get("/project/{id}", "ProjectsController@e_project");
   //        Route::get("/category/{id}", "ProjectsController@e_category");
   //        Route::get("/libary/{id}", "ProjectsController@e_libary");
   //        Route::get("/libary_content/{id}", "ProjectsController@e_libary_content");
   //        Route::get("/libary_notes/{id}", "ProjectsController@e_libary_notes");
   //        //edit form
   //        Route::post("/update/project/{id}", "PostController@e_project");
   //        Route::post("/update/category/{id}", "PostController@e_category");
   //        Route::post("/update/libary/{id}", "PostController@e_libary");
   //        Route::post("/update/libary_content/{id}", "PostController@e_libary_content");
   //        Route::post("/update/libary_notes/{id}", "PostController@e_libary_notes");
   //    });
   //});
   
   Route::namespace("Auth")->group(function (){
      Route::get("/login-member", "MemberLoginController@ShowLogin")->name("member.login");
      Route::post("/login-members", "MemberLoginController@login")->name("member.login.submit");
      Route::get("/sign-in-member", "MemberSignController@showSignin")->name("member.signin");
      Route::post("/sign-in-members", "MemberSignController@signin")->name("member.signin.submit");
      Route::post("/member-logout", "MemberLoginController@logout")->name("member.logout");
   });
   
//   Route::get("/login-member", "Auth\MemberLoginController@ShowLogin")->name("member.login");
//   Route::post("/login-members", "Auth\MemberLoginController@login")->name("member.login.submit");
//   Route::get("/sign-in-member", "Auth\MemberSignController@showSignin")->name("member.signin");
//   Route::post("/sign-in-members", "Auth\MemberSignController@signin")->name("member.signin.submit");
//   Route::get("/member-logout", "Auth\MemberLoginController@logout")->name("member.logout");
//
   
   //Auth::routes();
   
   Route::prefix("admin")->group(function () {
      Route::get('/', 'Admin\AdminController@index')->name('admin.dashboard');
      Route::get("/login", "Auth\AdminLoginController@ShowLogin")->name("admin.login");
      Route::post("/login", "Auth\AdminLoginController@login")->name("admin.login.submit");
      Route::namespace('Admin')->middleware(['adminauth'])->group(function () {
         Route::get('/home', 'AdminController@index')->name('adminHome');
         Route::get("/tableCreate", 'AdminController@tableCreate')->name("tableCreate");
         Route::get("/postCreate", 'AdminController@postCreate')->name("postCreate");
         Route::post("/postArticle", 'PostController@postArticle')->name("postArticle");
         Route::post("/postable", 'PostController@addTable')->name("postCreateTable");
         Route::post("/addcolumn", 'PostController@addTable')->name("postAddColumn");
         
         Route::prefix('table')->group(function () {
            Route::get('/{name}', 'AdminController@table');
            //            Route::get('/{name}/addcolumn', 'AdminController@tableColCreate');
            Route::get('/{name}/delete/{id}', 'AdminController@rowDelete');
            Route::get('/{name}/edit/{id}', 'AdminController@rowEdit');
            Route::get('/{name}/add', 'AdminController@rowInsert');
            Route::post('/{name}/add', 'PostController@rowAdd');
            Route::post('/{name}/update/{id}', 'PostController@rowEdit');
         });
         
      });
   });
   
   Route::namespace("Member")->prefix("member")->group(function () {
      Route::get("/", "MemberController@index")->name("member.home");
      Route::get("/me", "MemberController@me")->name("member.profile");
      Route::get("/blogs", "MemberController@blog")->name("member.blog");
      Route::get("/{member_name}", "MemberController@profile");
      Route::get("/{member_name}/projects", "MemberController@projects");
      Route::namespace("Profile")->group(function(){
         Route::prefix("add")->group(function(){
            Route::post("/add/friend", "PostController@addUser")->name("add.friends");
            Route::post("/remove/friend", "PostController@removeUser")->name("remove.friends");
         });
      });
      // Route::get("/{member_name}/project/{projects_name}", "MemberController@project_focus");
      Route::namespace("Projects")->group(function () {
         //blog profile page
         Route::get("/blog/{project_name}/writer", "ProjectsController@articleWriter");//blog article writer page
         Route::get("/blog/info/{project_name}", "ProjectsController@articleInfo");//blog edit list article update page
         Route::get("/blog/update/{project_name}/{id}", "ProjectsController@articleUpdater");//blog article update page
         Route::namespace("Blog")->group(function () {
            //proje blog view
            Route::get("/{project_name}/blog", "BlogController@index");
            Route::get('/{project_name}/blog/article/{name}', 'BlogController@article');
            Route::get('/{project_name}/blog/category/{name}', 'BlogController@blog');
            //proje blog posted
            Route::prefix("blog")->group(function () {
               Route::post("/comment", "PostController@addComment")->name("commentPost");
               Route::post("/comment/delete", "PostController@commentDelete")->name("comment.delete");//blog comment delete post
               Route::post("/comment/update", "PostController@commentUpdate")->name("comment.update");
               Route::post("/article", "PostController@blogPost")->name("blog.article.post");
               Route::post("/article/update", "PostController@articleUpdate")->name("blog.article.post.update");
               Route::get("/article/delete/{id}", "PostController@articleDelete")->where('id', '[0-9]+');
               Route::any("/search", "PostController@search")->name("search");
               Route::post("/like", "PostController@like")->name("article.like");
            });
         });
   
         //projects profile page
         Route::get("/{member_name}/project/{project_name}", "ProjectsController@project_view");
         Route::get("/{member_name}/project/{projects_name}/{category_name}", "ProjectsController@docs");
         Route::get("/{member_name}/project/{projects_name}/{category_name}/{libary_name}", "ProjectsController@libary");
         //edit view table
         Route::prefix("editable")->group(function () {
            Route::get("/project", "ProjectsController@editable_project")->name("editable_project");
            Route::get("/category", "ProjectsController@editable_category")->name("editable_category");
            Route::get("/libary", "ProjectsController@editable_libaries")->name("editable_libary");
            Route::get("/libary_content", "ProjectsController@editable_libary_content")->name("editable_libary_content");
            Route::get("/libary_notes", "ProjectsController@editable_libary_notes")->name("editable_libary_notes");
         });
         Route::prefix("create")->group(function () {
            //view create form
            Route::get("/project", "ProjectsController@project")->name("create_project");
            Route::get("/category", "ProjectsController@category")->name("create_category");
            Route::get("/libary", "ProjectsController@libaries")->name("create_libary");
            Route::get("/libary_content", "ProjectsController@libary_content")->name("create_libary_content");
            Route::get("/libary_notes", "ProjectsController@libary_notes")->name("create_libary_notes");
            //create post form
            Route::post("/new/project", "PostController@project")->name("create_post_project");
            Route::post("/new/category", "PostController@category")->name("create_post_category");
            Route::post("/new/libary", "PostController@libary")->name("create_post_libary");
            Route::post("/new/libary_content", "PostController@libary_content")->name("create_post_libary_content");
            Route::post("/new/libary_notes", "PostController@libary_notes")->name("create_post_libary_notes");
         });
         Route::prefix("search")->group(function () {
            Route::get("/project", "PostController@project_search")->name("search_project");
            Route::get("/category", "PostController@project_category_search")->name("search_project_category");
            Route::get("/libary", "PostController@project_libary_search")->name("search_project_lib");
            Route::get("/content", "PostController@project_libary_content_search")->name("search_project_lib_content");
            
            Route::get("/project-editable", "PostController@project_search_editable")->name("search_project_editable");
            Route::get("/category-editable", "PostController@project_category_search_editable")->name("search_project_category_editable");
            Route::get("/libary-editable", "PostController@project_libary_search_editable")->name("search_project_lib_editable");
            Route::get("/content-editable", "PostController@project_libary_content_search_editable")->name("search_project_lib_content_editable");
            Route::get("/notes-editable", "PostController@project_libary_notes_search_editable")->name("search_project_lib_notes_editable");
         });
         
         Route::prefix("edit")->group(function () {
            //edit view form
            Route::get("/projects/{id}", "ProjectsController@e_project");
            Route::get("/category/{id}", "ProjectsController@e_category");
            Route::get("/libary/{id}", "ProjectsController@e_libaries");
            Route::get("/libary_content/{id}", "ProjectsController@e_libary_content");
            Route::get("/libary_notes/{id}", "ProjectsController@e_libary_notes");
            //edit form
            Route::post("/update/project/{id}", "PostController@e_project");
            Route::post("/update/category/{id}", "PostController@e_category");
            Route::post("/update/libary/{id}", "PostController@e_libary");
            Route::post("/update/libary_content/{id}", "PostController@e_libary_content");
            Route::post("/update/libary_notes/{id}", "PostController@e_libary_notes");
         });
         Route::prefix("delete")->group(function () {
            //edit view form
            Route::post("/projects/{id}", "ProjectsController@delete_project");
            Route::post("/category/{id}", "ProjectsController@delete_category");
            Route::post("/libary/{id}", "ProjectsController@delete_libaries");
            Route::post("/libary_content/{id}", "ProjectsController@delete_libary_content");
            Route::post("/libary_notes/{id}", "ProjectsController@delete_libary_notes");
         });
         
         // ajax request and response
         Route::get("/project_all_info", "PostController@project_all_info")->name("project_all_info");
      });
   });