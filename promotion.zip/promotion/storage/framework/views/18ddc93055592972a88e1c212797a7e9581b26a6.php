<!doctype html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>
        <?php if(isset($title)): ?>
            <?php echo $title; ?>

        <?php else: ?>
            Hoş geldiniz
        <?php endif; ?>
    </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset("css/comeback.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/projects/projects.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/projects/highlighter.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/member/profile.css")); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.5.1/themes/prism.min.css">
    <?php if(str_contains(url()->full(),['create',"edit"])): ?>
        <script type="text/javascript" src="<?php echo e(asset("ckeditor/ckeditor.js")); ?>"></script>

    <?php endif; ?>
    <?php echo $__env->yieldContent("up"); ?>
</head>
<body style="background: #f9f9f9;">
<nav class="navbar dark no-shadow mb-50">
    <div class="navbar-panel justify-content-xl-center justify-content-md-between">
        <h5 class="text bold">ZERONE DESING </h5>
        <a href="#!" class="collapse-toggle" data-collapse="navbar" data-href="navbar-dark">
            <i class="fa fa-bars"></i></a>
    </div>
    <div class="navbar-collapse " data-id="navbar-dark">
        <ul class="nav-item right collapse">

            <?php if(!is_null(Auth::user())): ?>

                <li class="item"><a href="<?php echo e(route("home")); ?>"><i class="icon-home text lg"></i></a></li>
                <li class="item dropdown">
                    <a href="#" class="dropdown-toggle icon-bell text lg" ></a>
                    <ul class="dropdown-menu p-0" id="notifycationMenu">
                        <li class="item"></li>
                    </ul>
                </li>
                <li class="item dropdown">
                    <a href="#" class="dropdown-toggle icon-message-circle text lg"></a>
                    <ul class="dropdown-menu p-0">
                        <li class="item"></li>
                    </ul>
                </li>
                <li class="item"><a href="<?php echo e(url("/member/".Auth::user()->nick_name."/projects")); ?>">Projeler</a></li>

                <li class="item dropdown">
                    <a href="#" class="dropdown-toggle">
                        <?php echo e(str_limit(Auth::user()->name ,8)); ?> <span class="icon-chevron-down"></span>
                    </a>
                    <ul class="dropdown-menu p-0">
                        <li class="item"><a href="<?php echo e(url("member/".Auth::user()->nick_name)); ?>">
                                <i class="icon-home text-green text lg mr-10"></i>Profilime git</a></li>
                        <li class="item">
                            <a href="<?php echo e(route('member.logout')); ?>"
                               onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                <i class="icon-log-out text-red text lg mr-10"></i> Oturumu kapat
                            </a>
                            <form id="logout-form" action="<?php echo e(route('member.logout')); ?>" method="POST"
                                  style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </li>
                    </ul>
                </li>
            <?php else: ?>

                <li class="item"><a href="<?php echo e(route("home")); ?>"><i class="icon-home text lg mr-10"></i>Anasayfa</a></li>
                <li class="dropdown item ">
                    <a href="#!" class="dropdown-toggle text-white">Giriş Yap</a>
                    <div class="dropdown-menu">
                        <form action="<?php echo e(route("member.login.submit")); ?>" method="post" class="w-full">
                            <h5 class="text-default">Giriş formu</h5><br>
                            <?php echo e(csrf_field()); ?>

                            <div class="field line flex-column mt-0 mb-0">
                                <h6 class="icon-mail mb-0 text left"> Email adresiniz</h6>
                                <input type="email" name="email" required minlength="4" autofocus>
                            </div>
                            <div class="field line flex-column mt-20 mb-0">
                                <h6 class="icon-unlock mb-0 text left"> Kullanıcı Şifreniz</h6>
                                <input type="password" name="password" required>
                            </div>
                            <div class="field mb-0 ">
                                <input type="submit" value="Giriş yap" class="btn btn-md btn-success">
                            </div>
                        </form>
                    </div>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<div class="container">
    <div class="wrap xl-top xl-flexbox xl-around xl-gutter-24 md-gutter-0">
        <div class="col xl-5-7 md-1-1">
            <?php echo $__env->yieldContent('content'); ?>

        </div>
        <div class="col xl-2-7 md-1-1">
            <section class="field search w-full mt-10 mb-0">
                <label for="searchput"></label><input class="input-search rad-3 w-full br-0" type="text" id="searchput" data-search="true" placeholder="Ara...">
            </section>
            <div class="scrollspy search_content mb-10 bg-white p-10 " style="overflow-y: hidden;max-height: 300px;">
                <ul class="list search_list w-full  rad-0"></ul>
            </div>
            <div class="mb-10"></div>

            <section class="wrap xl-flexbox xl-top xl-1 ">
                <div class="col p-10 bg-white">
                    <h3>Son yazılar
                        <div class="bg-success" style=" width: 80px;height: 3px;"></div>
                    </h3>
                    <div class="mt-20"></div>
                    <?php $__currentLoopData = $pop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $populars): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <aside class="wrap xl-flexbox xl-gutter-16 mt-10">
                            <div class="col xl-1-4 md-1-8">
                                <img src="<?php echo e($populars->picture); ?>" alt="" width="60" height="60">
                            </div>
                            <div class="col xl-3-4  md-7-8">
                                <a href="<?php echo e(url("/blog/".str_replace(" ","-",$populars->title))); ?>" class="text md"><?php echo e($populars->title); ?></a><br>
                                <div class="wrap xl-middle xl-gutter-8 ">
                                    <img src="<?php echo e($populars->author_picture); ?>" class="circle" width="25" alt="">
                                    <span><?php echo e($populars->author); ?> </span><span>/</span><span><?php echo e($populars->kind); ?> </span></div>
                                <a href="<?php echo e(url("/blog/article/".$populars->seo_url)); ?>" class="text xs">Daha fazla oku...</a>
                            </div>
                        </aside>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mt-20"></div>
                <div class="col bg-white p-10">
                    <h3>sosyal medya
                        <div class="bg-purple" style=" width: 80px;height: 3px;"></div>
                    </h3>
                    <div class="d-flex justify-content-around mt-20">
                        <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($cont->facebook); ?>" class="btn btn-circle btn-primary hover-line"><i class="icon-facebook text lg"></i></a>
                            <a href="<?php echo e($cont->twitter); ?>" class="btn btn-circle btn-info hover-line"><i class="icon-twitter text lg"></i></a>
                            <a href="<?php echo e($cont->instagram); ?>" class="btn btn-circle btn-purple hover-line"><i class="icon-instagram text lg"></i></a>
                            <a href="<?php echo e($cont->github); ?>" class="btn btn-circle btn-dark hover-line"><i class="icon-github text lg"></i></a>
                            <a href="<?php echo e($cont->codepen); ?>" class="btn btn-circle btn-sublime hover-line"><i class="icon-codepen text lg"></i></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <div class="col mt-20"></div>
                <div class="col bg-white p-20">
                    <h3>Kategori
                        <div class="bg-rose" style=" width: 80px;height: 3px;"></div>
                    </h3>

                    <div class="mt-10 ">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url("/member/".Request()->segment(2)."/blog/category/".$cat->category_name)); ?>" class="text-default text sm"><?php echo e($cat->category_name); ?> (<?php echo e($cat->category_len); ?>)</a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>

<script type="text/javascript" src="<?php echo e(asset("js/comeback.js")); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset("js/jqueryAjax.js")); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset("js/ajax.js")); ?>"></script>
</body>

</html>