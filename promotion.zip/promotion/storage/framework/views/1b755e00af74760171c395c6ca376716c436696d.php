<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="pack xl-between">
            <h5 class="text default"><i class="icon-tag mr-10"></i>İçerik oluştur</h5>
             <a href="<?php echo e(route("create_libary_notes")); ?>" class="btn-md btn btn-rose">içerik notları oluştur <i class="icon-chevron-right"></i></a>
        </div>
        <?php echo $__env->make("member.projects.status.project", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <form action="<?php echo e(route("create_post_libary_content")); ?>" method="post" class="d-flex flex-column">
            <?php echo e(csrf_field()); ?>

            <div class="field line mb-0 dropdown">
                <input type="text" class="dropdown-toggle" name="framework_name" id="framework_name"
                       onkeypress="query_project('<?php echo e(route("search_project")); ?>')" placeholder="Hangi framework için...">
                <ul class="dropdown-menu mt-50 switch_list" id="project_search"></ul>
            </div>

            <div class="field line mb-0 dropdown">
                <input type="text" class="dropdown-toggle" name="category_name" id="category_name"
                       onkeypress="query_project_category('<?php echo e(route("search_project_category")); ?>')"
                       placeholder="kategori adını yazın...">
                <ul class="dropdown-menu mt-50 switch_list" id="project_category_search"></ul>
            </div>
            <div class="field line  mb-0 dropdown">
                <input type="text" class="dropdown-toggle" name="libary_name" id="libary_name"
                       onkeypress="query_project_libary('<?php echo e(route("search_project_lib")); ?>')"
                       placeholder="libary Alanını doldurun...">
                <ul class="dropdown-menu mt-50 switch_list" id="project_libary_search"></ul>
            </div>
            <div class="field line mt-0">
                <input type="text" name="name" placeholder="İçerik isim Alanını doldurun...">
            </div>
            <div class="field line">
                <h4 class="w-full" style="position: absolute;margin-top: -30px;">explanation Alanını doldurun</h4>
                <textarea name="explanation" id="explanation" class="w-full" rows="10" placeholder="" style="visibility: hidden; display: none;"></textarea>
                <script>
                    CKEDITOR.replace('explanation',{
                        customConfig: '<?php echo e(asset("ckeditor/adminConfig.js")); ?>',width :'100%'
                    });
                </script>
            </div>
            <div class="field line">
                <textarea name="examples" class="w-full" rows="10" placeholder="examples Alanını doldurun"></textarea>
            </div>


            <input type="submit" class="btn btn-md btn-primary" value="Yeni satır ekle">
        </form>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('member.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>