<?php $__env->startSection("content"); ?>
    <?php echo $__env->make("member.part.user.article_list", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("rightnav"); ?>
    <?php echo $__env->make("member.part.user.projects_info", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("member.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>