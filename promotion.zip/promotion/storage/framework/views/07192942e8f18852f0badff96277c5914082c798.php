<?php $__env->startSection('content'); ?><div class="container">
    <div class="pack xl-between">
        <h5 class="text default"><i class="icon-tag mr-10"></i>Kütüphane oluştur</h5>
        <a href="<?php echo e(route("create_libary_content")); ?>" class="btn-md btn btn-rose"> kütüphane içeriği oluştur <i class="icon-chevron-right"></i></a>
    </div>
    <?php echo $__env->make("member.projects.status.project", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <form action="<?php echo e(route("create_post_libary")); ?>" method="post" class="d-flex flex-column">
        <?php echo e(csrf_field()); ?>

        <div class="field line mb-0 dropdown">
            <input type="text" class="dropdown-toggle" name="framework_name" id="framework_name"
                   onkeypress="query_project('<?php echo e(route("search_project")); ?>')" placeholder="Hangi framework için...">
            <ul class="dropdown-menu mt-50 switch_list" id="project_search"></ul>
        </div>

        <div class="field line mb-0 dropdown">
            <input type="text" class="dropdown-toggle" name="category_name" id="category_name"
                   onkeypress="query_project_category('<?php echo e(route("search_project_category")); ?>')"
                   placeholder="kategori adını yazın...">
            <ul class="dropdown-menu mt-50 switch_list" id="project_category_search"></ul>
        </div>

        <div class="field line">
            <input type="text" name="name" placeholder="name Alanını doldurun...">
        </div>

        <div class="field line">
        </div>
        <div class="field line">
            <h4 class="w-full" style="position: absolute;margin-top: -30px;">İçerik Alanını doldurun</h4>
            <textarea name="text" id="text" class="w-full" rows="10" placeholder="" style="visibility: hidden; display: none;"></textarea>
            <script>
                CKEDITOR.replace('text',{
                    customConfig: '<?php echo e(asset("ckeditor/adminConfig.js")); ?>',width :'100%'
                });
            </script>
        </div>
        <input type="submit" class="btn btn-md btn-primary" value="Yeni satır ekle">
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('member.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>