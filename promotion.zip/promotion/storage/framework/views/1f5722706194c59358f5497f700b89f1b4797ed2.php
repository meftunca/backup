<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mu frontend framework</title>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset("css/comeback.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/projects/projects.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/projects/highlighter.css")); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.5.1/themes/prism.min.css">
</head>
<body>
<nav class="navbar dark no-shadow">
    <div class="navbar-panel justify-content-xl-center justify-content-md-between">
        <h5 class="text bold">ZERONE
            <span class="text-blue">
                    <i class="icon-chevron-left text-info text md mr--10"></i>
                    <i class="icon-minus text-blue text md"></i>
                    <i class="icon-chevron-right text-info text md ml--10"></i>
                </span> DESING</h5>
        <a href="#!" class="collapse-toggle" data-collapse="navbar" data-href="navbar-dark">
            <i class="fa fa-bars"></i></a>
    </div>
    <div class="navbar-collapse " data-id="navbar-dark">
        <ul class="nav-item right collapse">

            <?php if(auth()->guard()->guest()): ?>
                <li class="item"><a href="<?php echo e(route("home")); ?>"><i class="icon-home text lg mr-10"></i>Anasayfa</a></li>
                <li class="dropdown item ">
                    <a href="#!" class="dropdown-toggle text-white">Giriş Yap</a>
                    <div class="dropdown-menu">
                        <form action="<?php echo e(route("member.login.submit")); ?>" method="post" class="w-full">
                            <h5 class="text-default">Giriş formu</h5><br>
                            <?php echo e(csrf_field()); ?>

                            <div class="field line flex-column mt-0 mb-0">
                                <h6 class="icon-mail mb-0 text left"> Email adresiniz</h6>
                                <input type="email" name="email" required minlength="4" autofocus>
                            </div>
                            <div class="field line flex-column mt-20 mb-0">
                                <h6 class="icon-unlock mb-0 text left"> Kullanıcı Şifreniz</h6>
                                <input type="password" name="password" required>
                            </div>
                            <div class="field mb-0 ">
                                <input type="submit" value="Giriş yap" class="btn btn-md btn-success">
                            </div>
                        </form>
                    </div>
                </li>

            <?php else: ?>
                <li class="item"><a href="<?php echo e(route("home")); ?>"><i class="icon-home text lg"></i></a></li>
                <li class="item dropdown">
                    <a href="#" class="dropdown-toggle icon-bell text lg"></a>

                    <ul class="dropdown-menu p-0">
                        <li class="item"></li>
                    </ul>
                </li>
                <li class="item dropdown">
                    <a href="#" class="dropdown-toggle icon-message-circle text lg"></a>
                    <ul class="dropdown-menu p-0">
                        <li class="item"></li>
                    </ul>
                </li>
                <li class="item"><a href="<?php echo e(url("/member/".Auth::user()->nick_name."/projects")); ?>">Projeler</a></li>
                <li class="item"><a href="<?php echo e(url("/member/blog/".Request()->segment(4))); ?>">Blog</a></li>

                <li class="item dropdown">
                    <a href="#" class="dropdown-toggle">
                        <?php echo e(str_limit(Auth::user()->name ,8)); ?> <span class="icon-chevron-down"></span>
                    </a>
                    <ul class="dropdown-menu p-0">
                        <li class="item"><a href="<?php echo e(url("member/".Auth::user()->nick_name)); ?>">
                                <i class="icon-home text-green text lg mr-10"></i>Profilime git</a></li>
                        <li class="item">
                            <a href="<?php echo e(route('member.logout')); ?>"
                               onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                <i class="icon-log-out text-red text lg mr-10"></i> Oturumu kapat
                            </a>
                            <form id="logout-form" action="<?php echo e(route('member.logout')); ?>" method="POST"
                                  style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </li>
                    </ul>
                </li>
            <?php endif; ?>

        </ul>
    </div>
</nav>

<div class="block h-50 lg-hidden"></div>
<div class="wrap xl-top xl-gutter-40 xl-outside-40 md-gutter-0 md-outside-0">
    <div class="col xl-1-5 md-1-1">
        <?php echo $__env->make("projects.part.leftNav", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col xl-3-5 md-1-1">
            <?php echo $__env->yieldContent("content"); ?>
    </div>
    <div class="col xl-1-5 md-hidden">
        <?php echo $__env->yieldContent("rightnav"); ?>
    </div>
</div>



<script type="text/javascript" src="<?php echo e(asset("js/comeback.js")); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.5.1/prism.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.8.3/plugins/toolbar/prism-toolbar.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.7.1/clipboard.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset("js/projects/projects.js")); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.5.1/prism.js"></script>
</body>

</html>