
<?php $__env->startSection("leftnav"); ?>
    <div class="list">
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="item">
                <div class="wrap xl-flexbox xl-gutter-16">
                    <div class="col xl-1-4">
                        <img src="<?php echo e($project->logo); ?>" alt="" class="img-embed">
                    </div>
                    <div class="col xl-3-4">
                        <a href="projects/<?php echo e($project->seo_url); ?>"
                           class="text-gray text md"><?php echo e($project->name); ?></a>
                    </div>
                </div>
            </section>
            <ul class="list-accordion br-0 ">
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="item align-items-start br-0">
                            <a href="<?php echo e(url('projects/docs/'.$project->seo_url."/".$categories->seo_url)); ?>"><?php echo e($categories->name); ?></a>
                        </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $project->text; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("rightnav"); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("projects.projectMaster", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>