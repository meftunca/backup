<?php $__env->startSection('content'); ?>
        <div class="wrap xl-flexbox xl-top xl-masonry-2 xl-gutter-24 md-gutter-0">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $write): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col xl-1-2 md-1-1">
                    <section class="card br-0">
                        <div class="card-header">
                            <section class="pack image mt-10">
                                <section class="group-content">
                                    <img src="<?php echo e($write->author_picture); ?>" alt="" class="group m-0 circle mr-20">
                                    <aside class="group m-0">
                                        <span class=" text sm"><?php echo e($write->author); ?></span><br> <span class=" text sm"><?php echo e($write->kind); ?></span>
                                    </aside>
                                    <span class="group m-0 right">
                                    <?php
                                        \Carbon\Carbon::setLocale('tr');
                                     echo \Carbon\Carbon::parse($write->created_at)->diffForHumans();
                                    ?>
                                </section>
                            </section>
                        </div>
                        <div class="card-body">
                            <img src="<?php echo e($write->picture); ?>"
                                 class="img-embed" alt="">
                            <div class="card-block">
                                <h6 class="card-subtitle p-10 mb-0"><?php echo e($write->title); ?></h6>
                                <div class="card-text">
                                    <div class="p-10">
                                        <?php echo e( str_limit($write->text,150)); ?>

                                    </div>
                                    <a href="<?php echo e(url("/blog/article/".$write->seo_url)); ?>" class="text-gren ml-20">Devamını oku</a>

                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="wrap xl-flexbox xl-around xl-3 xl-center p-10">

                                <a class="col" href="#!"><i class="icon-thumbs-up text md"></i> <span class="text sm m-10"> Beğen</span></a>
                                <a class="col" href="<?php echo e(url("/blog/article/".$write->seo_url)); ?>"><i class="icon-message-square text md"></i> <span class="text sm m-10"> Yorum yap</span></a>
                                <a class="col" href="#!"><i class="icon-share text md"></i> <span class="text sm m-10">Paylaş</span></a>
                            </div>
                        </div>
                    </section>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="h-50 md-hidden"></div>
        <div class="wrap xl-center m-20">
            <nav class="bg-white" aria-label="pagination " role="navigation">
                <?php echo e($paginate->links()); ?>

            </nav>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>