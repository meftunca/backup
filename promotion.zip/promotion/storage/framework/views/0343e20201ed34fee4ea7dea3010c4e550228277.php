<div class="wrap xl-flexbox xl-center xl-1">
    <div class="col mb-20">
        <section class="wrap xl-center xl-3">
            <div class="col"><a href="#" class="icon-award text-success text lg"></a></div>
            <div class="col"><a href="#" class="icon-star text-warning text lg"></a></div>
            <div class="col"><a href="#" class="icon-trending-up text-rose text lg"></a></div>
        </section>
    </div>
    <div class="col">
        <ul class="list line mt-0">
            <li class="item p-10"><a>
                    <i class="icon-grid ml-10 mr-10 text md  text-sublime"></i>
                    <span class="text md text-black">Proje Oluşturucu</span></a></li>
            <li class="item p-10"><a href="<?php echo e(route("create_project")); ?>">
                    <i class="icon-bookmark ml-10 mr-10 text md text-green"></i>
                    <span class="text text-black">Projele oluştur</span></a></li>
            <li class="item p-10"><a href="<?php echo e(route("create_category")); ?>">
                    <i class="icon-bookmark ml-10 mr-10 text md text-green"></i>
                    <span class="text text-black">Proje için kategori oluştur</span></a></li>
            <li class="item p-10"><a href="<?php echo e(route("create_libary")); ?>">
                    <i class="icon-bookmark ml-10 mr-10 text md text-green"></i>
                    <span class="text text-black">Projen için kütüphane oluştur</span></a></li>
            <li class="item p-10"><a href="<?php echo e(route("create_libary_content")); ?>">
                    <i class="icon-bookmark ml-10 mr-10 text md text-green"></i>
                    <span class="text text-black">Projen için kütüphane içerik oluştur</span></a></li>
            <li class="item p-10"><a href="<?php echo e(route("create_libary_notes")); ?>">
                    <i class="icon-bookmark ml-10 mr-10 text md text-green"></i>
                    <span class="text text-black">Projen için içerik notu oluştur</span></a></li>

            <li class="item p-10"><a>
                    <i class="icon-grid ml-10 mr-10 text md text-sublime"></i>
                    <span class="text md text-black">Proje Düzenle veya sil</span></a></li>
            <li class="item p-10"><a href="<?php echo e(route('editable_project')); ?>">
                    <i class="icon-edit ml-10 mr-10 text md  text-purple"></i>
                    <span class="text text-black">Projeni düzenle</span></a></li>
            <li class="item p-10"><a href="<?php echo e(route('editable_category')); ?>">
                    <i class="icon-edit ml-10 mr-10 text md  text-purple"></i>
                    <span class="text text-black">Proje için kategori düzenle</span></a></li>
            <li class="item p-10"><a href="<?php echo e(route('editable_libary')); ?>">
                    <i class="icon-edit ml-10 mr-10 text md  text-purple"></i>
                    <span class="text text-black">Projen için kütüphane düzenle</span></a></li>
            <li class="item p-10"><a href="<?php echo e(route('editable_libary_content')); ?>">
                    <i class="icon-edit ml-10 mr-10 text md  text-purple"></i>
                    <span class="text text-black">Projen için kütüphane içerik düzenle</span></a></li>
            <li class="item p-10"><a href="<?php echo e(route('editable_libary_notes')); ?>">
                    <i class="icon-edit ml-10 mr-10 text md  text-purple"></i>
                    <span class="text text-black">Projen için içerik notu düzenle</span></a></li>
         </ul>
        <section class="field search w-full mt-10 mb-0">
            <label for="search_project"></label><input class="input-search rad-3 w-full br-0" onkeypress="query_project_all('<?php echo e(route("project_all_info")); ?>')" type="text" id="search_project" data-search="true" placeholder=" proje içinde Ara...">
        </section>
        <div class="scrollspy search_content mb-10 card p-10 " id="search_project_content" style="overflow-y: hidden;max-height: 300px;">
            <ul class="list search_list w-full rad-0" id="search_project_all_info"></ul>
        </div>
    </div>
</div>
