<?php $__env->startSection('content'); ?>
    <h5>Proje Kategorilerinde Ara !!!</h5>
    <ul class="list line box" style="overflow: visible">
        <div class="field search  mb-0">
            <input type="text"  name="category_name" id="category_name"
                   onkeypress="query_project_category('<?php echo e(route("search_project_category_editable")); ?>')"
                   placeholder="kategori adını yazın...">
        </div>
        <ul class="list box line mt-10 p-0 switch_list w-full" id="project_category_search"></ul>

    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('member.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>