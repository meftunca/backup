<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col h-100"></div>
    <section class="wrap xl-flexbox xl-center">
        <div class="col xl-3-4 md-4-5">
            <h5 class="text-gray">Admin! oturum açma ekranı</h5>
            <form class="mt-0 w-full" method="POST" action="<?php echo e(route('admin.login.submit')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="field m-0 <?php echo e($errors->has('email') ? ' has-error' : ''); ?>"> <label for="email"></label>
                    <input  id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                </div>
                <?php if($errors->has('email')): ?>
                    <p class="text xs text-orange">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </p>
                <?php endif; ?>
                <div class="field mb-0 <?php echo e($errors->has('password') ? ' has-error' : ''); ?>"> <label for="password"></label>
                    <input id="password" type="password" class="form-control" name="password" required>

                </div>
                <?php if($errors->has('email')): ?>
                    <p class="text xs text-red">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </p>
                <?php endif; ?>


                <div class="field mt-0">
                    <div class="group info ">
                        <input type="checkbox" checked="" id="remember" class="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        <label for="remember" class="checkbox"></label>
                    </div>
                    <div class="group ml-20">
                        <p class="text sm text-info">Beni hatırla</p>
                    </div>
                </div>

                <div class="field line m-0">
                        <button type="submit" class="btn btn-primary">
                            Login
                        </button>

                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                            Forgot Your Password?
                        </a>
                </div>
            </form>
        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>