<div class="wrap xl-1">
    <div class="col mb-20"><h2 class="text-default text bold">Harika ! <small>Projelerin seni bekliyor...</small></h2></div>
    <section class="col">
        <div class="wrap xl-2 md-1 xl-center xl-gutter-24 xl-outside-24 md-gutter-0 md-outside-0">
            <?php if(count($projects) < 1): ?>
                <div class="col mt-50">
                    <h5 class="text-default text bold"><i class="icon-alert mr-10"></i>Maalesef daha proje
                        oluşturmamışsınız.
                        <br> <a href="<?php echo e(route("create_project")); ?> " class='text-info'>Proje oluşturmak için tıklayın</a>
                    </h5>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <section class="card p-10">
                            <aside class="pack justify-content-between">
                                <a href="#!" class="text-gray"><span class="icon icon-heart text md"></span></a>
                                <h6><?php echo $project->name; ?></h6>
                                <div class="dropdown">
                                    <a href="#!" class="text-gray dropdown-toggle"><span
                                                class="icon icon-more-vertical text md"></span></a>
                                    <ul class="dropdown-menu right">
                                    </ul>
                                </div>
                            </aside>
                            <br>
                            <img src="<?php echo $project->logo; ?>" alt="" class="card-img">
                            <div class="card-block text center-all">
                                <p class="text-gray text sm"><?php echo str_limit($project->text,"300"); ?></p>
                            </div>
                            <div class="card-block text center-all">
                                <aside class="pack justify-content-between">
                                    <a href="<?php echo e(url("/member/".Auth::user()->nick_name."/project/".$project->name)); ?>"
                                       class="text-blue">Proje'ye Git</a>
                                    <span>
                                    <?php
                                        \Carbon\Carbon::setLocale('tr');
                                     echo \Carbon\Carbon::parse($project->created_at)->diffForHumans();
                                    ?>
                                </span>
                                </aside>
                            </div>
                        </section>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
    </section>

</div>