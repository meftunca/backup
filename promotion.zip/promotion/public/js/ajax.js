function switch_list(item) {
    var str = item.innerHTML,
        attr_name = item.getAttribute("data-input-name");
    document.querySelector("#" + attr_name).value = str;
}

function query_project(url) {
    var xhttp = new XMLHttpRequest();
    var str = document.querySelector("[name=framework_name]").value;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("project_search").innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", url + "?query=" + str, true);
    xhttp.send();
}

function query_project_category(url) {
    var xhttp = new XMLHttpRequest();
    var str = document.querySelector("[name=category_name]").value;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("project_category_search").innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", url + "?query=" + str, true);
    xhttp.send();
}

function query_project_libary(url) {
    var xhttp = new XMLHttpRequest();
    var str = document.querySelector("#category_name").value;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("project_libary_search").innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", url + "?query=" + str, true);
    xhttp.send();
}

function query_project_libary_content(url) {
    var xhttp = new XMLHttpRequest();
    var str = document.querySelector("#content_name").value;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("project_libary_content_search").innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", url + "?query=" + str, true);
    xhttp.send();
}

function query_project_libary_notes(url) {
    var xhttp = new XMLHttpRequest();
    var str = document.querySelector("#notes_name").value;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("project_libary_notes_search").innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", url + "?query=" + str, true);
    xhttp.send();
}

var clear = document.querySelectorAll("input");
Array.prototype.forEach.call(clear, function (el) {
    el.onfocus = function (e) {
        if (e.target != el) {
            var search_list = document.querySelectorAll(".scrolspy.card");
            Array.prototype.forEach.call(search_list, function (li) {
                li.classList.add("xl-hidden");
            });
        } else {
        }
    }
});

function query_project_all(url) {
    var xhttp = new XMLHttpRequest();
    var str = document.querySelector("#search_project").value;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            if (this.responseText === str) {
                document.getElementById("search_project_all_info").innerHTML = "<li class='item text-default text bold'><i class='icon-alert-triangle mr-10'></i>Maalesef veri yok</li>";
            } else {
                document.getElementById("search_project_all_info").innerHTML = this.responseText;
            }
        }
    };
    xhttp.open("GET", url + "?query=" + str, true);
    xhttp.send();
}

function like_article(who,projectName, articleName, liker, liker_picture, url, target) {

$(function () {
   $("#"+target+"#"+target+" *").click(function () {
       var data = {who:who,project_name: projectName, article_name: articleName, liker: liker, liker_picture: liker_picture};
       $.ajaxSetup({
           headers: {
               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
           }
       });
       $.ajax({
           type: "POST",
           url: url,
           data: data,
           dataType: "JSON",
           success: function (data) {
               if (data.success) {
                   $("#"+target+">*").addClass("text-info");
               }
               else {
                   $("#"+target+">*").removeClass("text-info");
               }

           }
       });
   }) ;
});

}