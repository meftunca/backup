/**
 * ajax function
 * @param item
 */


function ajax(url, method, data, async, done) {
    method = typeof method !== 'undefined' ? method : 'GET';
    async = typeof async !== 'undefined' ? async : false;
    var xhReq = new XMLHttpRequest();

    if (method == 'POST') {
        xhReq.open(method, url, async);
        xhReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhReq.setRequestHeader("X-Requested-With", "XMLHttpRequest");
        if (document.querySelector('meta[name="csrf-token"]')) {
            xhReq.setRequestHeader('X-CSRF-TOKEN', document.querySelector('meta[name="csrf-token"]').getAttribute("content"));
        }
        if (typeof data === Object) {
            var query = [];
            for (var key in data) {
                query.push(encodeURIComponent(key) + '=' + encodeURIComponent(parameters[key]));
            }
            data = query.join('&');
        }
        xhReq.onreadystatechange = function () {

            if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
                data = this.responseText;
                if(typeof data === Object){
                    var data = JSON.parse(data);

                }
                 return done(data);
            }
        };
        xhReq.send(data);
    }
    else {
        if (typeof data !== 'undefined' && data !== null) {
            url = url + '?' + data;
        }
        xhReq.open(method, url, async);
        xhReq.setRequestHeader("X-Requested-With", "XMLHttpRequest");
        xhReq.send(null);
    }

}

function switch_list(item) {
    var str = item.innerHTML,
        attr_name = item.getAttribute("data-input-name");
    document.querySelector("#" + attr_name).value = str;
}

function query_project(url) {
    var xhttp = new XMLHttpRequest();
    var str = document.querySelector("[name=framework_name]").value;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("project_search").innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", url + "?query=" + str, true);
    xhttp.send();
}

function query_project_category(url) {
    var xhttp = new XMLHttpRequest();
    var str = document.querySelector("[name=category_name]").value;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("project_category_search").innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", url + "?query=" + str, true);
    xhttp.send();
}

function query_project_libary(url) {
    var xhttp = new XMLHttpRequest();
    var str = document.querySelector("#category_name").value;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("project_libary_search").innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", url + "?query=" + str, true);
    xhttp.send();
}

function query_project_libary_content(url) {
    var xhttp = new XMLHttpRequest();
    var str = document.querySelector("#content_name").value;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("project_libary_content_search").innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", url + "?query=" + str, true);
    xhttp.send();
}

function query_project_libary_notes(url) {
    var xhttp = new XMLHttpRequest();
    var str = document.querySelector("#notes_name").value;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("project_libary_notes_search").innerHTML = this.responseText;
        }
    };
    xhttp.open("GET", url + "?query=" + str, true);
    xhttp.send();
}

var clear = document.querySelectorAll("input");
Array.prototype.forEach.call(clear, function (el) {
    el.onfocus = function (e) {
        if (e.target != el) {
            var search_list = document.querySelectorAll(".scrolspy.card");
            Array.prototype.forEach.call(search_list, function (li) {
                li.classList.add("xl-hidden");
            });
        } else {
        }
    }
});

function query_project_all(url) {
    var xhttp = new XMLHttpRequest();
    var str = document.querySelector("#search_project").value;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            if (this.responseText === str) {
                document.getElementById("search_project_all_info").innerHTML = "<li class='item text-default text bold'><i class='icon-alert-triangle mr-10'></i>Maalesef veri yok</li>";
            } else {
                document.getElementById("search_project_all_info").innerHTML = this.responseText;
            }
        }
    };
    xhttp.open("GET", url + "?query=" + str, true);
    xhttp.send();
}

function friends_add(nick_name, url) {
     return ajax(url, 'POST', 'userName=' + nick_name, "async",function (data) {
         window.location.reload();
    });
}
function friends_remove(nick_name, url) {
    return ajax(url, 'POST', 'userName=' + nick_name, "async",function (data) {
        window.location.reload();
    });
}

function like_article(who, projectName, articleName, liker, liker_picture, url, target) {


    $(function () {
        $("#" + target + "#" + target + " *").click(function () {
            var data = {
                who: who,
                project_name: projectName,
                article_name: articleName,
                liker: liker,
                liker_picture: liker_picture
            };
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: url,
                data: data,
                dataType: "JSON",
                success: function (data) {
                    if (data.success) {
                        $("#" + target + ">*").addClass("text-info");
                    }
                    else {
                        $("#" + target + ">*").removeClass("text-info");
                    }

                }
            });
        });
    });

}