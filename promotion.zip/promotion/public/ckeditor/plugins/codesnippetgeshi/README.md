Code Snippet GeSHi Plugin
==================================================

For installation and configuration instructions go to the [Code Snippet GeSHi documentation](https://docs.ckeditor.com/ckeditor4/docs/#!/guide/dev_codesnippetgeshi) in the [CKEditor Developer's Guide](https://docs.ckeditor.com/ckeditor4/docs/#!/guide).
