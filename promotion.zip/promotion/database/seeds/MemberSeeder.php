<?php

use Illuminate\Database\Seeder;
use App\Http\Models\Member;

class MemberSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('member')->delete(); // admin tablosundaki tüm verileri sildik. DB sınıfını veya Eloquent model dosyamızı kullanabililirsiniz.
        DB::table('password_resets')->delete(); // Password_resets tablosundaki tüm verileri sildik.
        Member::create(['id'=>1,'name' => 'Buğra Güney','email' => 'e-bugra@bugraguney.com.tr', 'password' => Hash::make( '123456' )]); // Yeni bir admin oluşturmak için. Birden fazlada tanımlayabilirsiniz. alt satıra çoğaltarak.
    }
}
