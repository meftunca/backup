<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProjectCategoryLibaryContentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('project_category_libary_content', function (Blueprint $table) {
            $table->increments('id');
            $table->string ("seo_url");
            $table->string ("name");
            $table->text ("explanation");
            $table->text ("examples");
            $table->string ("libary_name");
            $table->string ("category_name");
            $table->string ("framework_name");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('project_category_libary_content');
    }
}
