<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProjectLibaryContentCreatorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('project_libary_content_creators', function (Blueprint $table) {
            $table->increments('id');
            $table->string("creator_nickname")->nullable(false);
            $table->string("project_name");
            $table->string("category_name");
            $table->string("libary_name");
            $table->string("libary_content_name");
            $table->integer("project_id")->nullable(false);
            $table->integer("category_id")->nullable(false);
            $table->integer("libary_id")->nullable(false);
            $table->integer("libary_content_id")->nullable(false);
            $table->tinyInteger("check")->default("0");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('project_libary_content_creators');
    }
}
