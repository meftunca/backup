<?php
   
   use Illuminate\Support\Facades\Schema;
   use Illuminate\Database\Schema\Blueprint;
   use Illuminate\Database\Migrations\Migration;
   
   class CreateMemberFollowTable extends Migration
   {
      /**
       * Run the migrations.
       *
       * @return void
       */
      public function up ()
      {
         Schema::create('member_follow', function (Blueprint $table) {
            $table->increments('id');
            $table->string("bidder");
            $table->string("collocutor");
            $table->tinyInteger("is_friends");
            $table->tinyInteger("confirmation");
            $table->timestamps();
         });
      }
      
      /**
       * Reverse the migrations.
       *
       * @return void
       */
      public function down ()
      {
         Schema::dropIfExists('member_follow');
      }
   }
