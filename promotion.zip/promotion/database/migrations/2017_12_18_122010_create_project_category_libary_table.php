<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProjectCategoryLibaryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('project_category_libary', function (Blueprint $table) {
            $table->increments('id');
            $table->string ("category_name");
            $table->string ("name")->unique();
            $table->string ("framework_name");
            $table->string ("seo_url");
            $table->text ("text");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('project_category_libary');
    }
}
