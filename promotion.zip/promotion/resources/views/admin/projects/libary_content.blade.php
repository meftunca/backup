@extends('layouts.app')

@section('content')
    <div class="container">
        <form action="{{route("create_post_libary_content")}}" method="post" class="d-flex flex-column">
            {{csrf_field()}}
            <div class="field line mb-0 dropdown">
                <input type="text" class="dropdown-toggle" name="framework_name" id="framework_name"
                       onkeypress="query_project('{{route("search_project")}}')" placeholder="Hangi framework için...">
                <ul class="dropdown-menu mt-50 switch_list" id="project_search"></ul>
            </div>

            <div class="field line mb-0 dropdown">
                <input type="text" class="dropdown-toggle" name="category_name" id="category_name"
                       onkeypress="query_project_category('{{route("search_project_category")}}')"
                       placeholder="kategori adını yazın...">
                <ul class="dropdown-menu mt-50 switch_list" id="project_category_search"></ul>
            </div>
            <div class="field line  mb-0 dropdown">
                <input type="text" class="dropdown-toggle" name="libary_name" id="libary_name"
                       onkeypress="query_project_libary('{{route("search_project_lib")}}')"
                       placeholder="libary Alanını doldurun...">
                <ul class="dropdown-menu mt-50 switch_list" id="project_libary_search"></ul>
            </div>
            <div class="field line mt-0">
                <input type="text" name="name" placeholder="İçerik isim Alanını doldurun...">
            </div>
            <div class="field line">
                <h4 class="w-full" style="position: absolute;margin-top: -30px;">explanation Alanını doldurun</h4>
                <textarea name="explanation" id="explanation" class="w-full" rows="10" placeholder="" style="visibility: hidden; display: none;"></textarea>
                <script>
                    CKEDITOR.replace('explanation',{
                        customConfig: '{{asset("ckeditor/adminConfig.js")}}',width :'100%'
                    });
                </script>
            </div>
            <div class="field line">
                <textarea name="examples" class="w-full" rows="10" placeholder="examples Alanını doldurun"></textarea>
            </div>


            <input type="submit" class="btn btn-md btn-primary" value="Yeni satır ekle">
        </form>

    </div>
@endsection