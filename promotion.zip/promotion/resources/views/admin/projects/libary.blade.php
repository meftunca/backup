@extends('layouts.app')

@section('content')<div class="container">
    <form action="{{route("create_post_libary")}}" method="post" class="d-flex flex-column">
        {{csrf_field()}}
        <div class="field line mb-0 dropdown">
            <input type="text" class="dropdown-toggle" name="framework_name" id="framework_name"
                   onkeypress="query_project('{{route("search_project")}}')" placeholder="Hangi framework için...">
            <ul class="dropdown-menu mt-50 switch_list" id="project_search"></ul>
        </div>

        <div class="field line mb-0 dropdown">
            <input type="text" class="dropdown-toggle" name="category_name" id="category_name"
                   onkeypress="query_project_category('{{route("search_project_category")}}')"
                   placeholder="kategori adını yazın...">
            <ul class="dropdown-menu mt-50 switch_list" id="project_category_search"></ul>
        </div>

        <div class="field line">
            <input type="text" name="name" placeholder="name Alanını doldurun...">
        </div>

        <div class="field line">
        </div>
        <div class="field line">
            <h4 class="w-full" style="position: absolute;margin-top: -30px;">İçerik Alanını doldurun</h4>
            <textarea name="text" id="text" class="w-full" rows="10" placeholder="" style="visibility: hidden; display: none;"></textarea>
            <script>
                CKEDITOR.replace('text',{
                    customConfig: '{{asset("ckeditor/adminConfig.js")}}',width :'100%'
                });
            </script>
        </div>
        <input type="submit" class="btn btn-md btn-primary" value="Yeni satır ekle">
    </form>

</div>
@endsection