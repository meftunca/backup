@extends('layouts.app')

@section('content')
    <div class="container">
        <form action="{{route("create_post_project")}}" method="post" class="d-flex flex-column">
            {{csrf_field()}}
            <div class="field line">
                <input type="text" name="name" placeholder="name Alanını doldurun...">
            </div>
            <div class="field line">
            </div>
            <div class="field line">
                <h4 class="w-full" style="position: absolute;margin-top: -30px;">text Alanını doldurun</h4>
                <textarea name="text" id="text" class="w-full" rows="10" placeholder="" style="visibility: hidden; display: none;"></textarea>
                <script>
                    CKEDITOR.replace('text',{
                        customConfig: '{{asset("ckeditor/adminConfig.js")}}',width :'100%'
                    });
                </script>
            </div>
            <div class="field line">
                <input type="text" name="logo" placeholder="logo Alanını doldurun...">
            </div>
            <input type="submit" class="btn btn-md btn-primary" value="Yeni satır ekle">
        </form>

    </div>
@endsection
@section("down")
    <script src="{{asset("js/ajax.js")}}"></script>
@endsection