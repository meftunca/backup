@extends('layouts.app')

@section('content')
    <div class="container">
        <form action="{{route("create_post_category")}}" method="post" class="d-flex flex-column">
            {{csrf_field()}}
            <div class="field line mb-0 dropdown">
                <input type="text" class="dropdown-toggle" name="framework_name" id="framework_name"
                       onkeypress="query_project('{{route("search_project")}}')" placeholder="Hangi framework için...">
                <ul class="dropdown-menu mt-50 switch_list" id="project_search"></ul>
            </div>

            <div class="field line mt-10">
                <input type="text" name="name" placeholder="Kategori adını yazın...">
            </div>
            <div class="field line">
                <h6 class="w-full" style="position: absolute;margin-top: -30px;">Aşağıdaki alana içeriği yazabilirsiniz</h6>
                <textarea name="text" id="text" class="w-full" rows="10" placeholder="" style="visibility: hidden; display: none;"></textarea>
                <script>
                    CKEDITOR.replace('text',{
                        customConfig: '{{asset("ckeditor/adminConfig.js")}}',width :'100%'
                    });
                </script>
            </div>
            <div class="field line">
            </div>
            <input type="submit" class="btn btn-md btn-primary" value="Yeni satır ekle">
        </form>

    </div>
@endsection
