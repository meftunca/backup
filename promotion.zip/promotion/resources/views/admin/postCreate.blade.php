@extends('layouts.app')

@section('content')

    <form action="{{url("/admin/table/$name/create")}}" method="post" class="w-full">
        {{csrf_field()}}
        <div class="field line">
            <input type="text" name="title" id="d4"><label class="label text lg" for="d4"><i class="icon-flag"></i> <span
                        class="ml-10 text md">Makalenize başlık yazın</span></label>
        </div>

        <div class="field line">
            <div class="fileput">
                <aside class="fileput-text">
                    Lütfen dosya seçmek için tıklayın
                    <button type="button" class="btn btn-sm btn-info fileput-btn">Dosya seç</button>
                </aside>
                <input type="file" name="image">
                <div class="fileput-list">
                    <ul class="list line"></ul>
                </div>
            </div>
        </div>

        <div class="field line">
            <textarea name="post" id="post" class="w-full" rows="10"></textarea>
        </div>
        <input type="submit" value="Makaleyi ekle" class="btn btn-lg btn-success">

    </form>

@endsection

@section("down")
    <script src="{{asset('ckeditor/ckeditor.js')}}"></script>
    <script>
        CKEDITOR.replace("post");
    </script>
@endsection