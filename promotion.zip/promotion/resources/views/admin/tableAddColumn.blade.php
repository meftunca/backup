@extends('layouts.app')

@section('content')
    <div class="container">
        <h5>Yeni kolon ekle</h5>
        <form action="{{route("postAddColumn")}}" method="post" class="w-full">
            {{csrf_field()}}
            <input type="hidden" name="tableName" value="{{$tableName}}">
            <div class="field line">
                <div class="wrap xl-3 xl-between md-1 xl-centers xl-gutter-24">
                    <div class="col">
                        <input type="text" name="colName" placeholder="Satır adı">
                    </div>
                    <div class="col">
                        <div class="dropdown">
                            <button class="btn btn-rose btn-md dropdown-toggle w-full" type='button' data-toggle="selectbox">karakter tipi</button>
                            <ul class="dropdown-menu" data-type="selectbox" input-name="type" input-value="">
                                <li select-value="string">String</li>
                                <li select-value="text">Text</li>
                                <li select-value="date">Date</li>
                                <li select-value="timestamps">Timestamps</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <input type="text" name="colLimit" placeholder="Satır genişliği">
                    </div>
                </div>
            </div>
            <input type="submit" class="btn btn-md btn-primary" value="Tablo oluştur">
        </form>
    </div>
@endsection
