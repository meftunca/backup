@extends('layouts.app')

@section('content')
<div class="container">
    <div class="col h-100"></div>
    <section class="wrap xl-flexbox xl-center">
        <div class="col xl-3-4 md-4-5">
            <h5 class="text-gray">Admin! oturum açma ekranı</h5>
            <form class="mt-0 w-full" method="POST" action="{{ route('admin.login.submit') }}">
                {{ csrf_field() }}
                <div class="field m-0 {{ $errors->has('email') ? ' has-error' : '' }}"> <label for="email"></label>
                    <input  id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required autofocus>

                </div>
                @if ($errors->has('email'))
                    <p class="text xs text-orange">
                        <strong>{{ $errors->first('email') }}</strong>
                    </p>
                @endif
                <div class="field mb-0 {{ $errors->has('password') ? ' has-error' : '' }}"> <label for="password"></label>
                    <input id="password" type="password" class="form-control" name="password" required>

                </div>
                @if ($errors->has('email'))
                    <p class="text xs text-red">
                        <strong>{{ $errors->first('password') }}</strong>
                    </p>
                @endif


                <div class="field mt-0">
                    <div class="group info ">
                        <input type="checkbox" checked="" id="remember" class="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}>
                        <label for="remember" class="checkbox"></label>
                    </div>
                    <div class="group ml-20">
                        <p class="text sm text-info">Beni hatırla</p>
                    </div>
                </div>

                <div class="field line m-0">
                        <button type="submit" class="btn btn-primary">
                            Login
                        </button>

                        <a class="btn btn-link" href="{{ route('password.request') }}">
                            Forgot Your Password?
                        </a>
                </div>
            </form>
        </div>
    </section>

</div>
@endsection
