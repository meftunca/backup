<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
         <title>Hoş Geldiniz</title>
        <link href="{{asset("css/comeback.css")}}" rel="stylesheet" type="text/css">
        <style>
            .header-blue{
                background-color: #00aff0;
                height: 100vh;
                width: 100vw;
            }
        </style>
    </head>
    <body>
        <header class="header-blue">
            <nav class="navbar no-shadow">
                <div class="navbar-panel justify-content-xl-center justify-content-md-between">
                    <h4 class=" text-white">Logo</h4>
                    <a href="#!" class="collapse-toggle text-white" data-collapse="navbar" data-href="navbar-info"></a>
                </div>
                <div class="navbar-collapse " data-id="navbar-info">
                    <ul class="nav-item right collapse">
                        <li class="item text-white"><a href="#"><span class="text-white">Anasayfa</span></a></li>
                        <li class="item text-white"><a href="#"><span class="text-white">Projeler</span></a></li>
                        <li class="dropdown item ">
                            <a href="#!" class="dropdown-toggle text-white">Giriş Yap</a>
                            <div class="dropdown-menu">
                                <form action="{{route("member.login.submit")}}" method="post" class="w-full">
                                    <h5 class="text-default">Giriş formu</h5><br>
                                    {{csrf_field()}}
                                    <div class="field line flex-column mt-0 mb-0">
                                        <h6 class="icon-mail mb-0 text left"> Email adresiniz</h6>
                                        <input type="email" name="email" required minlength="4" autofocus>
                                    </div>
                                    <div class="field line flex-column mt-20 mb-0">
                                        <h6 class="icon-unlock mb-0 text left"> Kullanıcı Şifreniz</h6>
                                        <input type="password" name="password" required>
                                    </div>
                                    <div class="field mb-0 ">
                                        <input type="submit" value="Giriş yap" class="btn btn-md btn-success">
                                    </div>
                                </form>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="container p-20">
                <div class="wrap xl-flexbox xl-1" style="height: 80vh;">
                    <div class="col text-white text center-all">
                        <h1 class="text bold">Kendi projelerini oluştur!!! </h1>
                        <p class="text lg container p-10">
                        Proje oluştur ve yayınla. <br>Projen için geliştirici ekibi oluştur ve özelleştirme adımlarını istişare et.
                            <br>
                            Projen ile ilgili özelleştirmelerin otomatik olarak sosyal proje hesabınızdan yayınlansın. <br>Sen ise sadece geliştirmelerine odaklan!!!<br>
                            Sizin için daha fazlasını bu yapı içinde bedava bir şekilde oluşturduk. <br>Gelişmek için sizide bekliyoruz...
                        </p>
                    </div>
                    <div class="col text center-all mt-50">
                        <a href="{{route("member.signin")}}" class="btn btn-lg btn-white pill text-blue">Şimdi kayıt ol</a>
                        <a href="#!" class="btn btn-lg btn-white pill text-blue">Dökümanlara göz at</a>
                    </div>
                </div>
            </div>
        </header>


        <script src="{{asset("js/comeback.js")}}"></script>
    </body>
</html>
