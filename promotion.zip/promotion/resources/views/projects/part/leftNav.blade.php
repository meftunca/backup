<div class="sidenav  m-0">
    <ul class="list  m-0">
        @foreach($category as $cat)
            <li class="item flex-column align-items-start p-0">
                @if(isset($libary))
                    @if(str_contains($_SERVER["REQUEST_URI"],$cat->seo_url))

                        <a href="#{{$cat->name}}" class="collapse-toggle text-default text md"
                           data-collapse="default" data-href="cat{{$cat->id}}">{{$cat->name}}</a>
                        <div class="collapse show" style="display: block;" data-slide="down" data-id="cat{{$cat->id}}">
                            <ul class="list p-0 m-0">
                                @foreach($libary as $lib)
                                    @php
                                        $url = "/member/".$lib->creator_nickname."/project/".str_slug($lib->framework_name,"-")."/".str_slug($lib->category_name,"-")."/".$lib->seo_url;
                                    @endphp
                                    <li class="item"><a href="{{url($url)}}" class="text xs" style="font-weight: 500 ">{!! $lib->name !!}</a></li>
                                @endforeach
                            </ul>
                        </div>
                    @else
                        <a href="" class="collapse-toggle text-default text md" data-collapse="default"
                           data-href="cat{{$cat->id}}">{{$cat->name}}</a>
                        <div class="collapse" data-id="cat{{$cat->id}}">
                            <ul class="list p-0 m-0">
                                @foreach($libary as $lib)
                                    @php
                                        $url = "/member/".$lib->creator_nickname."/project/".str_slug($lib->framework_name,"-")."/".str_slug($lib->category_name,"-")."/".$lib->seo_url;
                                    @endphp
                                    <li class="item"><a href="{{url($url)}}" class="text xs" style="font-weight: 500 ">{!! $lib->name !!}</a></li>
                                @endforeach
                            </ul>
                        </div>

                    @endif
                @else
                    <a href="{{url("/member/".$lib->creator_nickname."/project/".str_slug($lib->framework_name,"-")."/".str_slug($lib->category_name,"-"))}}">{{$cat->name }}</a>
                @endif
            </li>
        @endforeach
    </ul>
    {{--<div class="list">--}}
    {{--@foreach($projects as $project)--}}
    {{--<section class="item">--}}
    {{--<div class="wrap xl-flexbox xl-gutter-16">--}}
    {{--<div class="col xl-1-4">--}}
    {{--<img src="{{$project->logo}}" alt="" class="img-embed">--}}
    {{--</div>--}}
    {{--<div class="col xl-3-4">--}}
    {{--<a href="projects/{{$project->seo_url}}"--}}
    {{--class="text-gray text md">{{$project->name}}</a>--}}
    {{--</div>--}}
    {{--</div>--}}
    {{--</section>--}}

    {{--<ul class="list-accordion br-0 ">--}}
    {{--@foreach($category as $categories)--}}
    {{--@if(isset($libary))--}}
    {{--<li class="item align-items-start br-0">--}}
    {{--<a href="#!" class="collapse-toggle text md normal" data-collapse="default"--}}
    {{--data-href="{{$categories->id}}">{{$categories->name}}</a>--}}
    {{--@if(str_contains($_SERVER['REQUEST_URI'],$categories->seo_url))--}}
    {{--<div class="collapse  m-0 " data-id="{{$categories->id}}"--}}
    {{--style="display: block;" data-slide="down">--}}
    {{--@else--}}
    {{--<div class="collapse m-0 " data-id="{{$categories->id}}">--}}
    {{--@endif--}}
    {{--<ul class="list m-0">--}}
    {{--@foreach($libary as $lib)--}}
    {{--@if($categories->name === $lib->category_name)--}}

    {{--<li class=" p-0 ">--}}
    {{--@if(str_contains($_SERVER['REQUEST_URI'],$lib->seo_url))--}}
    {{--<a class="text-rose ml-10"--}}
    {{--href="{{url('projects/docs/'.$project->seo_url."/".$categories->seo_url."/".$lib->seo_url)}}">{!! $lib->name !!}</a>--}}
    {{--@else--}}
    {{--<a href="{{url('projects/docs/'.$project->seo_url."/".$categories->seo_url."/".$lib->seo_url)}}">{!! $lib->name !!}</a>--}}
    {{--@endif--}}
    {{--@else--}}
    {{--<a href="{{url('projects/docs/'.$project->seo_url."/".$categories->seo_url)}}"--}}
    {{--class="text md normal">{{$categories->name}}</a>--}}
    {{--@endif--}}
    {{--</li>--}}
    {{--</ul>--}}
    {{--</div>--}}

    {{--</li>--}}
    {{--@endforeach--}}
    {{--@else--}}
    {{--<li class="item">--}}
    {{--<a href="{{url("/member/".Auth::user()->nick_name."/project/".str_slug($categories->framework_name,"-")."/".$categories->seo_url)}}">{!! $categories->name !!}</a>--}}
    {{--</li>--}}
    {{--@endif--}}

    {{--@endforeach--}}
    {{--@endforeach--}}
    {{--</ul>--}}
    {{--</div>--}}
</div>