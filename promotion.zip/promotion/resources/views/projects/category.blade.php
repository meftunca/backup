@extends("projects.ProjectMaster")

@section("content")
    @foreach($category as $cat)
        {!! $cat->text !!}
    @endforeach
@endsection
