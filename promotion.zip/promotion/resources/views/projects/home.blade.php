<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{$title}}</title>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{asset("css/comeback.css")}}">
    <link rel="stylesheet" href="{{asset("css/projects/projects.css")}}">
    <link rel="stylesheet" href="{{asset("css/projects/highlighter.css")}}">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.5.1/themes/prism.min.css">
</head>
<body>
<nav class="navbar dark no-shadow">
    <div class="navbar-panel justify-content-xl-center justify-content-md-between">
        <h5 class="text bold">ZERONE
            <span class="text-blue">
                    <i class="icon-chevron-left text-info text md mr--10"></i>
                    <i class="icon-minus text-blue text md"></i>
                    <i class="icon-chevron-right text-info text md ml--10"></i>
                </span> DESING</h5>
        <a href="#!" class="collapse-toggle" data-collapse="navbar" data-href="navbar-dark">
            <i class="fa fa-bars"></i></a>
    </div>
    <div class="navbar-collapse " data-id="navbar-dark">
        <ul class="nav-item right collapse">
            <li class="item"><a href="{{route("home")}}">Anasayfa</a></li>
            <li class="item"><a href="{{route("blog")}}">blog</a></li>
            <li class="item"><a href="{{route("promotion")}}">tanıtım</a></li>
            @guest
                <li class="item"><a href="{{ route('login') }}">Giriş Yap</a></li>
            @else

                <li class="item dropdown">
                    <a href="#" class="dropdown-toggle">
                        {{ str_limit(Auth::user()->name ,8)}} <span class="icon-chevron-down"></span>
                    </a>

                    <ul class="dropdown-menu">
                        <li class="item"><a href="{{route("adminHome")}}">Panel'e git</a></li>
                        <li class="item">
                            <a href="{{ route('logout') }}"
                               onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                Logout
                            </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                  style="display: none;">
                                {{ csrf_field() }}
                            </form>
                        </li>
                    </ul>
                </li>
            @endguest

        </ul>
    </div>
</nav>

<div class="block h-50 lg-hidden"></div>
<section class="container">
    <div class="wrap xl-top xl-gutter-40 xl-outside-40 md-gutter-0 md-outside-0">

        <div class="col xl-4-5 md-1-1">
            <div class="wrap xl-flexbox xl-top xl-gutter-16 xl-1">
                @foreach($projects as $project)
                    <div class="col">
                        <div class="card rad-0 mb-10">
                            <div class="p-10 d-flex justify-content-start ">
                                <img src="{{$project->logo}}"
                                     class="img-xs mr-10"><span class="h5">{{$project->name}}</span></div>
                            <article class="card-block m-0">
                                {!! str_limit($project->text ,500)!!}
                            </article>
                            <aside class="pack  p-10 justify-content-between">
                                <a href="{{route("projectsHome")."/docs/".$project->seo_url}}" class="text-blue">Kütüphaneye
                                    git...</a>
                                <span>
                                  @php
                                      \Carbon\Carbon::setLocale('tr');
                                   echo \Carbon\Carbon::parse($project->created_at)->diffForHumans();
                                  @endphp
                                </span>
                            </aside>
                        </div>
                    </div>
            </div>
            @endforeach
        </div>
    </div>
    <div class="col xl-1-5 md-1-1">

    </div>
    </div>
</section>


<script type="text/javascript" src="{{asset("js/comeback.js")}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.5.1/prism.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.8.3/plugins/toolbar/prism-toolbar.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.7.1/clipboard.min.js"></script>
<script type="text/javascript" src="{{asset("js/projects/projects.js")}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.5.1/prism.js"></script>
</body>

</html>