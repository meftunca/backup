@extends("projects.projectMaster")
@section("leftnav")
    <div class="list">
        @foreach($projects as $project)
            <section class="item">
                <div class="wrap xl-flexbox xl-gutter-16">
                    <div class="col xl-1-4">
                        <img src="{{$project->logo}}" alt="" class="img-embed">
                    </div>
                    <div class="col xl-3-4">
                        <a href="projects/{{$project->seo_url}}"
                           class="text-gray text md">{{$project->name}}</a>
                    </div>
                </div>
            </section>
            <ul class="list-accordion br-0 ">
                @foreach($category as $categories)
                        <li class="item align-items-start br-0">
                            <a href="{{url('projects/docs/'.$project->seo_url."/".$categories->seo_url)}}">{{$categories->name}}</a>
                        </li>
                @endforeach
                @endforeach
            </ul>
    </div>
@endsection
@section("content")
    @foreach($projects as $project)
        {!! $project->text !!}
    @endforeach
@endsection
@section("rightnav")

@endsection