@extends("projects.projectMaster")

@section("content")
    <div class="breadcrumb rounded"style="background: white">
        @php
            $url = $_SERVER["REQUEST_URI"];
            $url = str_replace(url("/"),"/",$url);
            $url = explode("/",$url);
            $str= url('/')."/";
            for($i = 3;$i<count($url);$i++){
                  $str = $str.$url[$i]."/";
                     echo '<section class="item">';
                    if($i == count($url)-1){
                          echo $url[$i];
                    }else{
                      echo "<a href='".url($str)."'>$url[$i]</a>";
                    }
                echo '</section>';
            }
        @endphp
    </div>
    <div class="wrap h-50"></div>
    @foreach($content as $cont)
        <h2 class="doc-title mb-20"><a href="#!" class="doc-title-link">{!! $cont->name !!}</a></h2>

         {!! $cont->text !!}
        <div class="wrap h-50"></div>
        @foreach($content_lib as $sub_lib)
            <a class="text lg capitalize" href="#{{$sub_lib->seo_url}}">{{$sub_lib->name}}</a><br>
            <div class="content_lib">
                {!! $sub_lib->explanation !!}
                <div class="mt-20 mb-20">
                    {!! $sub_lib->examples !!}
                </div>
            </div>
                @if($sub_lib->name == $notes[0]->name)
                        @foreach($notes as $note)
                            <div class="bg-default p-20">
                                <a class="text lg text-black capitalize" href="#{{$note->seo_url}}">{{$note->name}}</a>
                                <div class="content_notes">
                                    {!! $note->notes !!}
                                </div>
                            </div>

                        @endforeach

                @endif
        @endforeach
    @endforeach
@endsection
@section("rightnav")
        <ul class="number">
            @foreach($content_lib as $sub_lib)
                <li><a href="#{{$sub_lib->seo_url}}">{{$sub_lib->name}}</a><br>
                    @if($sub_lib->name == $notes[0]->name)
                        <ul class="roman">
                            @foreach($notes as $note)
                                <li><a href="#{{$note->seo_url}}" class="text sm">{{$note->name}}</a></li>
                            @endforeach
                        </ul>
                    @endif
                </li>
            @endforeach
        </ul>
@endsection