<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Promotion</title>
    <link rel="stylesheet" href="{{asset("css/comeback.css")}}">
    <link rel="stylesheet" href="{{asset("css/promotion.css")}}">

</head>

<body>
<nav class="navbar white fixed-top">
    <div class="navbar-panel justify-content-xl-around justify-content-md-between ">
        <h5 class="text bold">ZERONE  DESING</h5>
        <a href="#!" class="collapse-toggle" data-collapse="navbar" data-href="navbar-dark">
            <i class="fa fa-bars"></i>
        </a>
    </div>
    <div class="navbar-collapse " data-id="navbar-dark">
        <ul class="nav-item right collapse">
            <li class="item active" name="home">
                <a href="#home">Başlarken</a>
            </li>
            <li class="item" name="ourWorks">
                <a href="#ourWorks">Bizim işimiz</a>
            </li>
            <li class="item" name="promotion">
                <a href="#promotion">Taahhütler</a>
            </li>
            <li class="item" name="service">
                <a href="#service">Servis</a>
            </li>
            <li class="item" name="contact">
                <a href="#contact">İletişim</a>
            </li>
        </ul>
    </div>
</nav>

<header class="wrap xl-flexbox xl-2 md-1 md-reverse header_content mouse__" id="home">
    <div class="col">
        <section class="container card br-0" style="background-color:transparent">
            <div class="card-block text left-all">
                <h1 class="text bold text-black">
                    En iyi
                    <br>
                    <span class="text-blue text xl">SEO</span> ve
                    <span class="text-blue text xl">Web tasarımı</span> Hizmeti sağlıyoruz!
                </h1>
                <div class="wrap">
                    <i class="icon-chevron-left text-info text md mr--10"></i>
                    <i class="icon-minus text-blue text md"></i>
                    <i class="icon-chevron-right text-info text md ml--10"></i>
                </div>
                <br>
                <p class="text-dark text lg">Kurumsal veya şahsi olarak zamanın en modern tasarımları ve güçlü sistemlerine sahip olun!</p>
                <br>
                <a href="#" class=" btn btn-lg btn-primary">
                    Daha fazla bilgi için...
                </a>
        </section>
    </div>

    </div>
    <div class="col xl-center">
        <img src="http://www.pharaohlab.com/html/retaj/assets/img/seo.png" class="md-hidden">
    </div>
</header>

<div class="wrap h-100">
</div>

<article class="wrap xl-1 mouse__" id="ourWorks">
    <div class="col">
        <aside class="container  xl-center">
            <h1>
                <i class="icon-droplet text xxl text-info"></i>
            </h1>
            <h2>Bizim işimiz...</h2>
            <br>
            <p class="text-gray container text lg">Sizin için güçlü siteler ve gerekli seo çalışmalarıyla marka değerinizi arttırmaktır.</p>
            <br>
        </aside>
        <div class="wrap h-100"></div>
    </div>
    <div class="col">
        <section class="container">
            <div class="wrap xl-3 md-1 xl-top xl-flexbox xl-gutter-24 xl-outside-40">
                <section class="col">
                    <section class="d-flex xl-gutter-16 justify-content-start">
                        <span class="icon-anchor text xxl"></span>
                        <aside>
                            <h6 class="text-blue text bold">Tasarım</h6>
                            <p class="text-gray">Tasarım konusunda dünya standartlarında şablonlar ile marka değerinizi tüm dünyaya tanıtmanıza
                                yardımcı olabiliriz.
                            </p>
                        </aside>
                    </section>
                    <div class="wrap h-100"></div>
                </section>
                <section class="col">
                    <section class="d-flex xl-gutter-16 justify-content-start">
                        <span class="icon-shield text xxl"></span>
                        <aside>
                            <h6 class="text-blue text bold">Güvenlik</h6>
                            <p class="text-gray">Güvenlik konusunda sizde bizim kadar dikkatli ve kuşkuluysanız burakın sizin yerinize işi
                                bilenler dertlensin. Sitenizi her türlü saldırılara karşı koruyabiliriz.
                            </p>
                        </aside>
                    </section>
                    <div class="wrap h-100"></div>
                </section>
                <section class="col">
                    <section class="d-flex xl-gutter-16 justify-content-start">
                        <span class="icon-anchor text xxl"></span>
                        <aside>
                            <h6 class="text-blue text bold">Seo</h6>
                            <p class="text-gray">Sitenizi üst sıralara taşımak için gerekli incelemeler ve tespitlerle istediğiniz vakitte
                                sitenizi üst sıralara yükseltebiliriz.
                            </p>
                        </aside>
                    </section>
                    <div class="wrap h-100"></div>
                </section>
            </div>
        </section>
    </div>
</article>
<div class="wrap h-100">
</div>
<article class="wrap gradient_blue text-whiteAll padding_content mouse__" id="promotion">
    <div class=" container ">
        <div class="wrap xl-flexbox xl-2 md-1 ">
            <div class="col ">
                <img class="img-embed " src="http://www.pharaohlab.com/html/retaj/assets/img/seo2.png " alt="marketing ">
            </div>
            <div class="col ">
                <aside class="card br-0 ">
                    <section class="d-flex xl-gutter-16 justify-content-start ">
                        <span class="icon-users text xxl "></span>
                        <aside>
                            <h3 class="text bold">Site yönetimi ve seo</h3>
                            <p class="text sm ">Web sitenize isteğiniz doğrultusunda yeni yöneticiler ve özel link yapıları oluşturabilirsiniz...
                            </p>
                        </aside>
                    </section>
                </aside>
                <aside class="card br-0 ">
                    <section class="d-flex xl-gutter-16 justify-content-start ">
                        <span class="icon-edit-3 text xxl "></span>
                        <aside>
                            <h3 class="text bold">Kolay içerik oluşturma</h3>
                            <p class="text sm ">
                                Biz sizin rahat içerikler oluşturmanız için isteğiniz doğrultusunda size özel panel oluştururuz...
                            </p>
                        </aside>
                    </section>
                </aside>
                <aside class="card br-0 ">
                    <section class="d-flex xl-gutter-16 justify-content-start ">
                        <span class="icon-share-2 text xxl "></span>
                        <aside>
                            <h3 class="text bold">Sosyal medya yönetimi</h3>
                            <p class="text sm ">
                                Websitenizden sosyal medyalarınızı yönetebilirsiniz ...
                            </p>
                        </aside>
                    </section>
                </aside>
                <aside class="card br-0 ">
                    <section class="d-flex xl-gutter-16 justify-content-start ">
                        <span class="icon-shield text xxl "></span>
                        <aside>
                            <h3 class="text bold">Güvenlik</h3>
                            <p class="text sm ">
                                Websitenizi gelişen zamana göre devamlı koruma altında tutarız...
                            </p>
                        </aside>
                    </section>
                </aside>
            </div>
        </div>
    </div>
</article>
<div class="wrap h-100">
</div>
<section class="wrap xl-flexbox xl-top mouse__" id="service">
    <div class="container">
        <div class="wrap xl-1 xl-center">
            <div class="col">
                <i class="icon-layers text-info text xxl">
                </i>
                <h1>
                    Servis
                </h1>
                <p>
                    Neden bizi tercih etmelisiniz ?
                    <br> İnanıyoruz ki aşağıdaki maddeler bizi seçmeniz için sizi ikna edecektir.
                </p>
            </div>
        </div>
        <div class="wrap h-100"></div>

        <div class="wrap xl-3 lg-2 md-1 xl-center xl-gutter-40 md-gutter-24">

            <div class="col">
                <div class="br-light p-50 ">
                    <img src="http://www.pharaohlab.com/html/retaj/assets/img/icons/product-search.png" alt="product research">
                    <br>
                    <br>
                    <h5 class="text-info">
                        İhtiyaç araştırması
                    </h5>
                    <br>
                    <p class="text-gray">
                        Biz ihtiyaçlarınıza göre özellikler sunarız.Sizin ve sitenizin herzaman yükselen ve populer olması için uğraşırız...

                    </p>
                </div>
                <div class="wrap h-50"></div>

            </div>
            <div class="col">
                <div class="br-light p-50 ">
                    <img src="http://www.pharaohlab.com/html/retaj/assets/img/icons/consulting.png" alt="product research">
                    <br>
                    <br>
                    <h5 class="text-info">
                        Danışmanlık
                    </h5>
                    <br>
                    <p class="text-gray">
                        Biz sorunlarınızın çözümü için devamlı sizinle iletişimde kalıp danışmanlık hizmeti verebiliriz...
                    </p>
                </div>
                <div class="wrap h-50"></div>

            </div>
            <div class="col">
                <div class="br-light p-50 ">
                    <img src="http://www.pharaohlab.com/html/retaj/assets/img/icons/data-mang.png" alt="product research">
                    <br>
                    <br>
                    <h5 class="text-info">
                        Veri yönetimi
                    </h5>
                    <br>
                    <p class="text-gray">
                        Biz sizin için Websitenizi ve içeriklerinizi yönetmeniz için size özel bir admin paneli sunarız...
                    </p>
                </div>
                <div class="wrap h-50"></div>

            </div>
            <div class="col">
                <div class="br-light p-50">
                    <img src="http://www.pharaohlab.com/html/retaj/assets/img/icons/page-ranking.png" alt="product research">
                    <br>
                    <br>
                    <h5 class="text-info">
                        Sayfa sıralaması
                    </h5>
                    <br>
                    <p class="text-gray">
                        Biz websitenizi ve sayfalarınızı en yükseklerde olması gerektiğine inanıyoruz. Bunun için her yenilikle birlikte sitenizi
                        hakettiği yerde tutarız...
                    </p>
                </div>
                <div class="wrap h-50"></div>

            </div>
            <div class="col">
                <div class="br-light p-50">
                    <img src="http://www.pharaohlab.com/html/retaj/assets/img/icons/location-target.png" alt="product research">
                    <br>
                    <br>
                    <h5 class="text-info">
                        Yer hedefleri
                    </h5>
                    <br>
                    <p class="text-gray">
                        Biz
                        <span class="text-blue">seo</span> konusunda sizi gerçekten en önlerde tutmak için doğru referanslarınızla sitenizi güçlendirir
                        ve yeniliklerle güncelleriz...
                    </p>
                </div>
                <div class="wrap h-50"></div>

            </div>
            <div class="col">
                <div class="br-light p-50">
                    <img src="http://www.pharaohlab.com/html/retaj/assets/img/icons/website-speed.png" alt="product research">
                    <br>
                    <br>
                    <h5 class="text-info">
                        Performans
                    </h5>
                    <br>
                    <p class="text-gray">
                        Biz websitenizi performanslı ve modern standarlarda tasarlar, bunun için gerekli optimizasyonunu sağlarız...
                    </p>
                    <br>
                </div>
                <div class="wrap h-50"></div>

            </div>
        </div>
    </div>
</section>
<div class="wrap h-20">
</div>
<div class="wrap xl-flexbox xl-1 p-50 mouse__" id="contact">
    <div class="col xl-center">
        <i class="icon-message-circle text xxl text-info"></i>
        <h4>
            İletişim
        </h4>
        <p>
            Bizimle iletişim kurmak için ister bilgilerinizi girerek irtibat isteğinde bulunun, istersenizde mail veya telefon ile irtibat
            kurabilirsiniz...
        </p>
    </div>
    <div class="col">
        <section class="container">
            <article class="wrap xl-flexbox xl-2 md-1">
                <div class="col ">
                    <form action="" class="w-full">

                        <div class="field w-full">
                            <input type="text" id="d1">
                            <label class="label" for="d1">
                                <i class="icon-user"></i>
                                <span>İsim ve soyisim</span>
                            </label>
                        </div>
                        <div class="field w-full">
                            <input type="text" id="d1">
                            <label class="label" for="d1">
                                <i class="icon-mail"></i>
                                <span>Mail adresiniz</span>

                            </label>
                        </div>
                        <div class="field w-full">
                            <input type="text" id="d1">
                            <label class="label" for="d1">
                                <i class="icon-phone"></i>
                                <span>Telefon numaranız</span>
                            </label>
                        </div>
                        <div class="field">
                            <input type="submit" value="Gönder" class="btn btn-md btn-success p-10">
                        </div>
                    </form>
                </div>
                <div class="col p-20">
                    <section class="d-flex xl-gutter-24 justify-content-start">
                        <span class="icon-phone text xl"></span>
                        <aside>
                            <h5>Telefon numarası</h5>
                            <p class="text-gray">0 (545) 609 85 75</p>
                        </aside>
                    </section>
                    <br>
                    <br>
                    <section class="d-flex xl-gutter-24 justify-content-start">
                        <span class="icon-mail text xl"></span>
                        <aside>
                            <h5>mail adresi</h5>
                            <p class="text-gray text lower">buraksenturk25@gmail.com</p>
                        </aside>
                    </section>
                    <br>
                    <br>


                </div>
            </article>
        </section>
    </div>
</div>

<div class="wrap p-20 bg-dark xl-center xl-flexbox xl-1">
    <h2 class="text bold col">
        <h5>ZerOneDesing @ 2017</h5>
        <aside class="col xl-center">
            <a href="#home" class="btn btn-circle">
                <span class="m-10"> Yukarı çık </span>
                <i class="icon-chevron-up text xl"></i>
            </a>
        </aside>

</div>

<script src="{{asset("js/comeback.js ")}}"></script>
<script src="{{asset("js/promotion.js ")}}"></script>
</body>

</html>
