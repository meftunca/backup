@extends('layouts.frontend')
@section("up")
    <script src="{{asset('ckeditor/ckeditor.js')}}"></script>
 @endsection
@section('content')
    @foreach($posts as $write)
        <section class="card br-0">
            <div class="card-header">
                <section class="pack image mt-10">
                    <section class="group-content">
                        <img src="{{$write->author_picture}}" alt="" class="group m-0 circle mr-20">
                        <aside class="group m-0">
                            <span class=" text sm">{{$write->author}}</span><br> <span class=" text sm">{{$write->kind}}</span>
                        </aside>
                        <span class="group m-0 right">
                        @php
                            \Carbon\Carbon::setLocale('tr');
                         echo \Carbon\Carbon::parse($write->created_at)->diffForHumans();
                        @endphp
                    </section>
                </section>
            </div>
            <div class="card-body">
                <img src="{{$write->picture}}"
                     class="img-embed" alt="">
                <div class="card-block">
                    <h6 class="card-subtitle p-10 mb-0">{{$write->title}}</h6>
                    <div class="card-text">
                        <div class="p-10">
                            {!! $write->text !!}
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="wrap xl-flexbox xl-around  xl-center p-10 xl-3">
                    <a class="col" href="#!"><i class="icon-thumbs-up text md"></i> <span class="text sm m-10"> Beğen</span></a>
                    <a class="col collapse-toggle" href="#!" data-collapse="default" data-href="comment"><i class="icon-message-square text md"></i> <span class="text sm m-10"> Yorum yap</span></a>
                    <a class="col " href="#!"><i class="icon-share text md"></i> <span class="text sm m-10">Paylaş</span></a>
                </div>
            </div>
        </section>
        <div class="h-50 md-hidden"></div>
        <div class="card br-0 scrolspy" style="max-height: 600px">
            <h3 class="p-10"><i class="icon-message-square text lg mr-10"></i>Yorumlar
                <div class="bg-default" style=" width: 240%;height: 3px;"></div>
            </h3>
            <ul class="list br-0 line">
            @foreach($comment as $com)
                 <li class=" p-10 ">
                  <div class="wrap xl-flexbox">
                      <img src="https://ruclip.com/chimg/af/UCunmY844_M6VuX4cTopKdnQ.jpg" class="circle img-xs" alt="">
                        <span class="col  ml-10">
                        <h6>Ziyaretçi</h6>
                        <span>{!! $com->comment !!}</span>
                         </span>
                  </div>
                </li>
            @endforeach
            </ul>
        </div>
        <div class="h-50 md-hidden"></div>
        <div class="collapse bg-white p-20 br-0" data-id="comment">
            <form action="{{route("commentPost")}}" class="w-full" method="post">
                {{csrf_field()}}
                <input type="hidden" name="kind" value="{{$write->kind}}">
                <input type="hidden" name="seo_url" value="{{$write->seo_url}}">
                @if(session()->has('success'))
                    <div class="alert alert-success">
                        <h4>Başarılı !</h4>
                        <div class="alert-text">{{ session()->get('success') }}</div>
                        <a class="alert-close"></a>
                    </div>
                @elseif(session()->has('error'))
                    <div class="alert alert-rose">
                        <h4>Başarısız !!!</h4>
                        <div class="alert-text">{{ session()->get('error') }}</div>
                        <a class="alert-close"></a>
                    </div>
                @endif
                <div class="field line">
                    <textarea name="comment" id="comment" class="w-full" rows="10"></textarea>
                    <script>
                        CKEDITOR.replace("comment",{
                            customConfig: '{{asset("ckeditor/commentConfig.js")}}'
                        });
                    </script>
                    <style>
                        #cke_comment{
                            width: 100%;
                        }
                    </style>
                </div>
                <input type="submit" class="btn btn-md btn-success" value="Yorum yap">
            </form>
        </div>
    @endforeach
    <div class="wrap xl-2 xl-flexbox xl-center bg-white p-20">
        <div class="col">
        </div>
        <div class="col">
            <a href="{{$paginate->nextPageUrl()}}">Sonraki makale <i class="icon-chevron-right ml-10"></i></a>
        </div>
    </div>
@endsection
