@extends("member.master")

@section("content")
    @include("member.part.user.content")
@endsection
@section("rightnav")
    {{--@include("member.part.user.profile.aboutNav")--}}
@endsection