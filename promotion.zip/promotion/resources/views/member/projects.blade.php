@extends("member.master")
@section("content")
    @include("member.part.user.projects")
@endsection
@section("rightnav")
    @include("member.part.user.projects_info")
@endsection