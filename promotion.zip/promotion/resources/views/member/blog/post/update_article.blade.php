@extends('member.master')
@section("up")
    <script src="{{asset("ckeditor/ckeditor.js")}}"></script>
@endsection
@section('content')
    @foreach($article as $art)
        <div class="container">
            <div class="pack xl-between">
                <h5 class="text default"><i class="icon-tag mr-10"></i>{{$art->title}} yazısını düzenle...</h5>
            </div>
            @include("member.part.user.status")
            <form action="{{route("blog.article.post.update")}}" method="post" class="d-flex flex-column w-full">
                {{csrf_field()}}
                <input type="hidden" name="id" value="{{$art->id}}">
                <div class="field line">
                    <input type="text" name="kind" value="{{$art->kind}}"> <label class="icon-layers"> Yazını kategorisi</label>
                </div>
                <div class="field line">
                    <input type="text" name="title" value="{{$art->title}}"> <label class="icon-italic"> Makale başlığı</label>
                </div>
                <div class="field line">
                    <input type="text" name="picture" value="{{$art->picture}}"> <label class="icon-image"> Makaleniz için resim alanı</label>
                </div>
                <div class="field line flex-column">
                    <span class="h6 icon-edit-2 text-default mb-10"> Blog yazınızı bu alana yazabilirsiniz</span>
                    <textarea name="text" id="text" cols="30" rows="10"> {!! $art->text !!}</textarea>
                    <script>
                        CKEDITOR.replace('text',{
                            customConfig: '{{asset("ckeditor/adminConfig.js")}}',width :'100%'
                        });
                    </script>
                </div>
                <input type="submit" class="btn btn-md btn-primary" value="Yeni yazı ekle">
            </form>
        </div>
    @endforeach
@endsection
