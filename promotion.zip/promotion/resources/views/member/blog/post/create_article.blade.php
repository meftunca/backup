@extends('member.master')
@section("up")
    <script src="{{asset("ckeditor/ckeditor.js")}}"></script>
@endsection
@section('content')
    <div class="container">
        <div class="pack xl-between">
            <h5 class="text default"><i class="icon-tag mr-10"></i>Blog yazısı oluştur</h5>
        </div>
        @include("member.part.user.status")
        <form action="{{route("blog.article.post")}}" method="post" class="d-flex flex-column w-full">
            {{csrf_field()}}
            <input type="hidden" name="project_name" value="{{Request::segment(3)}}">
            <div class="field line">
                <input type="text" name="kind"> <label class="icon-layers"> Yazını kategorisi</label>
            </div>
            <div class="field line">
                <input type="text" name="title"> <label class="icon-italic"> Makale başlığı</label>
            </div>
            <div class="field line">
                <input type="text" name="picture"> <label class="icon-image"> Makaleniz için resim alanı</label>
            </div>
            <div class="field line flex-column">
                <span class="h6 icon-edit-2 text-default mb-10"> Blog yazınızı bu alana yazabilirsiniz</span>
                <textarea name="text" id="text" cols="30" rows="10"></textarea>
                <script>
                    CKEDITOR.replace('text',{
                        customConfig: '{{asset("ckeditor/adminConfig.js")}}',width :'100%'
                    });
                </script>
            </div>
            <input type="submit" class="btn btn-md btn-primary" value="Yeni yazı ekle">
        </form>
    </div>
@endsection
