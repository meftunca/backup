@extends("member.master")

@section("content")
    @include("member.part.user.article_list")
@endsection
@section("rightnav")
    @include("member.part.user.projects_info")
@endsection