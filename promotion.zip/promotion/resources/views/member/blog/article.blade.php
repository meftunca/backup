@extends('member.blog.master')
@section("up")
    <script src="{{asset('ckeditor/ckeditor.js')}}"></script>
    <style>
        body {
            background-color: #F9F9F9;
        }
    </style>
@endsection
@section('content')
    @foreach($posts as $write)
        <section class="card br-0">
            <div class="card-header">
                <section class="pack image mt-10">
                    <section class="group-content">
                        <img src="{{$write->author_picture}}" alt="" class="group m-0 circle mr-20">
                        <aside class="group m-0">
                            <span class=" text sm">{{$write->author}}</span><br> <span
                                    class=" text sm">{{$write->kind}}</span>
                        </aside>
                        <span class="group m-0 right">
                        @php
                            \Carbon\Carbon::setLocale('tr');
                         echo \Carbon\Carbon::parse($write->created_at)->diffForHumans();
                        @endphp
                    </section>
                </section>
            </div>
            <div class="card-body">
                <img src="{{$write->picture}}"
                     class="img-embed" alt="">
                <div class="card-block">
                    <h6 class="card-subtitle p-10 mb-0">{{$write->title}}</h6>
                    <div class="card-text">
                        <div class="p-10">
                            {!! $write->text !!}
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-footer">
                <div class="wrap xl-flexbox xl-around  xl-center p-10 xl-3">
                    @include("member.part.user.article_like")
                    <a class="col collapse-toggle" href="#!" data-collapse="default" data-href="comment"><i
                                class="icon-message-square text md"></i> <span
                                class="text sm m-10"> Yorum yap</span></a>
                    <a class="col " href="#!"><i class="icon-share text md"></i> <span
                                class="text sm m-10">Paylaş</span></a>
                </div>
            </div>
        </section>
        <div class="h-20 md-hidden"></div>
        <div class="collapse bg-white p-20 br-0" data-id="comment">

            <form action="{{route("commentPost")}}" class="w-full" method="post">
                {{csrf_field()}}
                <input type="hidden" name="project_name" value="{{$write->project_name}}">
                <input type="hidden" name="article_name" value="{{$write->title}}">
                <input type="hidden" name="author" value="{{$write->author}}">
                <input type="hidden" name="commentator" value="{{Auth::user()->nick_name}}">
                <input type="hidden" name="commentator_picture" value="{{Auth::user()->profile_picture}}">

                <div class="field line">
                    <textarea name="comment" id="comment" class="w-full" rows="10"></textarea>
                    <script>
                        CKEDITOR.replace("comment", {
                            customConfig: '{{asset("ckeditor/commentConfig.js")}}',
                            width: "100%"
                        });
                    </script>
                </div>
                <input type="submit" class="btn btn-md btn-success" value="Yorum yap">
            </form>
        </div>
        <div class="h-20 md-hidden"></div>
        <div class="card br-0 " style="overflow: visible">
            <h3 class="p-10"><i class="icon-message-square text lg mr-10"></i>Yorumlar
                <div class="bg-teal" style=" width: 240%;height: 3px;"></div>
            </h3>
            <section class="list br-0 line">
                @foreach($comment as $com)
                    <div class="item p-10 ">
                        <div class="wrap xl-flexbox">
                            <img src="{{$com->commentator_picture}}" class="circle img-sm" alt="">
                            <aside class="col xl-9-10 ml-10">
                                <section class="w-full pack justify-content-between">
                                    <div class="member_comment_info">
                                        <span class="text sm text-teal">{{strtoupper($com->commentator)}}</span>

                                        <span class="ml-10 text xs text-default">
                                            <i class="icon-watch text md text-rose"></i>
                                            @php
                                                \Carbon\Carbon::setLocale('tr');
                                                echo \Carbon\Carbon::parse($write->created_at)->diffForHumans();
                                            @endphp
                                     </span>
                                    </div>
                                    <div class="member_comment_controller">
                                        <div class="dropdown">
                                            <a href="#settings"
                                               class="dropdown-toggle icon-settings text lg text-teal"></a>
                                            <ul class="dropdown-menu right p-0">
                                                <li class="item">
                                                    <a href="#update" class="collapse-toggle icon-edit-2"
                                                       data-collapse="default"
                                                       data-href="update{{$com->id}}"> Düzenle
                                                    </a>
                                                </li>
                                                <li class="item">
                                                    <a class="icon-trash" href="{{ route('comment.delete') }}"
                                                       onclick="event.preventDefault();document.getElementById('comment{{$com->id}}').submit();" > Sil
                                                    </a>
                                                    <div class="xl-hidden">
                                                        <form action="{{route("comment.delete")}}" id="comment{{$com->id}}" class="w-full" method="post">
                                                            {{csrf_field()}}
                                                            <input type="hidden" name="id" value="{{$com->id}}">
                                                        </form>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </section>
                                <div class=" p-10 round text-default text sm normal member_comment_text mt-10 "
                                     style="background-color: #f6f6f6">{!! $com->comment !!}</div>
                                <div class="member comment_update collapse" data-id="update{{$com->id}}">
                                    <form action="{{route("comment.update")}}" class="w-full" method="post">
                                        {{csrf_field()}}
                                        <input type="hidden" name="id" value="{{$com->id}}">
                                        <div class="field line">
                                            <textarea name="comment" id="update" class="w-full" rows="10">{{$com->comment}}</textarea>
                                            <script>
                                                CKEDITOR.replace("update", {
                                                    customConfig: '{{asset("ckeditor/commentConfig.js")}}',
                                                    width: "100%"
                                                });
                                            </script>
                                        </div>
                                        <input type="submit" class="btn btn-md btn-success" value="Yorum yap">
                                    </form>
                                </div>

                            </aside>
                        </div>
                    </div>
                @endforeach
            </section>
        </div>

    @endforeach
    <div class="wrap xl-2 xl-flexbox xl-center xl-between bg-white p-20">
        <div class="col text left">
            <a href="{{$paginate->previousPageUrl()}}"><i class="icon-chevron-left mr-10"></i>Sonraki makale</a>
        </div>
        <div class="col text right">
            <a href="{{$paginate->nextPageUrl()}}">Sonraki makale <i class="icon-chevron-right ml-10"></i></a>
        </div>
    </div>
@endsection
