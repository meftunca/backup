@extends('member.blog.master')
@section("up")
    <script src="{{asset('ckeditor/ckeditor.js')}}"></script>
@endsection
@section('content')
    @foreach($posts as $write)
        <section class="card br-0">
            <div class="card-header">
                <section class="pack image mt-10">
                    <section class="group-content">
                        <img src="{{$write->author_picture}}" alt="" class="group m-0 circle mr-20">
                        <aside class="group m-0">
                            <span class=" text sm">{{$write->author}}</span><br> <span
                                    class=" text sm">{{$write->kind}}</span>
                        </aside>
                        <span class="group m-0 right">
                        @php
                            \Carbon\Carbon::setLocale('tr');
                         echo \Carbon\Carbon::parse($write->created_at)->diffForHumans();
                        @endphp
                    </section>
                </section>
            </div>
            <div class="card-body">
                <img src="{{$write->picture}}"
                     class="img-embed" alt="">
                <div class="card-block">
                    <h6 class="card-subtitle p-10 mb-0">{{$write->title}}</h6>
                    <div class="card-text">
                        <div class="p-10">
                            {!! str_limit($write->text,400) !!}
                        </div>
                    </div>
                </div>
                <div class="card-toggle-content" data-href="comment{{$write->id}}">
                    <div class="card br-0 scrolspy" style="max-height: 600px">
                        <div class="wrap xl-flexbox xl-between mb-10 xl-2">
                            <span class="col text sm xl-middle">Yorum paneli</span>
                            <a class="col card-toggle text right xl-middle" href="#!" data-id="comment{{$write->id}}"
                               style="z-index: 1 !important;">
                                <span class="col text sm">Paneli kapat </span>
                                <i class="icon-chevron-down text lg"></i> </a>
                        </div>
                        <ul class="list br-0 line">
                            @foreach($comment as $com)
                                @if($write->seo_url === $com->seo_url)
                                    <li class=" p-10 ">
                                        <div class="wrap xl-flexbox xl-top">
                                            <img src="https://ruclip.com/chimg/af/UCunmY844_M6VuX4cTopKdnQ.jpg"
                                                 class="col xl-1-12circle img-xs" alt="">
                                            <span class="col xl-11-12 ml-10">
                                        <h6 class="wrap xl-flexbox xl-between"><span class="col">Ziyaretçi</span>
                                         <span class="col text xs ml-20"><i class="icon-calendar text md"></i>
                                             @php
                                                 \Carbon\Carbon::setLocale('tr');
                                              echo \Carbon\Carbon::parse($com->created_at)->diffForHumans();
                                             @endphp
                                         </span>
                                        </h6>
                                        <p class="p-10">{!! $com->comment !!}</p>
                                         </span>
                                        </div>
                                    </li>
                                @endif
                            @endforeach
                        </ul>
                    </div>
                    <form action="{{route("commentPost")}}" class="w-full" method="post"
                          style="    position: absolute;bottom: 0;">
                        {{csrf_field()}}
                        <input type="hidden" name="kind" value="{{$write->kind}}">
                        <input type="hidden" name="seo_url" value="{{$write->seo_url}}">

                        <div class="field line">
                            <textarea name="comment" id="{{$write->seo_url}}" class="w-full"
                                      style="max-height: 300px"></textarea>
                            <script>
                                CKEDITOR.replace("{{$write->seo_url}}", {
                                    customConfig: '{{asset("ckeditor/commentConfig.js")}}',
                                    height: '100px'
                                });
                            </script>

                        </div>
                        <input type="submit" class="btn btn-lg btn-success w-full" value="Yorum yap"
                               style="z-index:99999 !important;">
                    </form>
                </div>
                <div class="card-footer">
                    <div class="wrap xl-flexbox xl-around  xl-center p-10">
                        <div class="col xl-3-7 xl-left">
                            <a href="{{url("/member/".Request()->segment(2)."/blog/article/".$write->seo_url)}}"
                               class="text-teal ml-20">Devamını oku</a>
                        </div>
                        <section class="col xl-4-7">
                            <aside class="wrap xl-3 xl-flexbox">
                                @include("member.part.user.article_like")
                                <a class="col card-toggle" href="#!" data-id="comment{{$write->id}}"
                                   style="z-index: 1 !important;"><i class="icon-message-square text md"></i> <span
                                            class="text sm m-10"> Yorum yap</span></a>
                                <a class="col" href="#!"><i class="icon-share text md"></i> <span class="text sm m-10">Paylaş</span></a>

                            </aside>
                        </section>
                     </div>
                </div>
        </section>
        <div class="h-50 md-hidden"></div>

    @endforeach
    <div class="wrap xl-center m-20">
        <nav class="bg-white" aria-label="pagination " role="navigation">
            {{$paginate->links()}}
        </nav>
    </div>
@endsection
