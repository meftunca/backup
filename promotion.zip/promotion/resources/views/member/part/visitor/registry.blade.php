@extends("member.master")
@section("content")
<div class="container">
    <div class="mt-10 mb-10">
        @include("member.part.visitor.registry_status")
    </div>
    <section class="card p-10">
        <form action="{{route("member.signin.submit")}}" method="post" class="w-full">
            <h2>Kayıt formu</h2>
            {{csrf_field()}}
            <div class="field line flex-column">
                <h6><i class="icon-users"></i> Kullanıcı adı</h6></h6><input type="text" required minlength="4" maxlength="32" name="nick_name">
            </div>
            <div class="field line flex-column">
                <h6><i class="icon-user"></i> İsminiz</h6></h6><input type="text" required minlength="4" maxlength="32" name="name">
            </div>
            <div class="field line flex-column">
                <h6><i class="icon-user"></i> Soyisminiz</h6></h6><input type="text" required minlength="4" maxlength="32" name="last_name">
            </div>
            <div class="field line flex-column">
                <h6><i class="icon-unlock"></i> Şifreniz</h6><input type="password" required minlength="8" maxlength="32" name="password">
            </div>
            <div class="field line flex-column">
                <h6><i class="icon-mail"></i> Email adresiniz</h6><input type="email" required name="email">
            </div>
            <div class="field line flex-column">
                <h6><i class="icon-image"></i> Profiliniz için resim ekleyin</h6><input type="text" name="profile_picture">
            </div>
            <div class="field line flex-column">
                <h6><i class="icon-info"></i> Uzman olduğunuz alan</h6><input type="text" name="interest">
            </div>
            <div class="field line flex-column">
                <h6><i class="icon-bookmark"></i>Hakkınızda kısa bir açıklama yazın (maximum 255 karakter)</h6>
                <textarea type="text" name="about" maxlength="255"></textarea>
            </div>
            <div class="field line flex-column">
                <h6><i class="icon-facebook"></i> Facebook hesap adresiniz</h6><input type="text" name="facebook">
            </div>
            <div class="field line flex-column">
                <h6><i class="icon-twitter"></i> twitter hesap adresiniz</h6><input type="text" name="twitter">
            </div>
            <div class="field line flex-column">
                <h6><i class="icon-github"></i> github hesap adresiniz</h6><input type="text" name="github">
            </div>
            <div class="field line flex-column">
                <h6><i class="icon-instagram"></i> instagram hesap adresiniz</h6><input type="text" name="instagram">
            </div>
            <div class="field line flex-column">
            </div><input type="submit" class="btn btn-md btn-success" value="Kayıt ol">
            </div>
        </form>
    </section>
</div>
@endsection
