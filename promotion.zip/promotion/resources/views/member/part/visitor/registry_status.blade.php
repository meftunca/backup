@if(session()->has("member_success"))
    <div class="alert alert-success"><h4>Başarılı</h4><p class="alert-text">{!! session()->get("member_success") !!}</p>
        <a class="alert-close"></a>
    </div>
@elseif(session()->has("member_warning"))
    <div class="alert alert-warning"><h4>Ufak bir sorun</h4><p class="alert-text">{!! session()->get("member_warning") !!}/p>
        <a class="alert-close"></a>
    </div>
@elseif(session()->has("member_danger"))
    <div class="alert alert-rose"><h4>Büyük bir hata</h4><p class="alert-text">{!! session()->get("member_danger") !!}</p>
        <a class="alert-close"></a>
    </div>
@endif




