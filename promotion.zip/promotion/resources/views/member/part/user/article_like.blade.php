@guest
    <a class="col" href="#!"><i class="icon-thumbs-up text md"></i> <span class="text sm m-10"> Beğen</span></a>
@else
    <a class="col" id="{{str_slug($write->title,"")}}" onmouseleave='like_article("{{$write->author}}","{{$write->project_name}}",
    "{{$write->title}}","{{Auth::user()->nick_name}}",
    "{{Auth::user()->profile_picture}}","{{route("article.like")}}","{{str_slug($write->title,"")}}")' href="#!"><i class="icon-thumbs-up text md"></i> <span class="text sm m-10"> Beğen</span></a>
@endguest
