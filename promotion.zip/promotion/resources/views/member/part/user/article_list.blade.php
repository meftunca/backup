<div class="wrap xl-1">
    <div class="col mb-20">
        <h2 class="text-teal text bold">Harika !
            <small class="text-default">Blog yazılarını burada düzenle veye sil...</small>
        </h2>
    </div>
    <section class="col">
            @include("member.part.user.status")
        <div class="wrap xl-1 ">
            <div class="col">
                <ul class="list box line w-full">
                    @foreach($articles as $article)
                        <li class="item p-10">
                            <img src="http://www.ravijaiswal.com/Afro-v.1.1/img/samples/robert-300.jpg" class="img-sm circle" alt="">
                            <aside class="wrap xl-between xl-flexbox" style="padding: 0 10px;">
                                <aside class="col xl-1-2 "><span class="text-teal text bold sm">Yazar :</span>
                                    <a href="" class="h6 text bold sm">{{$article->author}}</a>
                                    <br>
                                    <span class="text-info text bold sm">makale adı :</span>
                                    <a href="" class="h6 text bold sm"> {{$article->title}}</a>
                                </aside>
                                <aside class="col xl-1-2 xl-right">
                                        <a href="{{url("/member/blog/update/".str_slug($article->project_name,"-")."/".$article->id)}}" class=" p-10">
                                            <i class="icon-edit-3 text lg"></i></a>
                                        <a href="{{route("blog.article.post")."/delete/".$article->id}}" class="p-10">
                                            <i class="icon-trash text lg"></i></a>
                                    <br>
                                    <a href="#"><i class="icon-clock text-info mt-10"></i><span class="text xs" style="margin-left:5px;">
                                        @php
                                             \Carbon\Carbon::setLocale('tr');
                                             echo \Carbon\Carbon::parse($article->updated_at)->diffForHumans();
                                         @endphp
                                    </a>
                                </aside>
                            </aside>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </section>
</div>