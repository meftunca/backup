@if(session()->has("success"))
    <div class="alert alert-success"><h6>Başarılı</h6><p class="alert-text">{!! session()->get("success") !!}</p>
        <a class="alert-close"></a>
    </div>
@elseif(session()->has("warning"))
    <div class="alert alert-warning"><h6>Ufak bir sorun Oluştu</h6><p class="alert-text">{!! session()->get("warning") !!}/p>
            <a class="alert-close"></a>
    </div>
@elseif(session()->has("error"))
    <div class="alert alert-rose"><h6>Büyük bir hata Oluştu</h6><p class="alert-text">{!! session()->get("error") !!}</p>
        <a class="alert-close"></a>
    </div>
@endif