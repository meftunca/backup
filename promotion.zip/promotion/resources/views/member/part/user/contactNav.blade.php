<section class="tab-group flex-column">
    <div class="tab">
        <aside class="tab-item" data-href="tab1">Arkadaşlar</aside>
        <aside class="tab-item" data-href="tab2">Ekip</aside>
    </div>
    <div class="content-group">
        <section data-id="tab1" class="tab-content p-0">

            <ul class="list mt-0">
                <li>
                    <img src="https://st2.depositphotos.com/1006318/5909/v/950/depositphotos_59094043-stock-illustration-profile-icon-male-avatar.jpg"
                         class="circle img-xs" alt="">
                    <div class="pack">
                        <span class="group-content">
                            <aside class="pack"><h6>UserNames</h6></aside>
                        </span>
                    </div>
                </li>
                <li><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNwH9DCM75f13HIcF0PmBnDf8o2WVrCHk6haHMCNrTlfkO_iqy"
                         class="circle img-xs" alt="">
                    <div class="pack">
                        <span class="group-content">
                            <aside class="pack"><h6>UserNames</h6></aside>
                        </span>
                    </div>
                </li>
                <li><img src="https://ruclip.com/chimg/af/UCunmY844_M6VuX4cTopKdnQ.jpg" class="circle img-xs"
                         alt="">
                    <div class="pack">
        <span class="group-content">
            <aside class="pack"><h6>UserNames</h6></aside>
        </span>
                    </div>
                </li>
                <li><img
                        src="https://previews.123rf.com/images/gmast3r/gmast3r1504/gmast3r150400166/38548354-profile-icon-male-hispanic-avatar-portrait-casual-Stock-Photo.jpg"
                        class="circle img-xs" alt="">
                    <div class="pack">
        <span class="group-content">
            <aside class="pack"><h6>UserNames</h6></aside>
        </span>
                    </div>
                </li>
                <li><img
                        src="http://st2.depositphotos.com/1006318/5909/v/950/depositphotos_59094715-stock-illustration-businessman-profile-icon.jpg"
                        class="circle img-xs" alt="">
                    <div class="pack">
        <span class="group-content">
            <aside class="pack"><h6>UserNames</h6></aside>
        </span>
                    </div>
                </li>
                <li><img src="http://i54.tinypic.com/15otg0n.jpg" class="circle img-xs" alt="">
                    <div class="pack">
        <span class="group-content">
            <aside class="pack"><h6>UserNames</h6></aside>
        </span>
                    </div>
                </li>

            </ul>

        </section>
        <section data-id="tab2" class="tab-content p-0">

            <ul class="list mt-0 ">
                <li><img
                        src="https://st2.depositphotos.com/1006318/5909/v/950/depositphotos_59094043-stock-illustration-profile-icon-male-avatar.jpg"
                        class="circle img-xs" alt="">
                    <div class="pack">
        <span class="group-content">
            <aside class="pack"><h6>UserNames</h6></aside>
        </span>
                    </div>
                </li>
                <li><img
                        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNwH9DCM75f13HIcF0PmBnDf8o2WVrCHk6haHMCNrTlfkO_iqy"
                        class="circle img-xs" alt="">
                    <div class="pack">
        <span class="group-content">
            <aside class="pack"><h6>UserNames</h6></aside>
        </span>
                    </div>
                </li>
                <li><img src="https://ruclip.com/chimg/af/UCunmY844_M6VuX4cTopKdnQ.jpg" class="circle img-xs"
                         alt="">
                    <div class="pack">
        <span class="group-content">
            <aside class="pack"><h6>UserNames</h6></aside>
        </span>
                    </div>
                </li>
                <li><img
                        src="https://previews.123rf.com/images/gmast3r/gmast3r1504/gmast3r150400166/38548354-profile-icon-male-hispanic-avatar-portrait-casual-Stock-Photo.jpg"
                        class="circle img-xs" alt="">
                    <div class="pack">
        <span class="group-content">
            <aside class="pack"><h6>UserNames</h6></aside>
        </span>
                    </div>
                </li>
                <li><img
                        src="http://st2.depositphotos.com/1006318/5909/v/950/depositphotos_59094715-stock-illustration-businessman-profile-icon.jpg"
                        class="circle img-xs" alt="">
                    <div class="pack">
        <span class="group-content">
            <aside class="pack"><h6>UserNames</h6></aside>
        </span>
                    </div>
                </li>
                <li><img src="http://i54.tinypic.com/15otg0n.jpg" class="circle img-xs" alt="">
                    <div class="pack">
        <span class="group-content">
            <aside class="pack"><h6>UserNames</h6></aside>
        </span>
                    </div>
                </li>

            </ul>

        </section>
    </div>

</section>