<div class="wrap xl-flexbox xl-center xl-1">

    @foreach($member_info as $info)
        <div class="col mb-10">
            <div class="wrap xl-flexbox xl-gutter-16 xl-outside-8">
                <div class="col">
                    <img src="{{$info->profile_picture}}" alt="profil resmi" class="img-md circle">
                </div>
                <div class="col">
                    <h6 class="text bold mt-10 text sm">{{$info->name}} {{$info->last_name}}</h6>
                    <span class="text-default text sm">{{$info->interest}}</span> <br>
                    <span class="text-default text sm">{{$info->email}}</span>
                </div>
            </div>

        </div>
        <div class="col bg-default">
            <section class="pack text center-all">
                <aside class="mb-10 mt-10"><i class="text lg icon-mail d-block mb-0 text-red"></i><span
                            class="text xs text-rose bold">123</span></aside>
                <aside class="mb-10 mt-10"><i class="text lg icon-user-plus d-block mb-0 text-primary"></i><span
                            class="text xs text-info bold">{{$friends_info["friends"]}}</span></aside>
                <aside class="mb-10 mt-10"><i class="text lg icon-thumbs-up d-block mb-0 text-teal"></i><span
                            class="text xs text-green bold">12</span></aside>
            </section>
        </div>
        <div class="col mt-20 mb-20">
            <section class="mb-10">
                @php
                    $me = session()->get("member")["nick_name"];
                    $userName = $info->nick_name;
                    $followQuery = App\Models\Member_follow::where('bidder', '=', $me)->where('collocutor', '=', $userName)->count();
                    $friendsQuery = App\Models\Member_friends::where('bidder', '=', $me)->where('collocutor', '=', $userName)->count();
                @endphp
                <div class="w-full p-10 text center-all">
                    @if($followQuery)
                        <button class="btn btn-white btn-sm waves-effect waves-float hoverchanger">
                            <aside class="hover-change-item-1">
                                <i class="icon-check mr-10 text md text-info"></i><span class="text-info">Takiptesin</span>
                            </aside>
                            <aside class="hover-change-item-2">
                                <i class="icon-user-x mr-10 text md text-red "></i><span class="text-red">Takipten çık</span>
                            </aside>
                        </button>
                    @else
                        <button class="btn btn-white  btn-md "><i class="icon-crosshair mr-10 text md"></i>Takip et</button>
                    @endif
                    @if($friendsQuery)
                        <button class="btn btn-white btn-sm waves-effect waves-float hoverchanger " onclick="friends_remove('{{$info->nick_name}}','{{route("remove.friends")}}')">
                            <aside class="hover-change-item-1">
                                <i class="icon-user-check mr-10 text md text-info"></i><span>Arkadaşsınız</span></aside>
                            <aside class="hover-change-item-2">
                                <i class="icon-user-minus mr-10 text md text-red"></i><span class="text-red">Arkadaşlarından çıkar</span>
                            </aside>
                        </button>
                    @else
                        <button class="btn btn-white  btn-md addFriends-btn" onclick="friends_add('{{$info->nick_name}}','{{route("add.friends")}}')">
                            <i class="icon-user-plus mr-10 text md"></i>Arkadaş ekle
                        </button>
                    @endif
                </div>
            </section>
            <p class="text center bg-default text-default p-10">{{$info->about}}</p>
        </div>
        <div class="col">
            <h6 class="text-default text bold left p-20"><i class="icon-activity text lg mr-10 text-rose"></i>Sosyal
                medya hesapları</h6>
            <div class="pack text center-all">
                @if(isset($info))
                    <a href="{{$info->facebook}}" class="btn line btn-primary btn-circle">
                        <i class="icon-facebook text md"></i></a>
                @endif
                @if(isset($info))
                    <a href="{{$info->instagram}}" class="btn line btn-purple btn-circle">
                        <i class="icon-instagram text md"></i></a>
                @endif
                @if(isset($info))
                    <a href="{{$info->twitter}}" class="btn line btn-info btn-circle"><i class="icon-twitter text md"></i>
                    </a>
                @endif
                @if(isset($info))
                    <a href="{{$info->github}}" class="btn line btn-dark btn-circle"><i class="icon-github text md"></i></a>
                @endif
            </div>
        </div>
    @endforeach
</div>