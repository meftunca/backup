<div class="wrap xl-flexbox xl-center xl-1">
    <div class="col mt-20 mb-20">
        <h3 class="text bold text-info">ZERONE DESING </h3>
    </div>
    <div class="col mb-10">
        @if(!empty(Auth::user()->profile_picture))
            @if(str_contains(Auth::user()->profile_picture,["http","www"]))
                <img src="{{Auth::user()->profile_picture}}" alt="" class="img-lg rad-30">
            @else
                <img src="{{asset("img/profile/".Auth::user()->profile_picture)}}" alt="" class="img-lg rad-30">
            @endif
        @else
            <img src="{{asset("img/profile/default.png")}}" alt="" class="img-lg rad-30">
        @endif
        <h6 class="text bold mt-10 text sm">{{Auth::user()->name." ".Auth::user()->last_name}}</h6>
        <span class="text-default text sm">{{strtoupper(Auth::user()->interest)}}</span>
        <div class="mt-20" style="height: 1px; background-color: #999999"></div>
    </div>
    <div class="col">
        <section class=" pack text center-all mb-0">
            <aside class="mb-10 mt-10"><i class="text lg icon-mail d-block mb-0"></i><span class="text xs">123</span></aside>
            <aside class="mb-10 mt-10"><i class="text lg icon-user-plus d-block mb-0"></i><span class="text xs">561</span></aside>
            <aside class="mb-10 mt-10"><i class="text lg icon-thumbs-up d-block mb-0"></i><span class="text xs">12</span></aside>
        </section>
    </div>
    <div class="col">
        <div class="mt-10" style="height: 1px; background-color: #999999"></div>
        <ul class="list line link mt-0">
            <li class="item p-10"><a href="{{url("/member/".Auth::user()->nick_name."/projects")}}">
                    <i class="icon-grid ml-10 mr-10 text lg  text-sublime"></i>
                    <span class="text bold text-black">Projelerin</span></a></li>
            <li class="item p-10"><a href="{{url("/member/blogs")}}"><i class="icon-edit-3 ml-10 mr-10 text lg  text-green"></i>
                    <span class="text bold text-black">Bloguna yaz</span></a></li>
            <li class="item p-10"><a href="#!"><i class="icon-help-circle ml-10 mr-10 text lg  text-rose"></i>
                    <span class="text bold text-black">Soruları cevapla!</span></a></li>
            <li class="item p-10"><a href="#!"><i class="icon-users ml-10 mr-10 text lg  text-blue"></i>
                    <span class="text bold text-black">Arkadaşların</span></a></li>
            <li class="item p-10"><a href="#!"><i class="icon-briefcase ml-10 mr-10 text lg  text-pink"></i>
                    <span class="text bold text-black">Proje ekiplerin</span></a></li>
            <li class="item p-10"><a href="#!"><i class="icon-clipboard ml-10 mr-10 text lg text-warning"></i>
                    <span class="text bold text-black">Yapılacak listen</span></a></li>
            <li class="item p-10"><a href="#!"><i class="icon-check-square ml-10 mr-10 text lg  text-purple"></i>
                    <span class="text bold text-black">Bilgilerini güncelle</span></a></li>
            <li class="item p-10"><a href="#!"><i class="icon-trending-up ml-10 mr-10 text lg  text-black"></i>
                    <span class="text bold text-black">İstatistikler</span></a></li>
        </ul>
    </div>

</div>