<div class="wrap xl-1">
    <div class="col mb-20"><h2 class="text-teal text bold">Harika ! <small class="text-default">Blog yazıları seni bekliyor...</small></h2></div>
    <section class="col">
        <div class="wrap xl-1 ">
            <div class="col">
                <ul class="list box line w-full">
                    @foreach($projects as $blog)
                        <li class="item p-10">
                            <div class="wrap xl-left  xl-flexbox xl-gutter-24">
                                <div class="col xl-1-10"><img src="{{$blog->logo}}" alt="" width="50"></div>
                                <div class="col xl-5-10"><aside>Projeyi oluşturan
                                        <a href="#" class="text-default text bold">{{$blog->creator_nick_name}}</a></aside>
                                </div>
                                <div class="col xl-3-10">
                                   <div class="btn-group">
                                       <a href="{{url("/member/blog/".str_slug($blog->name,"-")."/writer")}}" class="btn btn-rose btn-sm">Yeni makale Yaz</a>
                                       <a href="{{url("/member/blog/info/".str_slug($blog->name,"-"))}}" class="btn btn-info btn-sm">Makalelerini güncelle</a>
                                   </div>
                                </div>
                            </div>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </section>
</div>