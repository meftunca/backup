<div class="wrap xl-flexbox xl-gutter-24">
    <div class="col xl-1-1">
        <section class="card " >
            <div class="card-block"><span class="text md text-default ml-10">Projelerle ilgili haberleri</span></div>
            <div class="list link p-10">
                <section class="item p-10"><img src="http://www.ravijaiswal.com/Afro-v.1.1/img/samples/robert-300.jpg" class="img-sm circle" alt="">
                    <aside class="" style="padding: 0 10px;"> <a href="#!" class="text default text bold">Meftunca </a> <span class="text default"> X projesi için Y kütüphanesini güncelledi...</span>
                        <br><a href="#"><i class="icon-clock"></i> <span class="text xs"> 5 dakika önce</span></a></aside>
                </section>
                <section class="item p-10"><img src="http://www.ravijaiswal.com/Afro-v.1.1/img/samples/robert-300.jpg" class="img-sm circle" alt="">
                    <aside class="" style="padding: 0 10px;"> <a href="#!" class="text default text bold">Meftunca </a> <span class="text default"> X projesi için Y kütüphanesini güncelledi...</span>
                        <br><a href="#"><i class="icon-clock"></i> <span class="text xs"> 5 dakika önce</span></a></aside>
                </section>
                <section class="item p-10"><img src="http://www.ravijaiswal.com/Afro-v.1.1/img/samples/robert-300.jpg" class="img-sm circle" alt="">
                    <aside class="" style="padding: 0 10px;"> <a href="#!" class="text default text bold">Meftunca </a> <span class="text default"> X projesi için Y kütüphanesini güncelledi...</span>
                        <br><a href="#"><i class="icon-clock"></i> <span class="text xs"> 5 dakika önce</span></a></aside>
                </section>
                <section class="item p-10"><img src="http://www.ravijaiswal.com/Afro-v.1.1/img/samples/robert-300.jpg" class="img-sm circle" alt="">
                    <aside class="" style="padding: 0 10px;"> <a href="#!" class="text default text bold">Meftunca </a> <span class="text default"> X projesi için Y kütüphanesini güncelledi...</span>
                        <br><a href="#"><i class="icon-clock"></i> <span class="text xs"> 5 dakika önce</span></a></aside>
                </section>
            </div>
        </section>
    </div>
    <div class="col xl-1-2">
        <div class="card">
            <div class="card-block"><span class="text md text-default ml-10"><i class="icon-bell text lg mr-10"></i>Son bildirimler</span></div>
            <div class="list link p-10">
                <section class="item p-10"><img src="http://www.ravijaiswal.com/Afro-v.1.1/img/samples/robert-300.jpg" class="img-sm circle" alt="">
                    <aside class="" style="padding: 0 10px;"> <a href="#!" class="text default text bold">Gökhan </a>
                        <span class="text default">X projesi için yeni kaynak sunmak istiyor..</span>
                        <br><a href="#"><i class="icon-clock"></i> <span class="text xs"> 5 dakika önce</span></a></aside>
                </section>
                <section class="item p-10"><img src="http://www.ravijaiswal.com/Afro-v.1.1/img/samples/robert-300.jpg" class="img-sm circle" alt="">
                    <aside class="" style="padding: 0 10px;"> <a href="#!" class="text default text bold">Gökhan </a>
                        <span class="text default">X projesi için Y dökümanı kaynağını güncellemek istiyor..</span>
                        <br><a href="#"><i class="icon-clock"></i> <span class="text xs"> 5 dakika önce</span></a></aside>
                </section>
            </div>
        </div>
    </div>
    <div class="col xl-1-2">
        <div class="card">
            <div class="card-block"><span class="text md text-default ml-10"><i class="icon-clipboard text lg mr-10"></i>Projelerin</span></div>
            <div class="list link p-10">
                <section class="item p-10"><img src="https://getbootstrap.com/assets/img/bootstrap-stack.png" class="img-sm circle" alt="">
                    <aside class="" style="padding: 0 10px;"> <a href="#!" class="text default text bold">Bootstrap </a>
                        <span class="text default"> projesi Bugün x kadar görüntülendi.. <br>
                                <a href="#!" class="text-blue">Devamı için...</a></span>
                        <br><a href="#"><i class="icon-clock"></i> <span class="text xs"> 5 dakika önce</span></a></aside>
                </section>
                <section class="item p-10"><img src="http://www.ravijaiswal.com/Afro-v.1.1/img/samples/robert-300.jpg" class="img-sm circle" alt="">
                    <aside class="" style="padding: 0 10px;"> <a href="#!" class="text default text bold">Gökhan </a>
                        <span class="text default">X projesi için Y dökümanı kaynağını güncellemek istiyor..</span>
                        <br><a href="#"><i class="icon-clock"></i> <span class="text xs"> 5 dakika önce</span></a></aside>
                </section>
            </div>
        </div>
    </div>
</div>
