@foreach($notification as $communuty)
   @if($communuty->roles === "communuty")
        @if($communuty->check === 1)
            <div class="notify-item">{!! $communuty->notification_text !!}</div>
        @else
            <div class="notify-item">{!! $communuty->notification_text !!}</div>
        @endif
    @endif
@endforeach
