{{--@foreach($notification as $member)--}}
    {{--@if($member->notify_group === "personal")--}}
        {{--@php--}}
            {{--$MemberModel = (new App\Member());--}}
            {{--$profile_who = $MemberModel->where("nick_name","=",trim($member->who))->get();--}}
            {{--\Carbon\Carbon::setLocale('tr');--}}
            {{--$time = \Carbon\Carbon::parse($member->updated_at)->diffForHumans();--}}
            {{--$who = $member->who;--}}
            {{--$profile_pictures = $profile_who->profile_picture;--}}
            {{--function is_objects ($par){--}}
              {{--return isset($par) ? $par : "";--}}
            {{--}--}}
        {{--@endphp--}}
        {{--@if($member->check !== 1)--}}
            {{--<div class="notify-item notify-new text left p-10 bg-hover-default">--}}
                {{--<section class="item">--}}
                    {{--<img src="{!! $profile_pictures!!}" class="img-sm circle" alt="{{is_objects($who)}} profil resmi">--}}
                    {{--<aside class="pX-10 pY-5">--}}
                        {{--<a href="{{url("/member/".$who)}}" class="text default text bold text lower">{{$who}}</a>--}}
                        {{--adlı üyemiz <span class="text default">--}}
                            {{--@if($member->notify_type === "friends")--}}
                                {{--size arkadaşlık isteği gönderdi...--}}
                                {{--<br>--}}
                                {{--<div class="wrap xl-right">--}}
                                    {{--<button class="btn btn-sm text md btn-white icon-user-x"></button>--}}
                                {{--<button class="btn btn-sm text md btn-white icon-user-plus"></button>--}}
                                {{--</div>--}}
                            {{--@elseif($member->notify_type === "follow")--}}
                                {{--sizi takip etmek istiyor...--}}
                            {{--@endif--}}
                        {{--</span> <br>--}}
                        {{--<a href="#" class="text-dark"><i class="icon-clock"></i> <span class="text xs">{{$time}}</span>--}}
                        {{--</a>--}}
                    {{--</aside>--}}
                {{--</section>--}}
            {{--</div>--}}
        {{--@else--}}
            {{--<div class="notify-item notify-old text left p-10 bg-hover-default">{!!  $member->notification_text !!}</div>--}}

        {{--@endif--}}
    {{--@endif--}}

{{--@endforeach--}}
{{--<div class="notify-item text md text-default"><i class="text lg text-rose icon-check"></i> Topluluk hakkında bir bildiriminiz yok...</div>--}}
