<div class="wrap xl-flexbox xl-center xl-1">
    <div class="col mb-10">
        <img src="https://organicthemes.com/demo/profile/files/2012/12/profile_img.png" alt=""
             class="img-lg rad-30">
        <h6 class="text bold mt-10 text sm">Muhammed burak şentürk</h6>
        <span class="text-default text sm">Fullstack developer</span>
        <div class="mt-20" style="height: 1px; background-color: #999999"></div>
    </div>
    <div class="col">
        <section class=" pack text center-all">
            <aside class="mb-10 mt-10"><i class="text lg icon-mail d-block mb-0"></i><span
                        class="text xs">123</span></aside>
            <aside class="mb-10 mt-10"><i class="text lg icon-user-plus d-block mb-0"></i><span
                        class="text xs">561</span></aside>
            <aside class="mb-10 mt-10"><i class="text lg icon-thumbs-up d-block mb-0"></i><span
                        class="text xs">12</span></aside>
        </section>
    </div>
    <div class="col mt-20 mb-20">
        <p class="text center text-default p-10"> Ipsa labore maxime
            quae quibusdam voluptatibus? Architecto asperiores autem dicta dolorem eos esse et maiores, maxime
            mollitia
            omnis pariatur quaerat quas temporibus!</p>
    </div>
    <div class="col">
        <div class="pack text center-all">
            <a href="#1" class="btn btn-primary btn-circle"><i class="icon-facebook text md"></i></a>
            <a href="#1" class="btn btn-purple btn-circle"><i class="icon-instagram text md"></i></a>
            <a href="#1" class="btn btn-info btn-circle"><i class="icon-twitter text md"></i></a>
            <a href="#1" class="btn btn-dark btn-circle"><i class="icon-github text md"></i></a>
        </div>
        <br>
        <button class="btn btn-success line btn-md ">Takip et</button>
        <button class="btn btn-info line btn-md ">Arkadaş ekle</button>
    </div>

</div>