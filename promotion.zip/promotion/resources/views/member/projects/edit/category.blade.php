@extends('member.master')

@section('content')
    <div class="container">
        <h5 class="text default"><i class="icon-tag mr-10"></i>kategori Düzenle</h5>

        <form action="{{route("create_post_category")}}" method="post" class="d-flex flex-column">
            {{csrf_field()}}
            @foreach($category as $cat)
            <div class="field line mb-0">
                <input type="text" name="framework_name" value="{{$cat->framework_name}}" id="framework_name" onkeypress="query_project('{{route("search_project")}}')" placeholder="Hangi framework için...">
            </div>
            <div class="scrolspy card br-0 mt-0 w-full" style="max-height: 400px" ><ul class="list switch_list mt-0 w-full link rad-0 shadow-1" id="project_search"></ul></div>

            <div class="field line mt-10">
                <input type="text" name="name" placeholder="Kategori adını yazın..." value="{{$cat->name}}">
            </div>
            <div class="field line">
                <h6 class="w-full" style="position: absolute;margin-top: -30px;">Aşağıdaki alana içeriği yazabilirsiniz</h6>
                <textarea name="text" id="text" class="w-full" rows="10" placeholder="" style="visibility: hidden; display: none;">{{$cat->text}}</textarea>
                <script>
                    CKEDITOR.replace('text',{
                        customConfig: '{{asset("ckeditor/adminConfig.js")}}',width :'100%'
                    });
                </script>
            </div>
            @endforeach
            <input type="submit" class="btn btn-md btn-primary" value="Yeni satır ekle">
        </form>

    </div>
@endsection
