@extends('member.master')

@section('content')
    <div class="container">
        <h5 class="text default"><i class="icon-tag mr-10"></i>Küüphane içeriği Düzenle</h5>

        <form action="{{route("create_post_libary_content")}}" method="post" class="d-flex flex-column">
            {{csrf_field()}}

            @foreach($content as $cont)
                <div class="field line mb-0">
                    <input type="text" name="framework_name" id="framework_name"
                           onkeypress="query_project('{{route("search_project")}}')"
                           placeholder="Hangi framework için..." value="{{$cont->framework_name}}">
                </div>
                <div class="scrolspy card br-0 mt-0 w-full" style="max-height: 400px">
                    <ul class="list switch_list mt-0 w-full link rad-0 shadow-1" id="project_search"></ul>
                </div>
                <div class="field line mb-0">
                    <input type="text" name="category_name" id="category_name"
                           onkeypress="query_project_category('{{route("search_project_category")}}')"
                           placeholder="kategori adını yazın..." value="{{$cont->category_name}}">
                </div>
                <div class="scrolspy card br-0 mt-0 w-full" style="max-height: 400px">
                    <ul class="list switch_list mt-0 w-full link rad-0 shadow-1" id="project_category_search" ></ul>
                </div>
                <div class="field line mb-0">
                    <input type="text" name="libary_name" id="libary_name"
                           onkeypress="query_project_libary('{{route("search_project_lib")}}')"
                           placeholder="libary Alanını doldurun..." value="{{$cont->libary_name}}">
                </div>
                <div class="scrolspy card br-0 mt-0 w-full" style="max-height: 400px">
                    <ul class="list switch_list mt-0 w-full link rad-0 shadow-1" id="project_libary_search"></ul>
                </div>

                <div class="field line mt-0">
                    <input type="text" name="name" placeholder="İçerik isim Alanını doldurun..." value="{{$cont->name}}">
                </div>
                <div class="field line">
                    <h4 class="w-full" style="position: absolute;margin-top: -30px;">explanation Alanını doldurun</h4>
                    <textarea name="explanation" id="explanation" class="w-full" rows="10" placeholder=""
                              style="visibility: hidden; display: none;">{{$cont->explanation}}</textarea>
                    <script>
                        CKEDITOR.replace('explanation', {
                            customConfig: '{{asset("ckeditor/adminConfig.js")}}', width: '100%'
                        });
                    </script>
                </div>
                <div class="field line">
                    <textarea name="examples" class="w-full" rows="10"
                              placeholder="examples Alanını doldurun">´{{$cont->examples}}</textarea>
                </div>
            @endforeach

            <input type="submit" class="btn btn-md btn-primary" value="Yeni satır ekle">
        </form>

    </div>
@endsection