@extends('member.master')

@section('content')

    <h5>Projelerinde Ara !!!</h5>
    <div class="field search mb-0 ">
        <input type="text"  name="framework_name" id="framework_name"
               onkeypress="query_project('{{route("search_project_editable")}}')" placeholder="Hangi projen için...">
    </div>
    <ul class="list box mt-20 switch_list w-full" id="project_search"></ul>

@endsection
@section("down")
    <script src="{{asset("js/ajax.js")}}"></script>
@endsection