@extends('member.master')

@section('content')
    <div class="container">
        <h5>Proje Kategorilerinde Ara !!!</h5>
        <div class="list line box" style="overflow: visible">
            <div class="field search  item mb-0">
                <input type="text" id="content_name"
                       onkeypress="query_project_libary('{{route("search_project_lib_content_editable")}}')"
                       placeholder="kategori adını yazın...">
            </div>
            <div class="item">
                <ul class=" switch_list w-full" id="project_libary_content_search"></ul>
            </div>
        </div>
    </div>
@endsection