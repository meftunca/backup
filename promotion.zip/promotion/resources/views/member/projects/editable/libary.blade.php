@extends('member.master')

@section('content')<div class="container">
    <h5>Proje Kategorilerinde Ara !!!</h5>
    <ul class="list line box" style="overflow: visible">
        <div class="field search  dropdown">
            <input type="text" class="dropdown-toggle" name="category_name" id="category_name"
                   onkeypress="query_project_libary('{{route("search_project_lib_editable")}}')"
                   placeholder="kategori adını yazın...">
            <ul class="dropdown-menu mt-50 switch_list w-full" id="project_libary_search"></ul>
        </div>
    </ul>
</div>
@endsection