@extends('member.master')

@section('content')
    <div class="container">
        <h5>Proje notlarında Ara !!!</h5>
        <div class="list line box" style="overflow: visible">
            <div class="field search item mb-0">
                <input type="text"  id="notes_name"
                       onkeypress="query_project_libary_notes('{{route("search_project_lib_notes_editable")}}')"
                       placeholder="kategori adını yazın...">
            </div>
            <div class="mt-0 item">
                <ul class="switch_list w-full" id="project_libary_notes_search"></ul>
            </div>
        </div>
    </div>
@endsection