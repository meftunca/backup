@extends('member.master')

@section('content')
    <div class="container">
        <div class="pack xl-between">
            <h5 class="text default"><i class="icon-tag mr-10"></i>Proje oluştur</h5>
            <a href="{{route("create_category")}}" class="btn-md btn btn-rose">kategori oluştur <i class="icon-chevron-right"></i></a>
        </div>
        @include("member.projects.status.project")
        <form action="{{route("create_post_project")}}" method="post" class="d-flex flex-column">
            {{csrf_field()}}
            <div class="field line">
                <input type="text" name="name" placeholder="Proje adını doldurun...">
            </div>
            <div class="field line">
                <h4 class="w-full" style="position: absolute;margin-top: -30px;">text Alanını doldurun</h4>
                <textarea name="text" id="text" class="w-full" rows="10" placeholder="" style="visibility: hidden; display: none;"></textarea>
                <script>
                    CKEDITOR.replace('text',{
                        customConfig: '{{asset("ckeditor/adminConfig.js")}}',width :'100%'
                    });
                </script>
            </div>
            <div class="field line">
                <input type="text" name="logo" placeholder="logo Alanını doldurun...">
            </div>
            <input type="submit" class="btn btn-md btn-primary" value="Yeni satır ekle">
        </form>

    </div>
@endsection
@section("down")
    <script src="{{asset("js/ajax.js")}}"></script>
@endsection