<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\article;
use Validator;
use App\Http\Controllers\Controller;
class AdminController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:admin');
    }
 

    public function index()
    {
        //table list
        $tableList = DB::select('SHOW TABLES');
        return view('admin.home', ["tableList" => $tableList]);
    }

    public function tableCreate()
    {
        //table list
        $tableList = DB::select('SHOW TABLES');
        return view("admin.tableCreate", ["tableList" => $tableList]);
    }
    public function tableColCreate($name)
    {
        //table list
        $tableList = DB::select('SHOW TABLES');
        return view("admin.tableAddColumn", ["tableList" => $tableList,"tableName"=>$name]);
    }
    public function table($name)
    {
        //table list
        $tableList = DB::select('SHOW TABLES');
        $table = DB::table($name)->get();
        $columns = DB::getSchemaBuilder()->getColumnListing($name);
        return view('admin.table', ['tables' => $table, "columns" => $columns, "tableName" => $name, "tableList" => $tableList]);
    }

    public function rowInsert($name)
    {
        //table list
        $tableList = DB::select('SHOW TABLES');
        $columns = DB::getSchemaBuilder()->getColumnListing($name);
        $addUrl = "/admin/table/$name/add";

        return view('admin.postAddRow', ["columns" => $columns, "tableList" => $tableList, "tableNmae" => $name,'addUrl'=>$addUrl]);
    }

    public function rowEdit($name, $id)
    {
        //table list
        $tableList = DB::select('SHOW TABLES');

        $table = DB::table($name)->where("id", "=", $id)->get();
        $columns = DB::getSchemaBuilder()->getColumnListing($name);
        $editUrl = "/admin/table/$name/update/$id";
        return view('admin.postEdit', ['tables' => $table, "columns" => $columns, "editUrl" => $editUrl, "tableList" => $tableList]);
    }

    public function rowDelete($name, $id)
    {
        $query = DB::table($name)->where("id", "=", $id)->delete();
        return redirect()->back();
    }

    public function postCreate()
    {
        //table list
        $tableList = DB::select('SHOW TABLES');
        return view('admin.postCreate', ["tableList" => $tableList]);
    }
}
