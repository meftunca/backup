<?php

namespace App\Http\Controllers\Frontend;

use Carbon\Carbon;
use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\article;
use function PHPSTORM_META\type;

class PostController extends Controller
{
//    public function __construct()
//    {
//        $this->middleware('auth');
//    }

    public function addComment(Request $request){

        $kind = $request->input("kind");
        $seo_url= $request->input("seo_url");
        $comment = $request->input("comment");
        $data = [
            "kind"=>$kind,
            "seo_url"=>$seo_url,
            "comment"=>$comment,
            "created_at"=>Carbon::now(),
            "updated_at"=>Carbon::now()
        ];
        $query = DB::table("comment")->insert($data);
        if($query){
            return redirect()->back()->with('success', 'Yorumunuz başarıyla eklendi.');
        }else{
            return redirect()->back()->with('error', 'Yorumunuz eklenemedi.');
        }
    }
    public function search(Request $req)
    {
        \Carbon\Carbon::setLocale('tr');

        $val = $req->input("search");
        if($val == ""){
            echo "";
        }else{
            $queryArticle = DB::table("article")->where("title","like","%$val%")->orWhere("text","like","%$val%")->orWhere("kind","like","%$val%")->limit(10)->get();
            $querycategory = DB::table("article")->Where("kind","like","%$val%")->limit(10)->get();

            if(count($querycategory) === 0 && count($queryArticle) === 0){
                echo "<li class='item justify-content-between rad-0' style='border-left:2px solid #f3f3f3;'><span class='text sm'>Maalesef hiçbir sonuç bulunamadı !</span> <i class='icon-alert-triangle text-rose'></i></li>";
            }else{
                if(count($queryArticle) === 0){
                }else{
                    foreach ($queryArticle as $val){
                        $date = \Carbon\Carbon::parse($val->updated_at)->diffForHumans();
                        echo "<li class='item  rad-0' style='border-left:2px solid #FF5733; margin-bottom: 4px;'><a class='d-flex justify-content-between w-full' href='$val->seo_url'>$val->title <span class='text-light'>$date</span></a> </li>";
                    }
                }
                if(count($querycategory) === 0){
                }else{
                    foreach ($querycategory as $val){
                        $date = \Carbon\Carbon::parse($val->updated_at)->diffForHumans();
                        echo "<li class='item  rad-0' style='border-left:2px solid #50CF11; margin-bottom: 4px;'><a  href='".url('/blog/category/'.$val->kind)."'>$val->kind  </li>";
                    }
                }
            }

        }


    }
}
