<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use validator;
class MemberLoginController extends Controller
{
    public function __construct()
    {
        $this->middleware("guest:member");
    }

    public function ShowLogin(){
        return redirect()->intended(route("home"));
    }

    public function Login(Request $request)
    {
       // dd($request->all());
        $this->validate($request, [
            'email' => "required|email",
            "password" => "required|min:6"
        ]);

        if (Auth::guard("member")->attempt(["email" => $request->email, "password" => $request->password], $request->remember)) {
            return redirect()->intended(route("member.home"));
        } else {
            return redirect()->back()->withInput($request->only("email", "remember"));
        }

    }
    public function logout()
    {
        Auth::guard('member')->logout();
        return redirect(route("home"));
    }
}
