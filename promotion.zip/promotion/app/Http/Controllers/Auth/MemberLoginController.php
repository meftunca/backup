<?php

namespace App\Http\Controllers\Auth;

use function collect;
use function count;
use function dd;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use validator;

use Illuminate\Support\Facades\Session;
use App\Member;
class MemberLoginController extends Controller
{
    public function __construct()
    {
        $this->middleware("guest:member");
    }

    public function ShowLogin(){
        return redirect()->intended(route("home"));
    }

    public function Login(Request $request)
    {
        $this->validate($request, [
            'email' => "required|email",
            "password" => "required|min:6"
        ]);

        if (Auth::guard("member")->attempt(["email" => $request->email, "password" => $request->password], $request->remember)) {
           $getUserData = Member::select("nick_name","name","last_name",'email','profile_picture','interest','about','facebook','twitter','instagram','github',"active")->where("email","=",$request->input("email"));
           $getUserData = $getUserData->first();
           Session::put("member",$getUserData->toArray());
            if(count($getUserData->nick_name) > 0){
               $isActive = Member::where("email","=",$request->input("email"))->get();
               $isActive = $isActive->find(1);
             
               //dd($isActive);
               if($isActive){
                  $isActive->active = 1;
                  $isActive->save();
               }
            }
            return redirect()->intended(route("member.home"));
        } else {
            return redirect()->back()->withInput($request->only("email", "remember"));
        }

    }
    public function logout()
    {
       if(count(Session::get("member","nick_name")) > 0){
          
          $isActive = Member::where("nick_name","=",Session::get("member")["nick_name"])->first();
          if($isActive){
             $isActive->active = 0;
             $query = $isActive->save();
             if($query)
                Session::pull("member");
          }
       }
        Auth::guard('member')->logout();
        return redirect(route("home"));
    }
}
