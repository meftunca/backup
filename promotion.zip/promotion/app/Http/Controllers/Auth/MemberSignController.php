<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Auth;
use DB;
class MemberSignController extends Controller
{

    public function showSignin()
    {
        return view("member.part.visitor.registry");
    }

    public function signin(Request $request)
    {

        if (Auth::guard("member")->attempt(["email" => $request->email, "password" => $request->password], $request->remember)) {
          return redirect()->intended(route("member.home"));
        } else {
            $insertMember=[
                "nick_name"=>strtolower($request->nick_name),
                "name"=>$request->name,
                "last_name"=>$request->last_name,
                "password"=>Hash::make($request->password),
                "email"=>$request->email,
                "profile_picture"=>$request->profile_picture,
                "interest"=>$request->interest,
                "about"=>$request->about,
                "facebook"=>$request->facebook,
                "twitter"=>$request->twitter,
                "instagram"=>$request->instagram,
                "github"=>$request->github,
                "remember_token"=>Hash::make($request->password),
                "active"=> "0",
            ];
            $query = DB::table("members")->where("nick_name","=",$request->nick_name)->orwhere("email","=",$request->email)->get();
             if(count($query)===0){
                $query = DB::table("members")->insert($insertMember);
                if($query){
                    return redirect()->intended(route("home"))->with("member_success","Üye başarılı olarak eklendi...<br> artık giriş yapabilirsiniz");
                }else{
                    return redirect()->back()->with("member_error","Üyelik bilgilerinizde hata olabilir...<br> Lütfen tekrar deneyiniz...");
                }
            }else{
                 return redirect()->back()->with("member_warning","Kulanıcı adı veya email hesabıyla farklı bir üyelik zaten alınmış<br> Lütfen farklı bir mail ile tekrar deneyiniz...");
              }
        }

    }
}
