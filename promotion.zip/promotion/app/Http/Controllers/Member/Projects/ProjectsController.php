<?php

namespace App\Http\Controllers\Member\Projects;

use function str_replace;
use function str_slug;
use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\article;

class ProjectsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:member');
    }
    public function index(){
        $projects = DB::table("project")->limit(10)->get();
        $category= DB::table("project_category")->select("name","seo_url")->get();
        $libary= DB::table("project_category_libary")->get();
        $title = "Kızıl Elma Projesi";
        return view("member.projects.home",["projects"=>$projects,"category"=>$category,"title"=>$title]);
    }
    public function project_view($memberName ,$project_name)
    {
        $projectName=$project_name;
        $members=$memberName;
        if(str_contains($memberName,"-")){
            $memberName= str_replace("-"," ",$memberName);
        }
        if(str_contains($project_name,"-")){
            $project_name= str_replace("-"," ",$project_name);
        }
        $project_creator = DB::table("project_creators")->where("creator_nickname","=",$memberName)->where("project_name","=",$project_name)->pluck("project_id");
        $project_creator = $project_creator->toArray();
        $projects = DB::table("project")->whereIn("id",$project_creator)->get();
        $category= DB::table("project_category")->where("framework_name","=",$project_name)->distinct()->get();
        return view("projects.projects",["projects"=>$projects,"category"=>$category]);
    }
    public function docs($memberName,$project_name,$name)
    {
        $projectName=$project_name;
        $members=$memberName;
        $category_name = $name;
        if(str_contains($memberName,"-")){
            $memberName= str_replace("-"," ",$memberName);
        }
        if(str_contains($project_name,"-")){
            $project_name= str_replace("-"," ",$project_name);
        }

        if(str_contains($name,"-")){
            $name= str_replace("-"," ",$name);
        }

        $projects =  DB::table("project")->where("seo_url","=",$projectName)->join('project_creators', function ($join) {
            $join->on('project.id', '=', 'project_creators.project_id')
                ->where('project_creators.check', '=', 1);
        })->get();

        $category= DB::table("project_category")->where("seo_url","=",$category_name)->join('project_category_creators', function ($join) {
            $join->on('project_category.id', '=', 'project_category_creators.category_id')
                ->where('project_category_creators.check', '=', 1);
        })->get();

        $libary= DB::table("project_category_libary")->where("framework_name","=",$project_name)->join('project_libary_creators', function ($join) {
            $join->on('project_category_libary.id', '=', 'project_libary_creators.libary_id')
                ->where('project_libary_creators.check', '=', 1);
        })->get();
        return view("projects.category",["projects"=>$projects,"category"=>$category,"libary"=>$libary]);
    }
    public function libary($memberName,$project_name,$categoryName,$libaries)
    {

        $projectName=$project_name;
        $category_name = $categoryName;
        $members=$memberName;
         if(str_contains($memberName,"-")){
            $memberName= str_replace("-"," ",$memberName);
        }
        if(str_contains($project_name,"-")){
            $project_name= str_replace("-"," ",$project_name);
        }
        if(str_contains($categoryName,"-")){
            $categoryName= str_replace("-"," ",$categoryName);
        }
        if(str_contains($libaries,"-")){
            $libaries = str_replace("-"," ",$libaries);
        }
        $projects =  DB::table("project")->where("seo_url","=",$projectName)->join('project_creators', function ($join) {
            $join->on('project.id', '=', 'project_creators.project_id')
                ->where('project_creators.check', '=', 1);
        })->get();

        $category= DB::table("project_category")->where("seo_url","=",$category_name)->join('project_category_creators', function ($join) {
            $join->on('project_category.id', '=', 'project_category_creators.category_id')
                ->where('project_category_creators.check', '=', 1);
        })->get();

        $libary= DB::table("project_category_libary")->where("framework_name","=",$project_name)->join('project_libary_creators', function ($join) {
            $join->on('project_category_libary.id', '=', 'project_libary_creators.libary_id')
                ->where('project_libary_creators.check', '=', 1);
        })->get();
        $content_lib= DB::table("project_category_libary_content")->where("category_name","=",$categoryName)->where("libary_name","=",$libaries)->get();
        $notes= DB::table("project_category_libary_notes")->where("category_name","=",$categoryName)->where("libary_name","=",$libaries)->get();
        $content= DB::table("project_category_libary")->where("category_name","=",$categoryName)->where("seo_url","=",$libaries)->get();
        return view("projects.libary",["projects"=>$projects,"category"=>$category,"libary"=>$libary,"content"=>$content,"content_lib"=>$content_lib,"notes"=>$notes]);
    }
    // ** member  part **

    // ** create part **
    public function  project (){
       return view('member.projects.project',[]);
    }

    public function  category (){
        return view('member.projects.category',[]);
    }

    public function  libaries (){
        return view('member.projects.libary',[]);
    }

    public function  libary_content (){
        return view('member.projects.libary_content',[]);
    }

    public function  libary_notes (){
        return view('member.projects.libary_notes',[]);
    }


    // ** edit part **
    public function  e_project ($id){
        $project = DB::table("project")->where("id","=",$id)->get();
        if(count($project) === 0){
            return redirect()->back();
        }else{
            return view('member.projects.edit.project',["project"=>$project]);
        }
    }

    public function  e_category ($id){
        $category= DB::table("project_category")->where("id","=",$id)->get();
        if(count($category) === 0){
            return redirect()->back();
        }else{
            return view('member.projects.edit.category',["category"=>$category]);
        }
    }

    public function  e_libaries ($id){
        $libary= DB::table("project_category_libary")->where("id","=",$id)->get();
        if(count($libary) === 0){
            return redirect()->back();
        }else{
            return view('member.projects.edit.libary',["libary"=>$libary]);
        }
    }

    public function  e_libary_content ($id){
        $content= DB::table("project_category_libary_content")->where("id","=",$id)->get();
        if(count($content) === 0){
            return redirect()->back();
        }else{
            return view('member.projects.edit.libary_content',["content"=>$content]);
        }
    }

    public function  e_libary_notes ($id){
        $notes= DB::table("project_category_libary_notes")->where("id","=",$id)->get();
        if(count($notes) === 0){
            return redirect()->back();
        }else{
            return view('member.projects.edit.libary_notes',["notes"=>$notes]);
        }
    }

    // ** editable part **
    public function  editable_project (){
        $projects = DB::table("project")->select("id","name","seo_url","updated_at")->orderBy('id', 'desc')->get();
        return view('member.projects.editable.project',["projects"=>$projects]);
    }

    public function  editable_category (){
        return view('member.projects.editable.category',[]);
    }

    public function  editable_libaries (){
        return view('member.projects.editable.libary',[]);
    }

    public function  editable_libary_content (){
        return view('member.projects.editable.libary_content',[]);
    }

    public function  editable_libary_notes (){
        return view('member.projects.editable.libary_notes',[]);
    }

    // ** Blog writer **
    public function articleWriter($project_name){
        return view('member.blog.post.create_article',[]);
    }
    public function articleInfo($project_name){
       //article get
       $article = DB::table("project_blog_article")->select("id","project_name","kind","author","title","picture","author_picture","updated_at")->where("project_name","=",str_replace("-"," ",$project_name))->get();
         return view('member.blog.profile_segment.article_edit',["articles"=>$article]);
    }
   public function articleUpdater($project_name,$id){
       $article = DB::table("project_blog_article")->where("project_name","=",str_slug($project_name,"-"))->where("id","=",$id)->get();
      return view('member.blog.post.update_article',["article"=>$article]);
   }
}
