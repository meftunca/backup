<?php

namespace App\Http\Controllers\Member\Projects;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PostController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:member');
    }

    //create part
    public function project(Request $request)
    {

        $insertData = [
            "creator_nick_name" => Auth::user()->nick_name,
            "name" => $request->input("name"),
            "text" => $request->input("text"),
            "logo" => $request->input("logo"),
            "seo_url" => str_slug($request->input("name"), "-"),
            "created_at" => Carbon::now('Europe/Istanbul'),
            "updated_at" => Carbon::now('Europe/Istanbul')
        ];

        $insert = DB::table("project")->insert($insertData);
        $lastId = DB::getPdo()->lastInsertId();
        if ($insert) {
            $creatorData = [
                "creator_nickname" => Auth::user()->nick_name,
                "project_name" => $request->input("name"),
                "project_id" => $lastId,
                "check" => "0"
            ];
            $creators = DB::table("project_creators")->insert($creatorData);
            if ($creators) {
                return redirect()->back()->with("project_success", "Verileriniz başarıyla eklendi...");
            } else {
                return redirect()->back()->with("project_warning", "Verileriniz başarıyla eklenemedi, bazı konularda ufak bir aksaklık oluştu lütfen sistem sahipleriyle iletişime geçin...");
            }
        } else {
            return redirect()->back()->with("project_danger", "Verileriniz başarıyla eklenemedi, bazı konularda ufak bir aksaklık oluştu lütfen sistem sahipleriyle iletişime geçin...");
        }
    }

    public function category(Request $request)
    {

        $insertData = ["name" => $request->input("name"),
            "text" => $request->input("text"),
            "framework_name" => $request->input("framework_name"),
            "seo_url" => str_slug($request->input("logo"), "-"),
            "created_at" => Carbon::now('Europe/Istanbul'),
            "updated_at" => Carbon::now('Europe/Istanbul')
        ];
        $insert = DB::table("project_category")->insert($insertData);
        $lastId = DB::getPdo()->lastInsertId();
        if ($insert) {
            $project_id = DB::table("project")->where("name", "=", $request->input("framework_name"))->pluck("id");
            $creatorData = [
                "creator_nickname" => Auth::user()->nick_name,
                "project_name" => $request->input("framework_name"),
                "project_id" => $project_id[0],
                "category_name" => $request->input("name"),
                "category_id" => $lastId,
                "check" => "0"
            ];
            $creators = DB::table("project_category_creators")->insert($creatorData);
            if ($creators) {
                return redirect()->back()->with("project_success", "Verileriniz başarıyla eklendi...");
            } else {
                return redirect()->back()->with("project_warning", "Verileriniz başarıyla eklenemedi, bazı konularda ufak bir aksaklık oluştu lütfen sistem sahipleriyle iletişime geçin...");
            }
        } else {
            return redirect()->back()->with("project_danger", "Verileriniz başarıyla eklenemedi, bazı konularda ufak bir aksaklık oluştu lütfen sistem sahipleriyle iletişime geçin...");
        }
    }

    public function libary(Request $request)
    {

        $insertData = ["name" => $request->input("name"),
            "text" => $request->input("text"),
            "framework_name" => $request->input("framework_name"),
            "category_name" => $request->input("category_name"),
            "seo_url" => str_slug($request->input("logo"), "-"),
            "created_at" => Carbon::now('Europe/Istanbul'),
            "updated_at" => Carbon::now('Europe/Istanbul')
        ];
        $insert = DB::table("project_category_libary")->insert($insertData);
        $lastId = DB::getPdo()->lastInsertId();
        if ($insert) {
            $project_id = DB::table("project")->where("name", "=", $request->input("framework_name"))->pluck("id");
            $category_id = DB::table("project_category")->where("name", "=", $request->input("category_name"))->pluck("id");
            $creatorData = [
                "creator_nickname" => Auth::user()->nick_name,
                "project_name" => $request->input("framework_name"),
                "project_id" => $project_id[0],
                "category_name" => $request->input("category_name"),
                "category_id" => $category_id[0],
                "libary_name" => $request->input("name"),
                "libary_id" => $lastId,
                "check" => "0"
            ];
            $creators = DB::table("project_libary_creators")->insert($creatorData);
            if ($creators) {
                return redirect()->back()->with("project_success", "Verileriniz başarıyla eklendi...");
            } else {
                return redirect()->back()->with("project_warning", "Verileriniz başarıyla eklenemedi, bazı konularda ufak bir aksaklık oluştu lütfen sistem sahipleriyle iletişime geçin...");
            }
        } else {
            return redirect()->back()->with("project_danger", "Verileriniz başarıyla eklenemedi, bazı konularda ufak bir aksaklık oluştu lütfen sistem sahipleriyle iletişime geçin...");
        }
    }


    public function libary_content(Request $request)
    {

        $insertData = ["name" => $request->input("name"),
            "explanation" => $request->input("explanation"),
            "examples" => $request->input("examples"),
            "framework_name" => $request->input("framework_name"),
            "category_name" => $request->input("category_name"),
            "libary_name" => $request->input("libary_name"),
            "seo_url" => str_slug($request->input("logo"), "-"),
            "created_at" => Carbon::now('Europe/Istanbul'),
            "updated_at" => Carbon::now('Europe/Istanbul')
        ];
        $insert = DB::table("project_category_libary_content")->insert($insertData);
        $lastId = DB::getPdo()->lastInsertId();

        if ($insert) {
            $project_id = DB::table("project")->where("name", "=", $request->input("framework_name"))->pluck("id");
            $category_id = DB::table("project_category")->where("name", "=", $request->input("category_name"))->pluck("id");
            $libary_id = DB::table("project_category_libary")->where("name", "=", $request->input("libary_name"))->pluck("id");
            $creatorData = [
                "creator_nickname" => Auth::user()->nick_name,
                "project_name" => $request->input("framework_name"),
                "project_id" => $project_id[0],
                "category_name" => $request->input("category_name"),
                "category_id" => $category_id[0],
                "libary_name" => $request->input("name"),
                "libary_id" => $libary_id[0],
                "libary_content_name" => $request->input("name"),
                "libary_content_id" => $lastId,
                "check" => "0"
            ];
            $creators = DB::table("project_libary_content_creators")->insert($creatorData);
            if ($creators) {
                return redirect()->back()->with("project_success", "Verileriniz başarıyla eklendi...");
            } else {
                return redirect()->back()->with("project_warning", "Verileriniz başarıyla eklenemedi, bazı konularda ufak bir aksaklık oluştu lütfen sistem sahipleriyle iletişime geçin...");
            }
        } else {
            return redirect()->back()->with("project_danger", "Verileriniz başarıyla eklenemedi, bazı konularda ufak bir aksaklık oluştu lütfen sistem sahipleriyle iletişime geçin...");
        }
    }


    public function libary_notes(Request $request)
    {

        $insertData = ["name" => $request->input("name"),
            "content_name" => $request->input("content_name"),
            "notes" => $request->input("notes"),
            "framework_name" => $request->input("framework_name"),
            "category_name" => $request->input("category_name"),
            "libary_name" => $request->input("libary_name"),
            "seo_url" => str_slug($request->input("logo"), "-"),
            "created_at" => Carbon::now('Europe/Istanbul'),
            "updated_at" => Carbon::now('Europe/Istanbul')
        ];
        $insert = DB::table("project_category_libary_notes")->insert($insertData);
        $lastId = DB::getPdo()->lastInsertId();
        if ($insert) {
            $project_id = DB::table("project")->where("name", "=", $request->input("framework_name"))->pluck("id");
            $category_id = DB::table("project_category")->where("name", "=", $request->input("category_name"))->pluck("id");
            $libary_id = DB::table("project_category_libary")->where("name", "=", $request->input("libary_name"))->pluck("id");
            $content_id = DB::table("project_category_libary_content")->where("name", "=", $request->input("content_name"))->pluck("id");
            $creatorData = [
                "creator_nickname" => Auth::user()->nick_name,
                "project_name" => $request->input("framework_name"),
                "project_id" => $project_id[0],
                "category_name" => $request->input("category_name"),
                "category_id" => $category_id[0],
                "libary_name" => $request->input("libary_name"),
                "libary_id" => $libary_id[0],
                "libary_content_name" => $request->input("content_name"),
                "libary_content_id" => $content_id[0],
                "libary_note_name" => $request->input("name"),
                "libary_note_id" => $lastId,
                "check" => "0"
            ];
            $creators = DB::table("project_libary_notes_creators")->insert($creatorData);
            if ($creators) {
                return redirect()->back()->with("project_success", "Verileriniz başarıyla eklendi...");
            } else {
                return redirect()->back()->with("project_warning", "Verileriniz başarıyla eklenemedi, bazı konularda ufak bir aksaklık oluştu lütfen sistem sahipleriyle iletişime geçin...");
            }
        } else {
            return redirect()->back()->with("project_danger", "Verileriniz başarıyla eklenemedi, bazı konularda ufak bir aksaklık oluştu lütfen sistem sahipleriyle iletişime geçin...");
        }
    }


    //edit part
    public function e_project($id, Request $request)
    {
        $name = "project_project";
        $columns = DB::getSchemaBuilder()->getColumnListing($name);
        $count = count($columns) - 3;
        $updateData = [];
        for ($i = 1; $i <= $count; $i++) {
            $updateData[$columns[$i]] = $request->input($columns[$i]);
        }
        $insertData["updated_at"] = Carbon::now('Europe/Istanbul');

        $updateQuery = DB::table($name)->where("id", "=", $id)->update($updateData);
        if ($updateQuery) {
            return redirect()->back();
        } else {
            return redirect()->back()->withErrors($updateQuery)->withInput();
        }
    }

    public function e_category($id, Request $request)
    {
        $name = "project_category";
        $columns = DB::getSchemaBuilder()->getColumnListing($name);
        $count = count($columns) - 3;
        $updateData = [];
        for ($i = 1; $i <= $count; $i++) {
            $updateData[$columns[$i]] = $request->input($columns[$i]);
        }
        $insertData["updated_at"] = Carbon::now('Europe/Istanbul');

        $updateQuery = DB::table($name)->where("id", "=", $id)->update($updateData);
        if ($updateQuery) {
            return redirect()->back();
        } else {
            return redirect()->back()->withErrors($updateQuery)->withInput();
        }
    }

    public function e_libary($id, Request $request)
    {
        $name = "project_libary";
        $columns = DB::getSchemaBuilder()->getColumnListing($name);
        $count = count($columns) - 3;
        $updateData = [];
        for ($i = 1; $i <= $count; $i++) {
            $updateData[$columns[$i]] = $request->input($columns[$i]);
        }
        $insertData["updated_at"] = Carbon::now('Europe/Istanbul');

        $updateQuery = DB::table($name)->where("id", "=", $id)->update($updateData);
        if ($updateQuery) {
            return redirect()->back();
        } else {
            return redirect()->back()->withErrors($updateQuery)->withInput();
        }
    }

    public function e_libary_content($id, Request $request)
    {
        $name = "project_libary_content";
        $columns = DB::getSchemaBuilder()->getColumnListing($name);
        $count = count($columns) - 3;
        $updateData = [];
        for ($i = 1; $i <= $count; $i++) {
            $updateData[$columns[$i]] = $request->input($columns[$i]);
        }
        $insertData["updated_at"] = Carbon::now('Europe/Istanbul');

        $updateQuery = DB::table($name)->where("id", "=", $id)->update($updateData);
        if ($updateQuery) {
            return redirect()->back();
        } else {
            return redirect()->back()->withErrors($updateQuery)->withInput();
        }
    }

    public function e_libary_notes($id, Request $request)
    {
        $name = "project_libary_notes";
        $columns = DB::getSchemaBuilder()->getColumnListing($name);
        $count = count($columns) - 3;
        $updateData = [];
        for ($i = 1; $i <= $count; $i++) {
            $updateData[$columns[$i]] = $request->input($columns[$i]);
        }
        $insertData["updated_at"] = Carbon::now('Europe/Istanbul');

        $updateQuery = DB::table($name)->where("id", "=", $id)->update($updateData);
        if ($updateQuery) {
            return redirect()->back();
        } else {
            return redirect()->back()->withErrors($updateQuery)->withInput();
        }
    }

    //search
    public function project_search()
    {
        $query = $_GET["query"];
        $query_arr = DB::table("project")->where("name", "like", "%$query%")->limit(10)->get();
        foreach ($query_arr as $wr) {
            echo "<li class='item'><a href='#!' data-input-name='framework_name' onclick='switch_list(this)'>$wr->name</a></li>";
        }
    }

    public function project_category_search()
    {
        $query = $_GET["query"];
        $query_arr = DB::table("project_category")->where("name", "like", "%$query%")->limit(10)->get();
        foreach ($query_arr as $wr) {
            echo "<li class='item'><a href='#!' data-input-name='category_name' onclick='switch_list(this)'>$wr->name</a></li>";
        }
    }

    public function project_libary_search()
    {
        $query = $_GET["query"];
        $query_arr = DB::table("project_category_libary")->where("name", "like", "%$query%")->limit(10)->get();
        foreach ($query_arr as $wr) {
            echo "<li class='item'><a href='#!' data-input-name='libary_name' onclick='switch_list(this)'>$wr->name</a></li>";
        }
    }

    public function project_libary_content_search()
    {
        $query = $_GET["query"];
        $query_arr = DB::table("project_category_libary_content")->where("name", "like", "%$query%")->limit(10)->get();
        foreach ($query_arr as $wr) {
            echo "<li class='item'><a href='#!' data-input-name='content_name' onclick='switch_list(this)'>$wr->name</a></li>";
        }
    }

    public function project_all_info()
    {
        $query = $_GET["query"];
        $query_arr_project = DB::table("project")->where("name", "like", "%$query%")->limit(3)->get();
        $query_arr_category = DB::table("project_category")->where("name", "like", "%$query%")->limit(3)->get();
        $query_arr_libary = DB::table("project_category_libary")->where("name", "like", "%$query%")->limit(3)->get();
        $query_arr_content = DB::table("project_category_libary_content")->where("name", "like", "%$query%")->limit(3)->get();
        $query_arr_notes = DB::table("project_category_libary_content")->where("name", "like", "%$query%")->limit(3)->get();
        foreach ($query_arr_project as $wr) {
            echo "<li class='item' style='border-radius:0 !important;border-left: 4px solid #C70039 !important;margin-bottom: 2px;'>
                <a href='" . url('/') . "/member/edit/projects/" . $wr->id . "' data-input-name='framework_name' onclick='switch_list(this)'>$wr->name</a></li>";
        }
        foreach ($query_arr_category as $wr) {
            echo "<li class='item' style='border-radius:0 !important;border-left: 4px solid #017EF4 !important;margin-bottom: 2px;'>
                <a href='href='" . url('/') . "/member/edit/category/" . $wr->id . "' data-input-name='category_name' onclick='switch_list(this)'>$wr->name</a></li>";
        }
        foreach ($query_arr_libary as $wr) {
            echo "<li class='item' style='border-radius:0 !important;border-left: 4px solid #01F460 !important;margin-bottom: 2px;'>
                <a href='href='" . url('/') . "/member/edit/libary/" . $wr->id . "' data-input-name='libary_name' onclick='switch_list(this)'>$wr->name</a></li>";
        }
        foreach ($query_arr_content as $wr) {
            echo "<li class='item' style='border-radius:0 !important;border-left: 4px solid #F401DA !important;margin-bottom: 2px;'>
                <a href='href='" . url('/') . "/member/edit/libary_content/" . $wr->id . "' data-input-name='content_name' onclick='switch_list(this)'>$wr->name</a></li>";
        }
        foreach ($query_arr_notes as $wr) {
            echo "<li class='item' style='border-radius:0 !important;border-left: 4px solid #E5F401 !important;margin-bottom: 2px;'>
                <a href='href='" . url('/') . "/member/edit/libary_notes/" . $wr->id . "' data-input-name='content_name' onclick='switch_list(this)'>$wr->name</a></li>";
        }
    }

    //search editable
    public function project_search_editable()
    {
        $query = $_GET["query"];
        $query_arr = DB::table("project")->where("name", "like", "%$query%")->limit(10)->get();
        foreach ($query_arr as $wr) {
            echo "<li class='item justify-content-between'><a href='" . route("search_project_editable") . "' data-input-name='framework_name' onclick='switch_list(this)'>$wr->name</a>
                <div class='btn-group'><a href='" . url('member/edit/projects/' . $wr->id) . "' class='btn btn-sm btn-info icon-edit'> Düzenle</a>
                <a href='" . url('member/projects/' . $wr->id) . "' class='btn btn-sm btn-rose icon-trash-2'> sil</a></div>
            </li>";
        }
    }

    public function project_category_search_editable()
    {
        $query = $_GET["query"];
        $query_arr = DB::table("project_category")->where("name", "like", "%$query%")->limit(10)->get();
        foreach ($query_arr as $wr) {
            echo "<li class='item justify-content-between'><a href='" . route("search_project_category_editable") . "' data-input-name='category_name' onclick='switch_list(this)'>$wr->name</a>
                <div class='btn-group'><a href='" . url("member/edit/category/" . $wr->id) . "' class='btn btn-sm btn-info icon-edit'> Düzenle</a>
                <a href='" . url('member/category/' . $wr->id) . "' class='btn btn-sm btn-rose icon-trash-2'> sil</a></div>
            </li>";
        }
    }

    public function project_libary_search_editable()
    {
        $query = $_GET["query"];
        $query_arr = DB::table("project_category_libary")->where("name", "like", "%$query%")->limit(10)->get();
        foreach ($query_arr as $wr) {
            echo "<li class='item justify-content-between'><a href='" . route("search_project_lib_editable") . "' data-input-name='libary_name' onclick='switch_list(this)'>$wr->name</a>
                <div class='btn-group'><a  href='" . url("member/edit/libary/" . $wr->id) . "' class='btn btn-sm btn-info icon-edit'> Düzenle</a>
                <a  href='" . url('member/libary/' . $wr->id) . "' class='btn btn-sm btn-rose icon-trash-2'> sil</a></div>
            </li>";
        }
    }

    public function project_libary_content_search_editable()
    {
        $query = $_GET["query"];
        $query_arr = DB::table("project_category_libary_content")->where("name", "like", "%$query%")->limit(10)->get();
        foreach ($query_arr as $wr) {
            echo "<li class='item justify-content-between'><a href='" . route("search_project_lib_content_editable") . "' data-input-name='content_name' onclick='switch_list(this)'>$wr->name</a>
                <div class='btn-group'><a href='" . url("member/edit/libary_content/" . $wr->id) . "' class='btn btn-sm btn-info icon-edit'> Düzenle</a>
                <a href='" . url('member/libary_content/' . $wr->id) . "' class='btn btn-sm btn-rose icon-trash-2'> sil</a></div>
            </li>";
        }
    }

    public function project_libary_notes_search_editable()
    {
        $query = $_GET["query"];
        $query_arr = DB::table("project_category_libary_notes")->where("name", "like", "%$query%")->limit(10)->get();
        foreach ($query_arr as $wr) {
            echo "<li class='item justify-content-between'><a href='" . route("search_project_lib_notes_editable") . "' data-input-name='content_name' onclick='switch_list(this)'>$wr->name</a>
                <div class='btn-group'><a href='" . url("member/edit/libary_notes/" . $wr->id) . "' class='btn btn-sm btn-info icon-edit'> Düzenle</a>
                <a href='" . url('member/libary_notes/' . $wr->id) . "' class='btn btn-sm btn-rose icon-trash-2'> sil</a></div>
            </li>";
        }
    }
}
