<?php
   
   namespace App\Http\Controllers\Member\Projects\Blog;
   
   use Carbon\Carbon;
   use function dd;
   use function json_encode;
   use function print_r;
   use function redirect;
   use function str_slug;
   use function url;
   use Validator;
   use Illuminate\Http\Request;
   use App\Http\Controllers\Controller;
   use Illuminate\Support\Facades\Auth;
   use Illuminate\Support\Facades\DB;
   use App\article;
   use function PHPSTORM_META\type;
   use Illuminate\Support\Facades\Session;
   
   class PostController extends Controller
   {
      public function __construct ()
      {
         $this->middleware('auth:member');
      }
      
      public function blogPost (Request $request)
      {
         
         \Carbon\Carbon::setLocale('tr');
         $insertData = [
             "kind"           => $request->input("kind"),
             "author"         => Auth::user()->nick_name,
             "author_picture" => Auth::user()->profile_picture,
             "title"          => $request->input("title"),
             "seo_url"        => str_slug($request->input("title"), "-"),
             "text"           => $request->input("text"),
             "project_name"   => $request->input("project_name"),
             "picture"        => $request->input("picture"),
             "created_at"     => Carbon::now(),
             "updated_at"     => Carbon::now()
         ];
         $article = DB::table("project_blog_article");
         if ($article->where("project_name", "=", $request->input("project_name"))->where("title", "=", $request->input("title"))->count() > 0) {
            Session::flash('error', "Maalesef aynı isimde başka bir yazı yazmışsınız.");
         } else {
            $insert = $article->insert($insertData);
            if ($insert) {
               $catQuery = DB::table("project_blog_category")->where("project_name", "=", $request->input("project_name"))->where("category_name", "=", $request->input("kind"));
               $oldCat = $catQuery->count();
               
               if ($oldCat > 0) {
                  $catCount = $article->where("project_name", "=", $request->input("project_name"))->where("kind", "=", $request->input("kind"))->count();
                  $updateData = [
                      "category_len" => $catCount + 1,
                      "updated_at"   => Carbon::now()
                  ];
                  $query = $catQuery->update($updateData);
                  if ($query) {
                     Session::flash('success', "Blog yazınız başarılı olarak eklendi.Projenizin blog sayfanızdan görüntüleyebilirsiniz.");
                  } else {
                     Session::flash('warning', "Bilinmeyen bir hata oluştu. Yazınız eklendi ama yapıda açık bulundu. Biz durumu düzeltene kadar yaznızın yedeğini alabilirsiniz.");
                  }
                  
               } else {
                  $insertData2 = [
                      "project_name"  => $request->input("project_name"),
                      "category_name" => $request->input("kind"),
                      "category_len"  => "1",
                      "created_at"    => Carbon::now(),
                      "updated_at"    => Carbon::now()
                  ];
                  $query = $catQuery->insert($insertData2);
                  if ($query) {
                     Session::flash('success', "Blog yazınız başarılı olarak eklendi.Projenizin blog sayfanızdan görüntüleyebilirsiniz.");
                     return redirect()->back();
                  } else {
                     Session::flash('warning', "Bilinmeyen bir hata oluştu. Yazınız eklendi ama yapıda açık bulundu. Biz durumu düzeltene kadar yaznızın yedeğini alabilirsiniz.");
                  }
               }
               
            } else {
               Session::flash('error', "Maalesef yazınız eklenemedi. Sunucuda bir hata olabilir. Lütfen sorunu site yetkilisine bildirin...");
            }
         }
         return redirect()->back();
         
      }
      
      public function articleDelete ($id)
      {
         
         $article = DB::table("project_blog_article")->where("id", "=", $id)->where("author", "=", Auth::user()->nick_name);
         if ($article->count() > 0) {
            $query = $article->delete(["id" => $id]);
            if ($query) {
               Session::flash('success', "Blog yazınız başarılı olarak silindi..Projenizin blog sayfanızdan güncel halinis görüntüleyebilirsiniz.");
            } else {
               Session::flash('warning', "Bilinmeyen bir hata oluştu. Yazınız silinemedi... Bu tip olayların teknik bir hatadan dolayı olma ihtimali yüksek bir olay, lütfen bizimle iletişime geçip durumu bildirin... Şimdiden teşekkürler");
            }
         } else {
            Session::flash('error', "Bu blog yazısını silmeye yetkiniz yok... eğer bu tarz uygunsuz veri silmeye kalkarsanız hesabınız engellenecektir. Ayrıca vermiş olduğunuz bilgiler ışığında hakkınızda Hukuksuz olarak 'Siber Saldırı' adıyla emniyet genel müdürlüğüne suç duyurusunda bulunulacaktır...");
         }
         return redirect()->back();
      }
      
      public function articleUpdate (Request $request)
      {
         \Carbon\Carbon::setLocale('tr');
         $updateData = [
             "kind"       => $request->input("kind"),
             "title"      => $request->input("title"),
             "text"       => $request->input("text"),
             "picture"    => $request->input("picture"),
             "updated_at" => Carbon::now()
         ];
         $article = DB::table("project_blog_article")->where("id", "=", $request->input("id"))->where("author", "=", Auth::user()->nick_name);
         if ($article->count() > 0) {
            $query = $article->update($updateData);
            if ($article) {
               Session::flash('success', "Blog yazınız başarılı olarak güncellendi..Projenizin blog sayfanızdan güncel halinis görüntüleyebilirsiniz.");
            } else {
               Session::flash('error', "Bilinmeyen bir hata oluştu. Yazınız güncellenemedi... Bu tip olayların teknik bir hatadan dolayı olma ihtimali yüksek bir olay, lütfen bizimle iletişime geçip durumu bildirin... Şimdiden teşekkürler");
            }
         } else {
            Session::flash('error', "Bu blog yazısını güncellemeye yetkiniz yok... eğer bu tarz uygunsuz veri silmeye kalkarsanız hesabınız engellenecektir. Ayrıca vermiş olduğunuz bilgiler ışığında hakkınızda Hukuksuz olarak 'Siber Saldırı' adıyla emniyet genel müdürlüğüne suç duyurusunda bulunulacaktır...");
         }
         
         return redirect()->back();
         
      }
      
      public function addComment (Request $request)
      {
         $insertData = [
             "project_name"        => $request->input("project_name"),
             "article_name"        => $request->input("article_name"),
             "commentator"         => $request->input("commentator"),
             "commentator_picture" => $request->input("commentator_picture"),
             "comment"             => $request->input("comment"),
             "created_at"          => Carbon::now(),
             "updated_at"          => Carbon::now()
         ];
         $articleCommentDb = DB::table("project_blog_article_comment");
         $insertComment = $articleCommentDb->insert($insertData);
         if ($insertComment) {
            //eğer yorum eklendiyse ...
            $notification = DB::table("member_notification");//yazar için bildirim gönder
            $notifyData = [
                'nick_name'         => $request->input("author"),
                "who"               => $request->input("commentator"),
                'notify_group'      => "communuty",
                'notify_type'       => "comment",
                'notify_target'     => $request->input("article_name"),
                'check'             => 0,
                "created_at"        => Carbon::now(),
                "updated_at"        => Carbon::now()
            ];
            $notifyQuery = $notification->insert($notifyData);
            if ($notifyQuery) {
               Session::flash("success", "Yorumunuz başarılı olarak eklendi...");
               return redirect()->back();
            } else {
               Session::flash("warning", "Yorumunuz eklenirken hata oluştu...");
               return redirect()->back();
            }
         } else {
            Session::flash("error", "Yorumunuz eklenemedi...<br> Sunucuda bir ağrıza olabilir, lütfen başka bir zaman yorum yapın.<br> Hata için özür dileriz...");
            return redirect()->back();
         }
         
      }
      
      public function commentDelete (Request $request)
      {
         $id = $request->input("id");
         DB::table("project_blog_article_comment")->where("id", "=", $id)->delete();
         return redirect()->back();
      }
      
      public function commentUpdate (Request $request)
      {
         $id = $request->input("id");
         $comment = $request->input("comment");
         DB::table("project_blog_article_comment")->where("id", "=", $id)->update(["comment" => $comment]);
         return redirect()->back();
      }
      
      public function search (Request $req)
      {
         \Carbon\Carbon::setLocale('tr');
         
         $val = $req->input("search");
         if ($val == "") {
            echo "";
         } else {
            $queryArticle = DB::table("article")->where("title", "like", "%$val%")->orWhere("text", "like", "%$val%")->orWhere("kind", "like", "%$val%")->limit(10)->get();
            $querycategory = DB::table("article")->Where("kind", "like", "%$val%")->limit(10)->get();
            
            if (count($querycategory) === 0 && count($queryArticle) === 0) {
               echo "<li class='item justify-content-between rad-0' style='border-left:2px solid #f3f3f3;'><span class='text sm'>Maalesef hiçbir sonuç bulunamadı !</span> <i class='icon-alert-triangle text-rose'></i></li>";
            } else {
               if (count($queryArticle) === 0) {
               } else {
                  foreach ($queryArticle as $val) {
                     $date = \Carbon\Carbon::parse($val->updated_at)->diffForHumans();
                     echo "<li class='item  rad-0' style='border-left:2px solid #FF5733; margin-bottom: 4px;'><a class='d-flex justify-content-between w-full' href='$val->seo_url'>$val->title <span class='text-light'>$date</span></a> </li>";
                  }
               }
               if (count($querycategory) === 0) {
               } else {
                  foreach ($querycategory as $val) {
                     $date = \Carbon\Carbon::parse($val->updated_at)->diffForHumans();
                     echo "<li class='item  rad-0' style='border-left:2px solid #50CF11; margin-bottom: 4px;'><a  href='" . url('/blog/category/' . $val->kind) . "'>$val->kind  </li>";
                  }
               }
            }
            
         }
         
      }
      
      public function like (Request $request)
      {
         $likeData = [
             "project_name"  => $_POST["project_name"],
             "article_name"  => $_POST["article_name"],
             "liker"         => $_POST["liker"],
             "liker_picture" => $_POST["liker_picture"],
             "created_at"    => Carbon::now(),
             "updated_at"    => Carbon::now()
         ];
         $like = DB::table("project_blog_article_like");
         $likeQuery = $like->where("article_name", "=", $_POST["article_name"])->where("liker", "=", $_POST["liker"])->count();
         $notification = DB::table("member_notification");
         $notifyLikeQuery = $notification->where("who", "=", $_POST["liker"])->where("article_name", "=", $_POST["article_name"])->count();
         if ($likeQuery > 1) {
            $data["error"] = "Beğenme geri alındı...";
            $like->where("liker", "=", $_POST["liker"])->where("article_name", "=", $_POST["article_name"])->delete();
            if ($notifyLikeQuery > 1) {
               $notifyDelete = $notification->where("who", "=", $_POST["liker"])->where("article_name", "=", $_POST["article_name"])->delete();
               if ($notifyDelete) {
                  $data["error"] = "Beğenme geri alındı..." . DB::getPdo()->lastInsertId();
               }
            }
         } else {
            
            $like->insert($likeData);//like tablosuna verileri ekliyorum,
            
            //Notify için notify tablosuna verileri ekliyoruz...
            
            if ($notifyLikeQuery > 1) {
               $notifyDelete = $notification->where("who", "=", $_POST["liker"])->where("article_name", "=", $_POST["article_name"])->delete();
               if ($notifyDelete) {
                  $data["error"] = "Beğenme geri alındı..." . DB::getPdo()->lastInsertId();
               }
            } else {
               $notifyData = [
                   'nick_name'         => $_POST["who"],
                   'who'               => $_POST["liker"],
                   'notify_group'      => "communuty",
                   'notify_type'       => "like",
                   'notify_target'     => $_POST["article_name"],
                   'check'             => 0,
                   "created_at"        => Carbon::now(),
                   "updated_at"        => Carbon::now()
               ];
               $notifyQuery = $notification->insert($notifyData);
               if ($notifyQuery) {
                  $data["success"] = "ekleme işlemi başarılı";
               }
            }
         }
         echo json_encode($data);
      }
   }
