<?php

namespace App\Http\Controllers\Member\Projects\Blog;

use function dd;
use function str_replace;
use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\article;

class BlogController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:member');
    }

    public function index()
    {
        $project_name = Request()->segment(2);
        //table list
        $posts = DB::table("project_blog_article")->where("project_name","=",$project_name)->orderBy('id', 'desc')->limit(6)->get();
        $pop = DB::table("project_blog_article")->select('kind','title','picture','author','author_picture','seo_url')->orderBy('id', 'desc')->limit(5)->get();
        $contact = DB::table("contact")->orderBy('id', 'desc')->limit(1)->get();
        $category = DB::table("project_blog_category")->get();
        $paginate = DB::table("project_blog_article")->paginate(6);
        $comment = DB::table("project_blog_article_comment")->orderBy("id","desc")->get();
        return view('member.blog.homePage', ['posts'=>$posts,'pop'=>$pop,'contact'=>$contact,'category'=>$category,"paginate"=>$paginate,"comment"=>$comment]);
    }
    public function blog($project_name,$name=null){
        if(!is_null ($name)){
            $posts = DB::table("project_blog_article")->where("project_name","=",$project_name)->where("kind","=",str_replace("-","",$name))->orderBy('id', 'desc')->limit(6)->get();
        }else{
            $posts = DB::table("project_blog_article")->where("project_name","=",$project_name)->orderBy('id', 'desc')->limit(6)->get();
        }
        $pop = DB::table("project_blog_article")->select('kind','title','picture','author','author_picture','seo_url')->where("project_name","=",$project_name)->orderBy('id', 'desc')->limit(5)->get();
        $contact = DB::table("contact")->orderBy('id', 'desc')->limit(1)->get();
        $category = DB::table("project_blog_category")->where("project_name","=",$project_name)->get();
        $paginate = DB::table("project_blog_article")->where("project_name","=",$project_name)->paginate(6);
        $comment = DB::table("project_blog_article_comment")->orderBy("id","desc")->get();
        return view('member.blog.blog', ['posts'=>$posts,'pop'=>$pop,'contact'=>$contact,'category'=>$category,"paginate"=>$paginate,"comment"=>$comment]);
    }

    public function article($name){
        $project_name = Request()->segment(2);
        $posts = DB::table("project_blog_article")->where("project_name","=",$project_name)->limit(1)->get();
        $pop = DB::table("project_blog_article")->select('kind','title','picture','author','author_picture','seo_url')->where("project_name","=",$project_name)->orderBy('id', 'desc')->limit(5)->get();
        $contact = DB::table("contact")->orderBy('id', 'desc')->limit(1)->get();
        $category = DB::table("project_blog_category")->where("project_name","=",$project_name)->get();
        $paginate = DB::table("project_blog_article")->where("project_name","=",$project_name)->paginate(6);
        $comment = DB::table("project_blog_article_comment")->orderBy("id","desc")->get();
        return view('member.blog.article', ['posts'=>$posts,'pop'=>$pop,'contact'=>$contact,'category'=>$category,"paginate"=>$paginate,"comment"=>$comment]);
    }

}
