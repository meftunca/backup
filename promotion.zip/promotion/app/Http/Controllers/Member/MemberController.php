<?php
   
   namespace App\Http\Controllers\Member;
   
   use function dd;
   use function is_null;
   use function redirect;
   use function session;
   use Validator;
   use Illuminate\Http\Request;
   use App\Http\Controllers\Controller;
   use Illuminate\Support\Facades\Auth;
   use Illuminate\Support\Facades\DB;
   use App\Models\Notify;
   use App\Member;
   use App\Models\Member_friends as friends;
   
   class MemberController extends Controller
   {
      public function __construct (Request $request)
      {
         $this->middleware('auth:member', ['except' => ['logout']]);
      }
      
      public function notification ()
      {
         dd(session()->get("member"));
         if (session()->has("member")) {
            $notify = Notify::where("nick_name", "=", session()->get("member")["nick_name"])->orderBy('updated_at', 'desc')->take(30)->get();
            view()->share('notification', $notify);
            dd($notify);
         } else {
            //dd(Session()->all());
         }
         return $this;
      }
      
      public function index ()
      {
         $this->notification();
         dd(session()->all());
         return view("member.profile");
      }
      public function me ()
      {
         $this->notification();
         return view("member.profile", ["title" => strtoupper(session()->get("member")["nick_name"]) . " Profili"]);
      }
      public function profile ($member_name=null )
      {
         
         $this->notification();
         if(!is_null($member_name) && session()->get("member")["nick_name"] !== $member_name){
            $member =  Member::where("nick_name","=",$member_name);
            $member_info =$member->get();
            $infoData = ["friends"=>$member->count()];
            return view("member.profile", ["title" => strtoupper($member_name) . " Profili","member_info"=>$member_info,"friends_info"=>$infoData]);
         }else{
            return redirect()->route("member.profile");
         }
      }
      
      public function projects ($member_name)
      {
         $this->notification();
         $project_creator = DB::table("project_creators")->where("creator_nickname", "=", $member_name)->pluck("project_id");
         $project_creator = $project_creator->toArray();
         $projects = DB::table("project")->whereIn("id", $project_creator)->get();
         $this->notification();
   
         return view("member.projects", [
             "title"    => strtoupper("Projelerin"),
             "projects" => $projects
         ]);
      }
      
      public function project_focus ($member_name, $project)
      {
      
      }
      
      public function blog ()
      {
         $this->notification();
         $blog_creator = DB::table("project")->where("creator_nick_name", "=", Auth::user()->nick_name)->pluck("name");
         $blog_creator = $blog_creator->toArray();
         $blog = DB::table("project_blog_article")->whereIn("project_name", $blog_creator)->get();
         $projects = DB::table("project")->select("name", "seo_url", "logo", "creator_nick_name")->where("creator_nick_name", "=", Auth::user()->nick_name)->get();
         return view("member.blogs", [
             "title"    => strtoupper("Bloglarınla ilgilen..."),
             "blogs"    => $blog,
             "projects" => $projects
         ]);
      }
      
   }
