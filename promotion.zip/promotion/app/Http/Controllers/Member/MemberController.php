<?php

namespace App\Http\Controllers\Member;

use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\article;

class MemberController extends Controller
{
    public function __construct()
    {
    $this->middleware('auth:member', ['except' => ['logout']]);
    }
    public function  index(){
        return view("member.profile");
    }
    public function  profile($member_name){
        return view("member.profile",["title"=>strtoupper($member_name)." Projeleri"]);
    }
    public function projects($member_name){
        $project_creator = DB::table("project_creators")->where("creator_nickname","=",$member_name)->pluck("project_id");
        $project_creator = $project_creator->toArray();
        $projects = DB::table("project")->whereIn("id",$project_creator)->get();
        return view("member.projects",["title"=>strtoupper("Projelerin"),"projects"=>$projects]);
    }
    public function project_focus($member_name,$project){

    }
    public function blog(){
        $blog_creator = DB::table("project")->where("creator_nick_name","=",Auth::user()->nick_name)->pluck("name");
        $blog_creator = $blog_creator->toArray();
        $blog = DB::table("project_blog_article")->whereIn("project_name",$blog_creator)->get();
        $projects = DB::table("project")->select("name","seo_url","logo","creator_nick_name")->where("creator_nick_name","=",Auth::user()->nick_name)->get();
        return view("member.blogs",["title"=>strtoupper("Bloglarınla ilgilen..."),"blogs"=>$blog,"projects"=>$projects]);
    }

}
