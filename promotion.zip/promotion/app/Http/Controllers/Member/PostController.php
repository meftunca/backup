<?php

namespace App\Http\Controllers\Member;

use Carbon\Carbon;
use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\article;
use function PHPSTORM_META\type;

class PostController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:member');
    }

    public function login(Request $request){
        $nick_name = $request->input("nick_name");
        $password = $request->input("password");
        $user_query = DB::table("user")->where("nick_name","=",$nick_name);
    }
    public function signin(Request $request){
        $insertData = [
            "nick_name"=>$request->input("nick_name"),
            "name"=>$request->input("name"),
            "last_name"=>$request->input("last_name"),
            "password"=>bcrypt($request->input("password")),
            "mail"=>$request->input("mail"),
            "profile_picture"=>$request->input("profile_picture"),
            "interest"=>$request->input("interest"),
            "about"=>$request->input("about"),
            "facebook"=>$request->input("facebook"),
            "twitter"=>$request->input("twitter"),
            "instagram"=>$request->input("instagram"),
            "github"=>$request->input("github"),
        ];
        $query = DB::table("member")->insert($insertData);
        if($query){
            return redirect()->back();
        }else{
            return redirect()->back()->withErrors("hata");
        }
    }
}
