<?php
   
   namespace App\Http\Controllers\Member\Profile;
   use function dd;
   use function is_null;
   use Validator;
   use Illuminate\Http\Request;
   use App\Http\Controllers\Controller;
   use Illuminate\Support\Facades\Auth;
   use Illuminate\Support\Facades\DB;
   use App\Models\Notify;
   use App\Member;
   use App\Models\Member_friends as friends;

   /**
    * Class ProfileController
    * @package App\Http\Controllers\Member\Profile
    * Extends item
    * users profile list
    * friends profile list
    * active friends profile list
    * message list
    * ...
    */
   class ProfileController  extends Controller
   {
      public function users_profile ($search)
      {
      }
      public function friends_profile ($friends_nick_name)
      {
      }
      public function active_friends_profile ($query)
      {
      }
      public function message_list ($search)
      {
      }
   }