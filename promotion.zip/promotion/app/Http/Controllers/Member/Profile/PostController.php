<?php
   /**
    * Created by PhpStorm.
    * User: devloop
    * Date: 30.01.2018
    * Time: 05:01
    */
   
   namespace App\Http\Controllers\Member\Profile;
   
   use Carbon\Carbon;
   use function dd;
   use function is_null;
   use function json_encode;
   use function print_r;
   use Validator;
   use Illuminate\Http\Request;
   use App\Http\Controllers\Controller;
   use Illuminate\Support\Facades\Auth;
   use Illuminate\Support\Facades\DB;
   use App\Models\Notify;
   use App\Member;
   use App\Models\Member_friends as Friends;
   
   class PostController extends Controller
   {
      public function addUser (Request $request)
      {
         $me = session()->get("member")["nick_name"];
         $userName = $request->input("userName");
         $user_query = Member::where("nick_name", "=", $userName)->count();
         if ($user_query > 0) {
            $notification = DB::table("member_notification");
            
            $friends_query = Friends::where(function ($query) use ($me, $userName) {
               $query->where('bidder', '=', $me)->where('collocutor', '=', $userName);
            })->orWhere(function ($query) use ($me, $userName) {
               $query->where('collocutor', '=', $me)->where('bidder', '=', $userName);
            })->count();
            
            if ($friends_query < 1) {
               $notifyData = [
                   'nick_name'     => $request->input("userName"),
                   "who"           => session()->get("member")["nick_name"],
                   'notify_group'  => "personal",
                   'notify_type'   => "friends",
                   'notify_target' => "any",
                   'check'         => 0,
                   "created_at"    => Carbon::now(),
                   "updated_at"    => Carbon::now()
               ];
               $notifyQuery = $notification->insert($notifyData);
               
               $friendsData = [
                   "bidder"       => $me,
                   "collocutor"   => $userName,
                   "confirmation" => 0,
                   "is_follow"    => 0,
                   "created_at"   => Carbon::now(),
                   "updated_at"   => Carbon::now()
               ];
               $addFriends = DB::table("member_friends")->insert($friendsData);
               if ($addFriends) {
                  $lastFriendsId = DB::getPdo()->lastInsertId();
                  $notifyData = [
                      'nick_name'     => $request->input("userName"),
                      "who"           => session()->get("member")["nick_name"],
                      'notify_group'  => "personal",
                      'notify_type'   => "follow",
                      'notify_target' => "any",
                      'check'         => 0,
                      "created_at"    => Carbon::now(),
                      "updated_at"    => Carbon::now()
                  ];
                  $notifyQuery = $notification->insert($notifyData);
                  
                  $followData = [
                      "bidder"       => $me,
                      "collocutor"   => $userName,
                      "confirmation" => 0,
                      "is_friends"   => 0,
                      "created_at"   => Carbon::now(),
                      "updated_at"   => Carbon::now()
                  ];
                  $addFriends = DB::table("member_follow")->insert($followData);
                  if ($friendsData) {
                     DB::table("member_friends")->where("id", "=", $lastFriendsId)->update(["is_follow" => 1]);
                     $backMessage["success"] = "Arkadaşlık isteğiniz iletildi ve şuanlık takip işlemlerinizi başlattık. Eğer arkadaşı değilseniz takip sistemide devredışı bırakılacak...";
                  } else {
                     $backMessage["warning"] = "Arkadaşlık isteğiniz iletildi ve şuanlık takip işlemlerinizi başlatamadık, lütfen bizi bilgilendirin...";
                  }
                  
               } else {
                  $backMessage["error"] = "Arkadaşlık isteğinizi iletemedik, bir sorun olmalı ? <br> lütfen bizi bilgilendirin...";
               }
               
            } else {
               $backMessage["warning"] = "Zaten arkadaşsınız... sayfayı tekrar yükleyin ve hala görüntü alıyorsanız bize bildirin...";
            }
            
         } else {
            $backMessage["error"] = "Böyle bir kullanıcı kayıtlarımızda yok, hesabı silinmiş olabilir... sayfayı tekrar yükleyin ve hala görüntü alıyorsanız bize bildirin...";
         }
         echo json_encode($backMessage);
      }
      
      public function addFollow ($friends_nick_name)
      {
      }
      
      public function removeUser (Request $request)
      {
         $me = session()->get("member")["nick_name"];
         $userName = $request->input("userName");
         $user_query = Member::where("nick_name", "=", $userName)->count();
         if ($user_query > 0) {
            $notification = DB::table("member_notification");
            
            $friends_query = Friends::where(function ($query) use ($me, $userName) {
               $query->where('bidder', '=', $me)->where('collocutor', '=', $userName);
            })->orWhere(function ($query) use ($me, $userName) {
               $query->where('collocutor', '=', $me)->where('bidder', '=', $userName);
            });
            
            if ($friends_query->count() > 0) {
               $deleteQuery =  $friends_query->delete();
               if($deleteQuery){
                  $backMessage["success"] = "Zaten arkadaşsınız... sayfayı tekrar yükleyin ve hala görüntü alıyorsanız bize bildirin...";
               }
            } else {
               $backMessage["warning"] = "Zaten arkadaşsınız... sayfayı tekrar yükleyin ve hala görüntü alıyorsanız bize bildirin...";
            }
         }
         
      }
      
      public function active_friends_profile ($query)
      {
      }
      
      public function message_list ($search)
      {
      }
   }