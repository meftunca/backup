<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class member_friends extends Model
{
   protected $table = "member_friends";
   /**
    * The attributes that are mass assignable.
    *
    * @var array
    */
   protected $fillable = [
       'id', 'bidder', 'collocutor', 'confirmation','is_follow'
   ];
}
