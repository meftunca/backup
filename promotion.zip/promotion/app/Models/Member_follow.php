<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Member_follow extends Model
{
   protected $table = "member_follow";
   
   protected $fillable = [
       'id', 'bidder', 'collocutor', 'confirmation','is_friends'
   ];
}
