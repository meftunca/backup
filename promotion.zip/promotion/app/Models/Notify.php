<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notify extends Model
{
    protected $table = "member_notification";
   /**
    * The attributes that are mass assignable.
    *
    * @var array
    */
   protected $fillable = [
       'id', 'nick_name', 'who', 'article_name', 'notification_text', 'roles', 'check', 'created_at', 'updated_at'
   ];
   
  
}
